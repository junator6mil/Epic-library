# EPICC TEST 1 — Digital College Library Discovery Platform

A digital discovery layer for a physical college library — not a bookstore, not a social reading network. A student lands on the homepage and feels like they have walked into their college library: every wooden shelf is browsable, every physical book is clickable with exact call number and shelf location, and an intelligent natural-language assistant helps them discover titles by vibe, mood, or comp-titles without needing to know exact titles.

The college librarian gets a dedicated staff management view to curate physical copy counts, import batch catalog records via client-side CSV parsing, manage student acquisition requests, and observe objective demand signals.

---

## 🏛️ Architectural Highlights & Features

### 1. The Wooden Bookshelf Discovery Homepage
- **Physical Bookshelf Aesthetic**: Rich wooden shelf planks with top highlights (`#C89B6D`), deep wood bodies (`#8B5E34`), and under-shelf ambient depth (`#5A3B22`).
- **Mounted Genre Plaques**: Physical engraved plaques with brass rivets and serif typography.
- **Dynamic Shelf Grouping**: Auto-derived from catalog genres (Fiction, Science Fiction, Fantasy, Mystery, Thriller, Romance, History, Biography, Psychology, Self-Help, Business).
- **Featured / New Additions**: Highlight shelf presenting latest additions.
- **Responsive Fluidity**: Desktop multi-cover rows; mobile and tablet horizontal momentum-scrolling with visible next-cover affordances.
- **Cover Image Fallback**: Graceful handling of Open Library covers (`https://covers.openlibrary.org/b/isbn/{isbn}-L.jpg`) with styled foil-embossed literary cloth book spines if offline or missing.

### 2. Floating Bottom-Center Navigation Control
- **Unified Navigation Hub**: Single floating circular control fixed near bottom-center.
- **Accessible Expandable Tray**: Keyboard operable (`Escape` to close, focus management, `aria-expanded`), expanding into Home, Search, Browse Shelves, AI Book Finder, Request a Book, and Librarian Mode.

### 3. Real Local AI Book Finder (`recommendBooks`)
- **Natural Language & Mood Matching**: Synonym dictionary for canonical tags (e.g. `sci-fi` → `science-fiction`, `pirates`, `mind-bending`, `dark`, `short`, `easy-read`, `philosophical`).
- **Comp-Title Shortcuts**: e.g., *"something like Harry Potter but darker"* maps through `{fantasy, magic, adventure, dark}` to surface fitting recommendations.
- **Strict Availability Separation**:
  - **Books in your library**: Displays verified catalog availability (`N copies available`, `Shelf: F-12` or `Currently unavailable`).
  - **Books you may like — not currently in library**: Always explicitly labeled `Not in library`, with a 1-click *"Request this book"* action. Never fabricates availability.

### 4. Book Detail View (Two-Column Editorial)
- Prominent unmissable availability card with physical section, shelf code, call number (`COL-LIB-F-12-...`), and real-time copy count.
- Deep literary specifications: ISBN-13, publisher, publication year, page count, discovery tags.
- Related books shelf derived from shared genre and tag overlaps.

### 5. Librarian Collection Management & Demand Insights
- **Live Inventory**: Table of catalog titles with inline physical copy adjustment (`available / total`), search, add, edit, delete.
- **Batch CSV Import**: Real client-side parser tolerantly mapping column header variants (`book_id`, `isbn`, `title`, `author`, `genre`, `total_copies`, `available_copies`, `shelf`, `section`, `tags`), displaying validation alerts and parsed preview table before merging.
- **Student Requests Queue**: Chronological student acquisition requests with status management and 1-click *"Add to Catalog"*.
- **Student Demand / Acquisition Insights**: Aggregates total requests, estimated unique student requesters, and search frequencies into neutral signal labels (*"Frequently requested"*, *"Frequently searched"*, *"High student interest"*). Strictly avoids prescriptive commercial directives like "Buy this book".

---

## 🛠️ Technology Stack

- **Framework**: React 19 + TypeScript
- **Styling**: Tailwind CSS v4 with custom design tokens (`paper`, `wood`, `accent-green`, `warn-clay`, `ink`)
- **Icons**: Lucide React
- **Build Tool**: Vite

---

## 🚀 Running the Prototype

```bash
# Install dependencies
npm install

# Start development server (port 3000)
npm run dev

# Compile / Typecheck
npm run build
```

---

## 🔮 Scope & Future Extensibility Notes

This v1 prototype is an in-memory, frontend-first discovery experience. In production deployment, the following modular integrations can be connected to the existing service layer (`src/services/`):
- **Backend Database**: PostgreSQL / Cloud SQL via Drizzle ORM to persist physical inventory and checkout states.
- **Vector Search / LLM**: Gemini Embeddings or vector database (e.g., pgvector) to extend the local canonical tag recommendation engine with dense vector semantic search.
- **Open Library & Google Books API**: Live ISBN lookup and enrichment during catalog import.
- **College SSO / Authentication**: Integration with campus directory (SAML/OAuth) for student holds and staff roles.
