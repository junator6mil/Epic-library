import React, { useState, useEffect, useRef } from 'react';
import { 
  Compass, 
  Home, 
  Search, 
  Sparkles, 
  BookPlus, 
  Library, 
  X,
  Layers,
  BookmarkCheck
} from 'lucide-react';
import { getSavedBooksCount, subscribeToSavedBooks } from '../services/savedBooks';

interface FloatingNavProps {
  currentView: string;
  onNavigateHome: () => void;
  onOpenSearch: () => void;
  onOpenAIFinder: () => void;
  onOpenRequest: () => void;
  onToggleLibrarian: () => void;
  isLibrarian: boolean;
  onScrollToShelves?: () => void;
  onOpenSavedBooks?: () => void;
}

export const FloatingNav: React.FC<FloatingNavProps> = ({
  currentView,
  onNavigateHome,
  onOpenSearch,
  onOpenAIFinder,
  onOpenRequest,
  onToggleLibrarian,
  isLibrarian,
  onScrollToShelves,
  onOpenSavedBooks
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [savedCount, setSavedCount] = useState(() => getSavedBooksCount());
  const menuRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const unsub = subscribeToSavedBooks(() => {
      setSavedCount(getSavedBooksCount());
    });
    return unsub;
  }, []);

  // Close on Escape key and return focus
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        setIsOpen(false);
        buttonRef.current?.focus();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen]);

  // Close on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (
        isOpen &&
        menuRef.current &&
        !menuRef.current.contains(e.target as Node) &&
        buttonRef.current &&
        !buttonRef.current.contains(e.target as Node)
      ) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);

  const handleAction = (actionFn: () => void) => {
    actionFn();
    setIsOpen(false);
  };

  return (
    <>
      {/* Dimmed backdrop when menu is open */}
      {isOpen && (
        <div
          onClick={() => setIsOpen(false)}
          className="fixed inset-0 bg-black/40 backdrop-blur-[2px] z-40 transition-opacity animate-fade-in"
          aria-hidden="true"
        />
      )}

      {/* Floating Control Hub */}
      <nav 
        aria-label="Primary Discovery Navigation"
        className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex flex-col items-center select-none"
      >
        {/* Expanded Actions Stack */}
        {isOpen && (
          <div
            ref={menuRef}
            id="floating-nav-menu"
            role="menu"
            aria-orientation="vertical"
            className="mb-3 w-64 sm:w-72 bg-[#FFFDF8] border border-[#E7DFD2] rounded-2xl p-2 shadow-[0_12px_32px_rgba(43,36,30,0.28)] flex flex-col gap-1 animate-in fade-in slide-in-from-bottom-6 duration-200"
          >
            {/* Action 1: Home / Library */}
            <button
              role="menuitem"
              onClick={() => handleAction(onNavigateHome)}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-left text-sm font-medium transition-colors cursor-pointer ${
                currentView === 'home' && !isLibrarian
                  ? 'bg-[#E4EEE6] text-[#3E6B4C]'
                  : 'text-[#2B241E] hover:bg-[#FAF6EE]'
              }`}
            >
              <div className="w-8 h-8 rounded-lg bg-[#FAF6EE] border border-[#E7DFD2] flex items-center justify-center shrink-0 text-[#3E6B4C]">
                <Home className="w-4 h-4" />
              </div>
              <div className="flex flex-col">
                <span className="font-semibold text-xs sm:text-sm">Home & Shelves</span>
                <span className="text-[11px] text-[#6B6055]">Browse main collection & world</span>
              </div>
            </button>

            {/* Action 2: Saved for Later Reading List */}
            {onOpenSavedBooks && (
              <button
                role="menuitem"
                onClick={() => handleAction(onOpenSavedBooks)}
                className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-left text-sm font-medium text-[#2B241E] hover:bg-[#FAF6EE] transition-colors cursor-pointer"
              >
                <div className="w-8 h-8 rounded-lg bg-[#FAF6EE] border border-[#E7DFD2] flex items-center justify-center shrink-0 text-[#D4AF37]">
                  <BookmarkCheck className="w-4 h-4 fill-current" />
                </div>
                <div className="flex flex-col">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-xs sm:text-sm">Saved for Later</span>
                    {savedCount > 0 && (
                      <span className="px-1.5 py-0.2 rounded-full bg-[#3E6B4C] text-white text-[10px] font-bold">
                        {savedCount}
                      </span>
                    )}
                  </div>
                  <span className="text-[11px] text-[#6B6055]">Personal reading list</span>
                </div>
              </button>
            )}

            {/* Action 3: Search */}
            <button
              role="menuitem"
              onClick={() => handleAction(onOpenSearch)}
              className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-left text-sm font-medium text-[#2B241E] hover:bg-[#FAF6EE] transition-colors cursor-pointer"
            >
              <div className="w-8 h-8 rounded-lg bg-[#FAF6EE] border border-[#E7DFD2] flex items-center justify-center shrink-0 text-[#8B5E34]">
                <Search className="w-4 h-4" />
              </div>
              <div className="flex flex-col">
                <span className="font-semibold text-xs sm:text-sm">Search Catalog</span>
                <span className="text-[11px] text-[#6B6055]">By title, author, genre, ISBN</span>
              </div>
            </button>

            {/* Action 4: AI Book Finder */}
            <button
              role="menuitem"
              onClick={() => handleAction(onOpenAIFinder)}
              className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-left text-sm font-medium bg-[#E4EEE6]/50 text-[#2B241E] hover:bg-[#E4EEE6] transition-colors cursor-pointer border border-[#3E6B4C]/20"
            >
              <div className="w-8 h-8 rounded-lg bg-[#3E6B4C] flex items-center justify-center shrink-0 text-[#FAF6EE] shadow-sm">
                <Sparkles className="w-4 h-4" />
              </div>
              <div className="flex flex-col">
                <span className="font-semibold text-xs sm:text-sm text-[#3E6B4C]">AI Book Finder</span>
                <span className="text-[11px] text-[#3E6B4C]/80">Describe your mood or taste</span>
              </div>
            </button>

            {/* Action 5: Request a Book */}
            <button
              role="menuitem"
              onClick={() => handleAction(onOpenRequest)}
              className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-left text-sm font-medium text-[#2B241E] hover:bg-[#FAF6EE] transition-colors cursor-pointer"
            >
              <div className="w-8 h-8 rounded-lg bg-[#FAF6EE] border border-[#E7DFD2] flex items-center justify-center shrink-0 text-[#B15A3E]">
                <BookPlus className="w-4 h-4" />
              </div>
              <div className="flex flex-col">
                <span className="font-semibold text-xs sm:text-sm">Request a Book</span>
                <span className="text-[11px] text-[#6B6055]">Ask library to acquire title</span>
              </div>
            </button>

            {/* Divider */}
            <div className="h-px bg-[#E7DFD2] my-1" />

            {/* Action 6: Librarian View Switcher */}
            <button
              role="menuitem"
              onClick={() => handleAction(onToggleLibrarian)}
              className={`w-full flex items-center gap-3 px-3.5 py-2 rounded-xl text-left text-sm font-medium transition-colors cursor-pointer ${
                isLibrarian 
                  ? 'bg-[#3E6B4C] text-[#FAF6EE]' 
                  : 'text-[#5A3B22] hover:bg-[#FAF6EE]'
              }`}
            >
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                isLibrarian ? 'bg-white/20 text-white' : 'bg-[#FAF6EE] border border-[#E7DFD2] text-[#5A3B22]'
              }`}>
                <Library className="w-4 h-4" />
              </div>
              <div className="flex flex-col">
                <span className="font-semibold text-xs sm:text-sm">
                  {isLibrarian ? 'Switch to Student View' : 'Librarian Dashboard'}
                </span>
                <span className={`text-[11px] ${isLibrarian ? 'text-white/80' : 'text-[#6B6055]'}`}>
                  {isLibrarian ? 'Return to physical shelves' : 'Catalog, requests & insights'}
                </span>
              </div>
            </button>
          </div>
        )}

        {/* Central Circular Floating Trigger */}
        <button
          ref={buttonRef}
          id="floating-nav-button"
          onClick={() => setIsOpen(!isOpen)}
          aria-expanded={isOpen}
          aria-controls="floating-nav-menu"
          aria-label={isOpen ? "Close navigation menu" : "Open discovery and navigation menu"}
          className="group relative flex items-center justify-center w-14 h-14 rounded-full bg-gradient-to-br from-[#3E6B4C] to-[#2B4B34] text-[#FAF6EE] shadow-[0_8px_24px_rgba(43,36,30,0.35)] hover:shadow-[0_12px_28px_rgba(62,107,76,0.45)] border-2 border-[#FAF6EE] transition-all duration-200 ease-out hover:scale-105 active:scale-95 cursor-pointer focus:outline-none focus:ring-4 focus:ring-[#3E6B4C]/40"
        >
          {isOpen ? (
            <X className="w-6 h-6 transition-transform duration-200 rotate-90" />
          ) : (
            <div className="flex flex-col items-center justify-center">
              <Compass className="w-6 h-6 group-hover:rotate-45 transition-transform duration-300" />
              <span className="sr-only">Discover</span>
            </div>
          )}

          {/* Pulsing ring indicator on first load */}
          {!isOpen && (
            <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#C89B6D] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-[#C89B6D] border-2 border-[#FAF6EE]"></span>
            </span>
          )}
        </button>
      </nav>
    </>
  );
};

