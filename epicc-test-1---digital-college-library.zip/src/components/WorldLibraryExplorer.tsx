import React, { useState, useEffect, useMemo, useTransition } from 'react';
import { WorldBook, Book } from '../types';
import { 
  searchOpenLibraryWorld, 
  fetchWorldBooksBySubject, 
  getAllCuratedWorldBooks 
} from '../services/worldBooks';
import { BookCover } from './BookCover';
import { 
  Globe, 
  Search, 
  Sparkles, 
  BookOpen, 
  Building2, 
  BookPlus, 
  CheckCircle2, 
  RefreshCw, 
  Layers, 
  ExternalLink,
  ChevronRight,
  Filter,
  X
} from 'lucide-react';

interface WorldLibraryExplorerProps {
  onSelectWorldBook: (worldBook: WorldBook) => void;
  onRequestBook: (title: string, author?: string) => void;
  onJumpToPhysicalShelf?: (shelfCode: string) => void;
}

const WORLD_SUBJECT_PILLS = [
  { label: '🌟 All Curated Masterpieces', value: 'all' },
  { label: '🏆 Nobel Laureates', value: 'nobel' },
  { label: '🏛️ World Classics', value: 'classics' },
  { label: '🌌 Sci-Fi & Speculative', value: 'science_fiction' },
  { label: '🧠 World Philosophy', value: 'philosophy' },
  { label: '⛩️ Asian Literature', value: 'japanese_literature' },
  { label: '🦜 Latin American', value: 'latin_american' },
  { label: '🌍 African Canon', value: 'african_literature' },
  { label: '📜 World History', value: 'history' },
  { label: '🕵️ Mystery & Noir', value: 'mystery' },
  { label: '🔬 Science & Cosmos', value: 'science' },
  { label: '🎭 Poetry & Drama', value: 'poetry' },
];

export const WorldLibraryExplorer: React.FC<WorldLibraryExplorerProps> = ({
  onSelectWorldBook,
  onRequestBook,
  onJumpToPhysicalShelf,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeSubject, setActiveSubject] = useState('all');
  const [filterMode, setFilterMode] = useState<'all' | 'in-library' | 'not-in-library'>('all');
  const [sortBy, setSortBy] = useState<'curated' | 'editions' | 'year-asc' | 'year-desc'>('curated');
  
  // Results & Pagination State
  const [books, setBooks] = useState<WorldBook[]>(() => getAllCuratedWorldBooks());
  const [totalFound, setTotalFound] = useState<number>(() => getAllCuratedWorldBooks().length);
  const [page, setPage] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [, startTransition] = useTransition();

  // Load initial or query-based world books
  useEffect(() => {
    let isCancelled = false;

    async function loadData() {
      setIsLoading(true);
      setPage(1);

      if (searchQuery.trim()) {
        const res = await searchOpenLibraryWorld(searchQuery.trim(), 1, 24);
        if (!isCancelled) {
          setBooks(res.books);
          setTotalFound(res.totalFound);
          setIsLoading(false);
        }
      } else if (activeSubject !== 'all') {
        if (activeSubject === 'nobel') {
          const curated = getAllCuratedWorldBooks().filter(b => b.tags.includes('nobel-prize') || b.genre.includes('Nobel'));
          if (!isCancelled) {
            setBooks(curated);
            setTotalFound(curated.length);
            setIsLoading(false);
          }
        } else if (activeSubject === 'classics') {
          const curated = getAllCuratedWorldBooks().filter(b => b.genre === 'World Classics');
          if (!isCancelled) {
            setBooks(curated);
            setTotalFound(curated.length);
            setIsLoading(false);
          }
        } else {
          const subjBooks = await fetchWorldBooksBySubject(activeSubject, 24);
          if (!isCancelled) {
            setBooks(subjBooks.length > 0 ? subjBooks : getAllCuratedWorldBooks());
            setTotalFound(subjBooks.length > 0 ? subjBooks.length : getAllCuratedWorldBooks().length);
            setIsLoading(false);
          }
        }
      } else {
        const allCurated = getAllCuratedWorldBooks();
        if (!isCancelled) {
          setBooks(allCurated);
          setTotalFound(allCurated.length);
          setIsLoading(false);
        }
      }
    }

    // Debounce search query
    const timeout = setTimeout(() => {
      loadData();
    }, searchQuery ? 400 : 0);

    return () => {
      isCancelled = true;
      clearTimeout(timeout);
    };
  }, [searchQuery, activeSubject]);

  // Load More Handler for infinite world exploration
  const handleLoadMore = async () => {
    if (isLoadingMore || !searchQuery.trim()) return;
    setIsLoadingMore(true);
    const nextPage = page + 1;
    const res = await searchOpenLibraryWorld(searchQuery.trim(), nextPage, 24);
    setBooks(prev => [...prev, ...res.books]);
    setPage(nextPage);
    setIsLoadingMore(false);
  };

  // Filter and Sort Processing
  const filteredAndSortedBooks = useMemo(() => {
    let list = [...books];

    // Library Availability Filter
    if (filterMode === 'in-library') {
      list = list.filter(b => b.inLibrary);
    } else if (filterMode === 'not-in-library') {
      list = list.filter(b => !b.inLibrary);
    }

    // Sorting
    if (sortBy === 'editions') {
      list.sort((a, b) => (b.editionCount || 0) - (a.editionCount || 0));
    } else if (sortBy === 'year-asc') {
      list.sort((a, b) => (a.publicationYear || 0) - (b.publicationYear || 0));
    } else if (sortBy === 'year-desc') {
      list.sort((a, b) => (b.publicationYear || 0) - (a.publicationYear || 0));
    }

    return list;
  }, [books, filterMode, sortBy]);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* World Library Hero Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-[#2C3E50] via-[#1E3A2F] to-[#2B241E] text-[#FAF6EE] p-6 sm:p-8 border border-[#3E6B4C]/40 shadow-xl relative overflow-hidden">
        {/* Subtle decorative background pattern */}
        <div className="absolute right-0 top-0 bottom-0 w-1/3 opacity-10 bg-[radial-gradient(#FAF6EE_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none" />
        
        <div className="relative z-10 max-w-3xl space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#FAF6EE]/15 border border-[#FAF6EE]/20 text-xs font-semibold uppercase tracking-wider backdrop-blur-xs">
            <Globe className="w-3.5 h-3.5 text-[#B8D8BF]" />
            <span>Universal World Library Archive</span>
            <span className="text-[#B8D8BF]">• 30M+ Books</span>
          </div>

          <h2 className="font-serif font-bold text-2xl sm:text-3xl lg:text-4xl text-[#FAF6EE] leading-tight">
            Explore Every Book in the World
          </h2>

          <p className="text-sm sm:text-base text-[#E7DFD2]/90 leading-relaxed font-sans">
            Search human literature from ancient manuscripts to contemporary global bestsellers. Seamlessly cross-references physical college shelves with 1-click acquisition requests for unowned titles.
          </p>

          {/* Live Search Input Bar */}
          <div className="pt-2">
            <div className="relative flex items-center w-full max-w-2xl bg-[#FFFDF8] rounded-2xl border-2 border-[#FAF6EE]/30 focus-within:border-[#3E6B4C] shadow-lg transition-all">
              <Search className="w-5 h-5 text-[#8B5E34] absolute left-4 shrink-0 pointer-events-none" />
              
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search any book title, author, or topic across the globe (e.g. Dante, Murakami, Quantum Physics)..."
                className="w-full pl-12 pr-10 py-3.5 bg-transparent text-sm text-[#2B241E] placeholder:text-[#6B6055] focus:outline-none rounded-2xl"
              />

              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 p-1.5 text-[#6B6055] hover:text-[#2B241E] rounded-full hover:bg-black/5"
                  title="Clear search"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* World Region & Subject Pills */}
      <div className="flex items-center gap-2 overflow-x-auto py-2 shelf-scrollbar">
        <span className="text-xs font-semibold text-[#6B6055] uppercase tracking-wider shrink-0 mr-1 flex items-center gap-1">
          <Layers className="w-3.5 h-3.5 text-[#8B5E34]" />
          <span>Curations:</span>
        </span>
        {WORLD_SUBJECT_PILLS.map((pill) => (
          <button
            key={pill.value}
            onClick={() => {
              setSearchQuery('');
              setActiveSubject(pill.value);
            }}
            className={`text-xs px-3.5 py-1.5 rounded-full font-medium whitespace-nowrap cursor-pointer transition-all border shadow-2xs ${
              activeSubject === pill.value && !searchQuery
                ? 'bg-[#3E6B4C] text-[#FAF6EE] border-[#3E6B4C] shadow-xs'
                : 'bg-[#FFFDF8] text-[#2B241E] hover:bg-[#E4EEE6] border-[#D5CABE]'
            }`}
          >
            {pill.label}
          </button>
        ))}
      </div>

      {/* Filter and Status Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#FFFDF8] p-4 rounded-2xl border border-[#E7DFD2]">
        <div className="flex items-center gap-3">
          <span className="text-xs sm:text-sm font-semibold text-[#2B241E]">
            {isLoading ? (
              <span className="flex items-center gap-2 text-[#3E6B4C]">
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Searching universal archive...</span>
              </span>
            ) : (
              <span>
                Showing <strong className="text-[#3E6B4C]">{filteredAndSortedBooks.length}</strong> {searchQuery ? `matches for "${searchQuery}"` : 'world titles'}
                {totalFound > books.length && ` (of ${totalFound.toLocaleString()} cataloged)`}
              </span>
            )}
          </span>
        </div>

        {/* Filter / Sort Selectors */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Availability Filter */}
          <div className="flex items-center bg-[#FAF6EE] rounded-xl p-1 border border-[#D5CABE] text-xs">
            <button
              onClick={() => setFilterMode('all')}
              className={`px-2.5 py-1 rounded-lg font-medium transition-colors cursor-pointer ${
                filterMode === 'all' ? 'bg-[#3E6B4C] text-white shadow-2xs' : 'text-[#6B6055] hover:text-[#2B241E]'
              }`}
            >
              All World
            </button>
            <button
              onClick={() => setFilterMode('in-library')}
              className={`px-2.5 py-1 rounded-lg font-medium transition-colors cursor-pointer ${
                filterMode === 'in-library' ? 'bg-[#3E6B4C] text-white shadow-2xs' : 'text-[#6B6055] hover:text-[#2B241E]'
              }`}
            >
              In Library ({books.filter(b => b.inLibrary).length})
            </button>
            <button
              onClick={() => setFilterMode('not-in-library')}
              className={`px-2.5 py-1 rounded-lg font-medium transition-colors cursor-pointer ${
                filterMode === 'not-in-library' ? 'bg-[#3E6B4C] text-white shadow-2xs' : 'text-[#6B6055] hover:text-[#2B241E]'
              }`}
            >
              Unowned
            </button>
          </div>

          {/* Sort Selector */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            aria-label="Sort books"
            className="bg-[#FAF6EE] border border-[#D5CABE] rounded-xl px-2.5 py-1.5 text-xs text-[#2B241E] focus:outline-none"
          >
            <option value="curated">Curated Order</option>
            <option value="editions">Most Global Editions</option>
            <option value="year-asc">Oldest Era First</option>
            <option value="year-desc">Newest First</option>
          </select>
        </div>
      </div>

      {/* World Books Responsive Grid */}
      {filteredAndSortedBooks.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
          {filteredAndSortedBooks.map((wb) => (
            <div
              key={wb.bookId}
              className="bg-[#FFFDF8] border border-[#E7DFD2] hover:border-[#3E6B4C]/50 rounded-2xl p-4 sm:p-5 flex flex-col justify-between shadow-xs hover:shadow-[0_8px_24px_rgba(43,36,30,0.1)] transition-all group"
            >
              <div>
                {/* Book Cover + Basic Info */}
                <div className="flex gap-4 mb-3.5">
                  <div className="shrink-0">
                    <BookCover
                      book={wb}
                      size="sm"
                      onClick={() => onSelectWorldBook(wb)}
                    />
                  </div>

                  <div className="flex-1 min-w-0 space-y-1">
                    {/* Genre Tag & Year */}
                    <div className="flex items-center justify-between gap-1">
                      <span className="text-[10px] uppercase tracking-wider font-bold text-[#8B5E34] bg-[#FAF6EE] px-2 py-0.5 rounded border border-[#E7DFD2] truncate">
                        {wb.genre}
                      </span>
                      <span className="text-[11px] text-[#6B6055] shrink-0 font-medium">
                        {wb.publicationYear > 0 ? wb.publicationYear : `${Math.abs(wb.publicationYear)} BCE`}
                      </span>
                    </div>

                    <h3
                      onClick={() => onSelectWorldBook(wb)}
                      className="font-serif font-bold text-sm sm:text-base text-[#2B241E] group-hover:text-[#3E6B4C] cursor-pointer line-clamp-2 leading-snug"
                    >
                      {wb.title}
                    </h3>

                    <p className="text-xs text-[#6B6055] line-clamp-1 font-medium">
                      by <span className="text-[#2B241E]">{wb.author}</span>
                    </p>

                    {wb.editionCount && wb.editionCount > 1 && (
                      <span className="text-[10px] text-[#6B6055] block">
                        {wb.editionCount} world editions
                      </span>
                    )}
                  </div>
                </div>

                {/* Synopsis Snippet */}
                <p className="text-xs text-[#6B6055] line-clamp-2 leading-relaxed mb-3">
                  {wb.description}
                </p>

                {/* Subject Tags */}
                {wb.tags && wb.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-3">
                    {wb.tags.slice(0, 3).map((tag) => (
                      <span
                        key={tag}
                        className="text-[10px] px-2 py-0.5 rounded-md bg-[#FAF6EE] border border-[#E7DFD2] text-[#6B6055]"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              {/* Bottom Availability Status & Action Row */}
              <div className="pt-3 border-t border-[#E7DFD2] space-y-2">
                {wb.inLibrary && wb.libraryBook ? (
                  <div className="flex items-center justify-between gap-2 bg-[#E4EEE6] border border-[#B8D8BF] text-[#24452F] px-3 py-1.5 rounded-xl text-xs font-semibold">
                    <div className="flex items-center gap-1.5 truncate">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#3E6B4C] shrink-0" />
                      <span className="truncate">Shelf {wb.libraryBook.shelf} ({wb.libraryBook.availableCopies} available)</span>
                    </div>
                    <button
                      onClick={() => onSelectWorldBook(wb)}
                      className="text-[11px] underline hover:text-[#1E3A2F] shrink-0 font-bold cursor-pointer"
                    >
                      Locate
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] text-[#6B6055] font-medium flex items-center gap-1">
                      <Globe className="w-3 h-3 text-[#8B5E34]" />
                      <span>World Catalog</span>
                    </span>

                    <button
                      onClick={() => onRequestBook(wb.title, wb.author)}
                      className="flex items-center gap-1 px-2.5 py-1 bg-[#FAF6EE] hover:bg-[#E4EEE6] text-[#3E6B4C] hover:text-[#2B4B34] border border-[#3E6B4C]/40 rounded-lg text-xs font-semibold transition-colors cursor-pointer shadow-2xs"
                    >
                      <BookPlus className="w-3.5 h-3.5" />
                      <span>Request</span>
                    </button>
                  </div>
                )}

                <button
                  onClick={() => onSelectWorldBook(wb)}
                  className="w-full flex items-center justify-center gap-1 py-1 text-xs text-[#8B5E34] hover:text-[#5A3B22] font-semibold cursor-pointer"
                >
                  <span>View Full Details & Editions</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-16 bg-[#FFFDF8] rounded-3xl border border-[#E7DFD2] p-8">
          <BookOpen className="w-12 h-12 text-[#8B5E34] mx-auto mb-3 opacity-60" />
          <h3 className="font-serif font-bold text-lg text-[#2B241E]">
            No World Titles Matched the Filter
          </h3>
          <p className="text-xs sm:text-sm text-[#6B6055] mt-1 max-w-md mx-auto mb-4">
            Try broadening your search query, clearing filters, or browsing our curated world masterpiece subjects.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setActiveSubject('all');
              setFilterMode('all');
            }}
            className="px-4 py-2 bg-[#3E6B4C] text-[#FAF6EE] rounded-xl text-xs font-semibold cursor-pointer"
          >
            Reset World Explorer
          </button>
        </div>
      )}

      {/* Load More Button for Live Queries */}
      {searchQuery && filteredAndSortedBooks.length > 0 && (
        <div className="text-center pt-6">
          <button
            onClick={handleLoadMore}
            disabled={isLoadingMore}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#3E6B4C] hover:bg-[#2B4B34] text-[#FAF6EE] text-xs sm:text-sm font-semibold transition-colors cursor-pointer shadow-md disabled:opacity-50"
          >
            {isLoadingMore ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Loading Next Batch of World Titles...</span>
              </>
            ) : (
              <>
                <Globe className="w-4 h-4" />
                <span>Load More from World Archive</span>
              </>
            )}
          </button>
        </div>
      )}

    </div>
  );
};
