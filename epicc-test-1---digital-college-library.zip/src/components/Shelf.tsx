import React, { useRef } from 'react';
import { Book, WorldBook } from '../types';
import { BookCover } from './BookCover';
import { GenrePlaque } from './GenrePlaque';
import { ChevronRight, ChevronLeft } from 'lucide-react';

interface ShelfProps {
  genre: string;
  subtitle?: string;
  books: (Book | WorldBook)[];
  onSelectBook: (bookId: string) => void;
  onViewAll?: (genre: string) => void;
  isFeatured?: boolean;
}

export const Shelf: React.FC<ShelfProps> = ({
  genre,
  subtitle,
  books,
  onSelectBook,
  onViewAll,
  isFeatured = false
}) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const offset = direction === 'left' ? -340 : 340;
      scrollContainerRef.current.scrollBy({ left: offset, behavior: 'smooth' });
    }
  };

  if (books.length === 0) {
    return null;
  }

  return (
    <section 
      id={`shelf-${genre.toLowerCase().replace(/\s+/g, '-')}`}
      className="relative pt-6 sm:pt-8"
      aria-label={`${genre} bookshelf`}
    >
      {/* Shelf Header with Mounted Plaque */}
      <div className="flex items-center justify-between px-4 sm:px-8 mb-2 sm:mb-3">
        <GenrePlaque
          title={isFeatured ? `★ ${genre}` : genre}
          subtitle={subtitle}
          count={books.length}
        />

        {/* Action / View All & Scroll Buttons */}
        <div className="flex items-center gap-2">
          {onViewAll && books.length > 4 && (
            <button
              onClick={() => onViewAll(genre)}
              className="text-xs sm:text-sm font-semibold text-[#3E6B4C] hover:text-[#24452F] px-3 py-1 rounded-lg hover:bg-[#E4EEE6]/70 transition-colors flex items-center gap-1 cursor-pointer bg-white/70 border border-[#D5CABE] shadow-2xs"
            >
              <span>View all</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          )}

          {/* Scroll arrows for desktop ease */}
          <div className="hidden md:flex items-center gap-1 bg-[#4A2D17]/80 p-0.5 rounded-lg border border-[#351E0E] shadow-xs">
            <button
              onClick={() => scroll('left')}
              aria-label="Scroll left"
              className="p-1.5 rounded text-[#F5E6CC] hover:bg-white/20 transition-colors cursor-pointer active:scale-95"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => scroll('right')}
              aria-label="Scroll right"
              className="p-1.5 rounded text-[#F5E6CC] hover:bg-white/20 transition-colors cursor-pointer active:scale-95"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Books Container */}
      <div className="relative">
        <div
          ref={scrollContainerRef}
          className="shelf-scrollbar flex items-end gap-5 sm:gap-8 px-6 sm:px-12 overflow-x-auto scroll-smooth pb-0 pt-4 relative z-10"
        >
          {books.map((book) => (
            <div key={book.bookId} className="shrink-0 flex flex-col items-center">
              <BookCover
                book={book}
                size="md"
                showStatusDot={true}
                showSaveButton={true}
                onClick={() => onSelectBook(book.bookId)}
              />
            </div>
          ))}
          {/* Trailing spacer so the last book has space before edge */}
          <div className="w-6 shrink-0" />
        </div>

        {/* Physical Ultra-Thick Wooden Shelf Structure (Like classic wooden bookcase) */}
        <div className="relative w-full select-none pointer-events-none mt-0">
          
          {/* 1. Shelf Top Edge & Golden Highlight Bevel */}
          <div className="h-3 sm:h-3.5 w-full bg-gradient-to-r from-[#B5824C] via-[#E2B37E] to-[#A8723E] border-t-2 border-[#FFE8D0]/60 shadow-[inset_0_1px_2px_rgba(255,255,255,0.4),0_-2px_4px_rgba(0,0,0,0.15)] flex items-center justify-between px-8">
            <div className="w-full h-full opacity-35 bg-[repeating-linear-gradient(90deg,transparent,transparent_30px,rgba(255,255,255,0.4)_31px,transparent_32px)]" />
          </div>

          {/* 2. Thick Wooden Shelf Front Fascia Plank */}
          <div className="h-6 sm:h-7 w-full bg-gradient-to-b from-[#8C572D] via-[#74431F] to-[#542F12] border-b-2 border-[#2E1809] shadow-[0_8px_16px_rgba(35,20,10,0.45)] flex items-center justify-between px-8 relative">
            {/* Wood Grain Lines */}
            <div className="w-full h-full opacity-25 bg-[repeating-linear-gradient(90deg,transparent,transparent_45px,rgba(0,0,0,0.5)_46px,transparent_47px)]" />
            {/* Subtle brass screw heads at corners */}
            <div className="absolute left-3 w-1.5 h-1.5 rounded-full bg-[#1F1006] shadow-[inset_0_1px_1px_rgba(0,0,0,0.8)]" />
            <div className="absolute right-3 w-1.5 h-1.5 rounded-full bg-[#1F1006] shadow-[inset_0_1px_1px_rgba(0,0,0,0.8)]" />
          </div>

          {/* 3. Under-shelf Deep Drop Shadow */}
          <div className="h-6 sm:h-8 w-full bg-gradient-to-b from-black/50 via-black/20 to-transparent blur-[1px]" />
        </div>
      </div>
    </section>
  );
};

