import React from 'react';
import { Book, ExternalBook } from '../types';
import { CheckCircle2, AlertCircle, HelpCircle } from 'lucide-react';

interface StatusBadgeProps {
  book: Book | ExternalBook;
  size?: 'sm' | 'md' | 'lg';
  showDetails?: boolean;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({
  book,
  size = 'md',
  showDetails = false
}) => {
  const isInLibrary = 'availableCopies' in book;

  if (!isInLibrary) {
    return (
      <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#E7DFD2] text-[#6B6055] text-xs font-medium border border-[#D5CABE]">
        <HelpCircle className="w-3.5 h-3.5 text-[#6B6055] shrink-0" />
        <span>Not in library</span>
      </div>
    );
  }

  const libBook = book as Book;
  const isAvailable = libBook.availableCopies > 0;

  if (isAvailable) {
    return (
      <div className={`inline-flex flex-col sm:flex-row sm:items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#E4EEE6] text-[#3E6B4C] border border-[#C5DDC9] ${
        size === 'lg' ? 'text-sm' : 'text-xs'
      }`}>
        <div className="inline-flex items-center gap-1.5 font-semibold">
          <CheckCircle2 className="w-4 h-4 text-[#3E6B4C] shrink-0" />
          <span>Available in library</span>
        </div>
        
        {showDetails && (
          <div className="text-xs text-[#3E6B4C]/90 font-medium pl-5 sm:pl-0 sm:border-l sm:border-[#3E6B4C]/25 sm:ml-1 sm:pl-2">
            <span>{libBook.availableCopies} of {libBook.totalCopies} copies ready</span>
            {libBook.shelf && (
              <span className="ml-2 font-mono bg-white/60 px-1.5 py-0.5 rounded text-[11px] text-[#2B241E]">
                Shelf {libBook.shelf}
              </span>
            )}
          </div>
        )}
      </div>
    );
  }

  // Unavailable (0 copies)
  return (
    <div className={`inline-flex flex-col sm:flex-row sm:items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#F3E3DC] text-[#B15A3E] border border-[#E8C7BC] ${
      size === 'lg' ? 'text-sm' : 'text-xs'
    }`}>
      <div className="inline-flex items-center gap-1.5 font-semibold">
        <AlertCircle className="w-4 h-4 text-[#B15A3E] shrink-0" />
        <span>Currently unavailable</span>
      </div>

      {showDetails && (
        <div className="text-xs text-[#B15A3E]/90 font-medium pl-5 sm:pl-0 sm:border-l sm:border-[#B15A3E]/25 sm:ml-1 sm:pl-2">
          <span>0 of {libBook.totalCopies} copies available</span>
          {libBook.shelf && (
            <span className="ml-2 font-mono bg-white/60 px-1.5 py-0.5 rounded text-[11px] text-[#2B241E]">
              Shelf {libBook.shelf}
            </span>
          )}
        </div>
      )}
    </div>
  );
};
