import React, { useState, useEffect } from 'react';
import { APP_CONFIG } from '../config/appConfig';
import { BookOpen, Search, Sparkles, Library, UserCheck, BookmarkCheck } from 'lucide-react';
import { getSavedBooksCount, subscribeToSavedBooks } from '../services/savedBooks';

interface HeaderProps {
  isLibrarian: boolean;
  onToggleLibrarian: () => void;
  onOpenSearch: () => void;
  onOpenAIFinder: () => void;
  onNavigateHome: () => void;
  onOpenSavedBooks?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  isLibrarian,
  onToggleLibrarian,
  onOpenSearch,
  onOpenAIFinder,
  onNavigateHome,
  onOpenSavedBooks
}) => {
  const [savedCount, setSavedCount] = useState(() => getSavedBooksCount());

  useEffect(() => {
    const unsub = subscribeToSavedBooks(() => {
      setSavedCount(getSavedBooksCount());
    });
    return unsub;
  }, []);

  return (
    <header className="border-b border-[#E7DFD2] bg-[#FFFDF8]/90 backdrop-blur-md sticky top-0 z-30 transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        
        {/* Brand Wordmark */}
        <div 
          onClick={onNavigateHome}
          className="flex items-center gap-3 cursor-pointer group select-none"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#8B5E34] to-[#5A3B22] flex items-center justify-center text-[#FAF6EE] shadow-[0_2px_6px_rgba(90,59,34,0.3)] group-hover:scale-105 transition-transform">
            <BookOpen className="w-5 h-5 text-[#FAF6EE]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-serif font-bold text-base sm:text-lg text-[#2B241E] tracking-tight group-hover:text-[#3E6B4C] transition-colors">
                {APP_CONFIG.appName}
              </span>
              <span className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded bg-[#FAF6EE] text-[#8B5E34] border border-[#E7DFD2] hidden sm:inline-block">
                Discovery
              </span>
            </div>
            <p className="text-[11px] text-[#6B6055] leading-none hidden sm:block">
              {APP_CONFIG.librarySubtitle}
            </p>
          </div>
        </div>

        {/* Quick Header Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Quick Search Button */}
          <button
            onClick={onOpenSearch}
            aria-label="Search collection"
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#FAF6EE] hover:bg-[#E7DFD2] text-[#2B241E] border border-[#D5CABE] text-xs sm:text-sm font-medium transition-colors cursor-pointer"
          >
            <Search className="w-4 h-4 text-[#8B5E34]" />
            <span className="hidden md:inline text-[#6B6055]">Quick Search...</span>
          </button>

          {/* AI Book Finder Button */}
          <button
            onClick={onOpenAIFinder}
            aria-label="Open AI Book Finder"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#E4EEE6] hover:bg-[#D5E6D8] text-[#3E6B4C] border border-[#C5DDC9] text-xs sm:text-sm font-semibold transition-colors cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-[#3E6B4C]" />
            <span className="hidden sm:inline">AI Finder</span>
          </button>

          {/* Saved for Later Reading List */}
          {onOpenSavedBooks && (
            <button
              onClick={onOpenSavedBooks}
              aria-label="View saved books"
              title="Saved for Later Reading List"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#FAF6EE] hover:bg-[#E7DFD2] text-[#2B241E] border border-[#D5CABE] text-xs sm:text-sm font-medium transition-colors cursor-pointer relative"
            >
              <BookmarkCheck className={`w-4 h-4 ${savedCount > 0 ? 'text-[#D4AF37] fill-current' : 'text-[#8B5E34]'}`} />
              <span className="hidden sm:inline">Saved</span>
              {savedCount > 0 && (
                <span className="px-1.5 py-0.2 rounded-full bg-[#3E6B4C] text-white text-[10px] font-bold">
                  {savedCount}
                </span>
              )}
            </button>
          )}

          {/* Librarian / Student Toggle */}
          <button
            onClick={onToggleLibrarian}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition-all cursor-pointer border ${
              isLibrarian
                ? 'bg-[#3E6B4C] text-[#FAF6EE] border-[#2B4B34] shadow-xs'
                : 'bg-[#FFFDF8] text-[#5A3B22] border-[#D5CABE] hover:bg-[#FAF6EE]'
            }`}
          >
            {isLibrarian ? (
              <>
                <UserCheck className="w-4 h-4" />
                <span>Librarian Mode</span>
              </>
            ) : (
              <>
                <Library className="w-4 h-4 text-[#8B5E34]" />
                <span className="hidden sm:inline">Librarian View</span>
                <span className="sm:hidden">Staff</span>
              </>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};

