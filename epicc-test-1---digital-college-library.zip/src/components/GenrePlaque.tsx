import React from 'react';

interface GenrePlaqueProps {
  title: string;
  subtitle?: string;
  count?: number;
  onClick?: () => void;
  className?: string;
}

export const GenrePlaque: React.FC<GenrePlaqueProps> = ({
  title,
  subtitle,
  count,
  onClick,
  className = ''
}) => {
  return (
    <div
      onClick={onClick}
      role={onClick ? "button" : undefined}
      tabIndex={onClick ? 0 : undefined}
      className={`inline-flex items-center gap-3 px-4 py-2 rounded-md bg-gradient-to-b from-[#4A321E] via-[#3D2817] to-[#2E1E11] text-[#F5E6CC] border-t border-[#8B5E34]/50 border-b border-black/80 shadow-[inset_0_1px_2px_rgba(255,255,255,0.2),0_4px_8px_rgba(0,0,0,0.35)] select-none relative group ${
        onClick ? 'cursor-pointer hover:from-[#5A3E26] hover:to-[#382516] transition-colors' : ''
      } ${className}`}
    >
      {/* Left faux brass rivet/screw */}
      <span className="w-1.5 h-1.5 rounded-full bg-[#C89B6D] shadow-[inset_0_1px_1px_rgba(0,0,0,0.6),0_1px_1px_rgba(255,255,255,0.3)] shrink-0" />

      <div className="flex items-baseline gap-2">
        <h3 className="font-serif font-bold text-sm sm:text-base tracking-wide text-[#FBF5E8] drop-shadow-[0_1px_1px_rgba(0,0,0,0.8)]">
          {title}
        </h3>
        {subtitle && (
          <span className="text-[11px] font-sans tracking-normal text-[#C89B6D] opacity-90 hidden sm:inline">
            {subtitle}
          </span>
        )}
      </div>

      {count !== undefined && (
        <span className="text-[11px] font-sans font-medium px-1.5 py-0.5 rounded bg-black/40 text-[#E7DFD2] border border-[#8B5E34]/40">
          {count} {count === 1 ? 'title' : 'titles'}
        </span>
      )}

      {/* Right faux brass rivet/screw */}
      <span className="w-1.5 h-1.5 rounded-full bg-[#C89B6D] shadow-[inset_0_1px_1px_rgba(0,0,0,0.6),0_1px_1px_rgba(255,255,255,0.3)] shrink-0" />
    </div>
  );
};
