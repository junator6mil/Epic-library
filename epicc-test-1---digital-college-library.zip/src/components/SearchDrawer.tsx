import React, { useState, useMemo, useEffect, useRef } from 'react';
import { Search, X, Filter, BookOpen } from 'lucide-react';
import { searchBooks } from '../services/search';
import { getGenres } from '../services/catalog';
import { recordSearch } from '../services/insights';
import { BookCover } from './BookCover';
import { StatusBadge } from './StatusBadge';
import { Book } from '../types';

interface SearchDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectBook: (bookId: string) => void;
}

export const SearchDrawer: React.FC<SearchDrawerProps> = ({
  isOpen,
  onClose,
  onSelectBook,
}) => {
  const [query, setQuery] = useState('');
  const [selectedGenre, setSelectedGenre] = useState<string>('all');
  const [availableOnly, setAvailableOnly] = useState<boolean>(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const genres = useMemo(() => ['all', ...getGenres()], []);

  // Focus input when opened
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [isOpen]);

  // Debounced search demand insight recording
  useEffect(() => {
    if (!isOpen || query.trim().length < 3) return;
    const timer = setTimeout(() => {
      recordSearch(query.trim());
    }, 600);

    return () => clearTimeout(timer);
  }, [isOpen, query]);

  // Execute real live search against catalog
  const results = useMemo(() => {
    return searchBooks(query, {
      genre: selectedGenre,
      availableOnly: availableOnly,
    });
  }, [query, selectedGenre, availableOnly]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end bg-black/50 backdrop-blur-xs animate-in fade-in duration-200">
      {/* Click backdrop to close */}
      <div className="flex-1" onClick={onClose} />

      {/* Drawer Container sliding up from bottom */}
      <div 
        id="search-panel"
        role="dialog"
        aria-label="Library Catalog Search"
        className="w-full max-w-4xl mx-auto bg-[#FFFDF8] border-t-2 border-[#8B5E34] rounded-t-3xl shadow-[0_-12px_40px_rgba(43,36,30,0.35)] flex flex-col max-h-[85vh] sm:max-h-[80vh] overflow-hidden animate-in slide-in-from-bottom duration-300 pb-20"
      >
        {/* Header with Search Bar & Close */}
        <div className="p-4 sm:p-6 border-b border-[#E7DFD2] bg-[#FAF6EE]">
          <div className="flex items-center justify-between gap-3 mb-4">
            <div className="flex items-center gap-2 text-[#3E6B4C]">
              <Search className="w-5 h-5" />
              <h2 className="font-serif font-bold text-lg text-[#2B241E]">
                Search College Library Catalog
              </h2>
            </div>
            <button
              onClick={onClose}
              aria-label="Close search"
              className="p-1.5 rounded-full text-[#6B6055] hover:text-[#2B241E] hover:bg-[#E7DFD2] transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Search Input */}
          <div className="relative">
            <Search className="w-5 h-5 text-[#8B5E34] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by title, author, genre, ISBN, tags, or topic..."
              className="w-full pl-11 pr-10 py-3 bg-[#FFFDF8] border border-[#D5CABE] rounded-xl text-[#2B241E] placeholder:text-[#6B6055]/70 focus:outline-none focus:ring-2 focus:ring-[#3E6B4C] focus:border-transparent text-sm sm:text-base shadow-xs"
            />
            {query && (
              <button
                onClick={() => setQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#6B6055] hover:text-[#2B241E] p-1 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Filters Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 mt-3 pt-2 text-xs sm:text-sm">
            <div className="flex items-center gap-2 overflow-x-auto py-1 max-w-full">
              <Filter className="w-3.5 h-3.5 text-[#6B6055] shrink-0" />
              <span className="text-[#6B6055] shrink-0 font-medium">Genre:</span>
              <select
                value={selectedGenre}
                onChange={(e) => setSelectedGenre(e.target.value)}
                className="bg-[#FFFDF8] border border-[#D5CABE] rounded-lg px-2.5 py-1 text-[#2B241E] focus:outline-none focus:ring-1 focus:ring-[#3E6B4C] text-xs cursor-pointer"
              >
                <option value="all">All Genres</option>
                {genres.filter(g => g !== 'all').map(g => (
                  <option key={g} value={g}>{g}</option>
                ))}
              </select>

              {/* Available Copies Filter */}
              <label className="flex items-center gap-1.5 ml-2 cursor-pointer select-none text-xs font-medium text-[#2B241E]">
                <input
                  type="checkbox"
                  checked={availableOnly}
                  onChange={(e) => setAvailableOnly(e.target.checked)}
                  className="rounded text-[#3E6B4C] focus:ring-[#3E6B4C] border-[#D5CABE]"
                />
                <span>Available copies only</span>
              </label>
            </div>

            {/* Live Count */}
            <div className="text-xs text-[#6B6055] font-medium">
              {results.length} {results.length === 1 ? 'book found' : 'books found'}
            </div>
          </div>
        </div>

        {/* Results List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 divide-y divide-[#E7DFD2]">
          {results.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {results.map((book: Book) => (
                <div
                  key={book.bookId}
                  onClick={() => {
                    onSelectBook(book.bookId);
                    onClose();
                  }}
                  className="flex gap-4 p-3.5 rounded-xl border border-[#E7DFD2] bg-[#FFFDF8] hover:border-[#3E6B4C]/40 hover:bg-[#FAF6EE] transition-all cursor-pointer group shadow-xs"
                >
                  <BookCover book={book} size="sm" />
                  <div className="flex-1 flex flex-col justify-between min-w-0">
                    <div>
                      <div className="flex items-center gap-1.5 mb-1">
                        <span className="text-[10px] uppercase tracking-wider font-semibold text-[#8B5E34] bg-[#FAF6EE] px-1.5 py-0.5 rounded border border-[#E7DFD2]">
                          {book.genre}
                        </span>
                        <span className="text-[10px] font-mono text-[#6B6055]">
                          {book.shelf}
                        </span>
                      </div>
                      <h4 className="font-serif font-bold text-sm text-[#2B241E] group-hover:text-[#3E6B4C] transition-colors line-clamp-1">
                        {book.title}
                      </h4>
                      <p className="text-xs text-[#6B6055] line-clamp-1 mb-1.5">
                        {book.author} ({book.publicationYear})
                      </p>
                      <p className="text-xs text-[#6B6055]/90 line-clamp-2 leading-relaxed">
                        {book.description}
                      </p>
                    </div>

                    <div className="mt-2 pt-2 border-t border-[#E7DFD2]/60 flex items-center justify-between">
                      <StatusBadge book={book} size="sm" showDetails={true} />
                      <span className="text-[11px] text-[#3E6B4C] font-semibold group-hover:underline">
                        View details →
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-12 text-center">
              <BookOpen className="w-10 h-10 text-[#8B5E34]/40 mx-auto mb-3" />
              <h3 className="font-serif font-bold text-base text-[#2B241E]">
                No books matched your search
              </h3>
              <p className="text-sm text-[#6B6055] max-w-md mx-auto mt-1">
                Try searching for a different keyword or removing some filters. You can also request that the library acquire this title.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
