import React, { useState } from 'react';
import { Sparkles, X, ArrowRight, Library, HelpCircle, BookPlus } from 'lucide-react';
import { recommendBooks } from '../services/recommend';
import { RecommendationResult, Book } from '../types';
import { BookCover } from './BookCover';
import { StatusBadge } from './StatusBadge';

interface AIBookFinderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectBook: (bookId: string) => void;
  onRequestBook: (title: string, author?: string) => void;
}

const EXAMPLE_PROMPTS = [
  "Mind-bending sci-fi with pirates",
  "Something like Harry Potter but darker",
  "A short philosophical book that's easy to read",
  "Find me something mysterious and atmospheric",
  "I want a fast-paced thriller with psychological twists",
  "Inspiring biography about resilience",
];

export const AIBookFinderModal: React.FC<AIBookFinderModalProps> = ({
  isOpen,
  onClose,
  onSelectBook,
  onRequestBook,
}) => {
  const [query, setQuery] = useState('');
  const [searchedQuery, setSearchedQuery] = useState('');
  const [inLibraryResults, setInLibraryResults] = useState<RecommendationResult[]>([]);
  const [notInLibraryResults, setNotInLibraryResults] = useState<RecommendationResult[]>([]);
  const [hasSearched, setHasSearched] = useState(false);

  const handleRecommend = (searchPrompt: string) => {
    const text = searchPrompt.trim();
    if (!text) return;

    setQuery(text);
    setSearchedQuery(text);
    const { inLibrary, notInLibrary } = recommendBooks(text);
    setInLibraryResults(inLibrary);
    setNotInLibraryResults(notInLibrary);
    setHasSearched(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleRecommend(query);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        id="ai-book-finder-modal"
        role="dialog"
        aria-label="AI Book Finder Reading Assistant"
        className="w-full max-w-3xl bg-[#FFFDF8] border-2 border-[#3E6B4C]/40 rounded-3xl shadow-[0_20px_50px_rgba(43,36,30,0.4)] flex flex-col max-h-[90vh] overflow-hidden animate-in zoom-in-95 duration-200"
      >
        {/* Header */}
        <div className="p-5 sm:p-6 bg-gradient-to-r from-[#E4EEE6] via-[#FAF6EE] to-[#FAF6EE] border-b border-[#E7DFD2]">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-[#3E6B4C] flex items-center justify-center text-[#FAF6EE] shadow-sm">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h2 className="font-serif font-bold text-lg sm:text-xl text-[#2B241E]">
                  AI Book Finder
                </h2>
                <p className="text-xs sm:text-sm text-[#3E6B4C] font-medium">
                  Natural-language discovery layer for your college collection
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              aria-label="Close assistant"
              className="p-1.5 rounded-full text-[#6B6055] hover:text-[#2B241E] hover:bg-[#E7DFD2] transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="mt-4">
            <div className="flex gap-2">
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Describe a feeling, plot idea, trope, or comp title (e.g. 'mind-bending sci-fi with pirates')..."
                className="flex-1 px-4 py-3 bg-[#FFFDF8] border border-[#D5CABE] rounded-xl text-sm sm:text-base text-[#2B241E] placeholder:text-[#6B6055]/70 focus:outline-none focus:ring-2 focus:ring-[#3E6B4C]"
              />
              <button
                type="submit"
                className="px-5 py-3 bg-[#3E6B4C] hover:bg-[#2B4B34] text-[#FAF6EE] font-semibold text-sm rounded-xl flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer shrink-0"
              >
                <span>Find</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>

          {/* Example prompt pills */}
          <div className="mt-3">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-[#6B6055] block mb-1.5">
              Try an example prompt:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {EXAMPLE_PROMPTS.map((prompt) => (
                <button
                  key={prompt}
                  type="button"
                  onClick={() => handleRecommend(prompt)}
                  className="text-xs px-2.5 py-1 rounded-full bg-white/80 hover:bg-[#3E6B4C] hover:text-white text-[#2B241E] border border-[#D5CABE] transition-all cursor-pointer font-medium"
                >
                  {prompt}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Results Container */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">
          {!hasSearched ? (
            <div className="py-12 text-center text-[#6B6055]">
              <Sparkles className="w-12 h-12 text-[#3E6B4C]/40 mx-auto mb-3" />
              <h3 className="font-serif font-bold text-base text-[#2B241E]">
                Tell me what you are in the mood for
              </h3>
              <p className="text-xs sm:text-sm max-w-md mx-auto mt-1 leading-relaxed">
                Describe a mood, a favorite book or author, a complex genre mix, or a specific reading vibe. The assistant cross-references canonical library tags and physical shelf availability.
              </p>
            </div>
          ) : (
            <>
              {/* Group 1: In Library */}
              <section aria-labelledby="in-library-heading">
                <div className="flex items-center gap-2 pb-2 border-b border-[#E7DFD2] mb-3">
                  <Library className="w-4 h-4 text-[#3E6B4C]" />
                  <h3 id="in-library-heading" className="font-serif font-bold text-base text-[#2B241E]">
                    Books in your library
                  </h3>
                  <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-[#E4EEE6] text-[#3E6B4C]">
                    {inLibraryResults.length} available to borrow
                  </span>
                </div>

                {inLibraryResults.length > 0 ? (
                  <div className="space-y-3">
                    {inLibraryResults.map((result) => {
                      const book = result.book as Book;
                      return (
                        <div
                          key={book.bookId}
                          onClick={() => {
                            onSelectBook(book.bookId);
                            onClose();
                          }}
                          className="flex gap-4 p-3.5 rounded-xl border border-[#E7DFD2] bg-[#FFFDF8] hover:border-[#3E6B4C] hover:bg-[#FAF6EE] transition-all cursor-pointer group shadow-xs"
                        >
                          <BookCover book={book} size="sm" />
                          <div className="flex-1 flex flex-col justify-between min-w-0">
                            <div>
                              <div className="flex items-center gap-2 mb-1">
                                <span className="text-[10px] uppercase font-bold text-[#8B5E34] bg-[#FAF6EE] px-1.5 py-0.5 rounded border border-[#E7DFD2]">
                                  {book.genre}
                                </span>
                                <span className="text-[11px] font-medium text-[#3E6B4C] italic">
                                  {result.reason}
                                </span>
                              </div>
                              <h4 className="font-serif font-bold text-sm sm:text-base text-[#2B241E] group-hover:text-[#3E6B4C] transition-colors line-clamp-1">
                                {book.title}
                              </h4>
                              <p className="text-xs text-[#6B6055] line-clamp-1 mb-1">
                                {book.author} ({book.publicationYear})
                              </p>
                              <p className="text-xs text-[#6B6055]/90 line-clamp-2 leading-relaxed">
                                {book.description}
                              </p>
                            </div>

                            <div className="mt-2 pt-2 border-t border-[#E7DFD2]/60 flex items-center justify-between">
                              <StatusBadge book={book} size="sm" showDetails={true} />
                              <span className="text-xs font-semibold text-[#3E6B4C] group-hover:underline">
                                View shelf location →
                              </span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="p-4 rounded-xl bg-[#FAF6EE] text-center text-xs text-[#6B6055]">
                    No exact titles in the current collection matched "{searchedQuery}". Check the external suggestions below.
                  </div>
                )}
              </section>

              {/* Group 2: Not in Library */}
              <section aria-labelledby="not-in-library-heading" className="pt-2">
                <div className="flex items-center gap-2 pb-2 border-b border-[#E7DFD2] mb-3">
                  <HelpCircle className="w-4 h-4 text-[#6B6055]" />
                  <h3 id="not-in-library-heading" className="font-serif font-bold text-base text-[#2B241E]">
                    Books you may like — not currently in library
                  </h3>
                  <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-[#E7DFD2] text-[#6B6055]">
                    {notInLibraryResults.length} recommendations
                  </span>
                </div>

                {notInLibraryResults.length > 0 ? (
                  <div className="space-y-3">
                    {notInLibraryResults.map((result) => {
                      const extBook = result.book;
                      return (
                        <div
                          key={extBook.bookId}
                          className="flex gap-4 p-3.5 rounded-xl border border-[#E7DFD2] bg-[#FAF6EE]/60 hover:bg-[#FAF6EE] transition-all"
                        >
                          <BookCover book={extBook} size="sm" />
                          <div className="flex-1 flex flex-col justify-between min-w-0">
                            <div>
                              <div className="flex items-center gap-2 mb-1">
                                <span className="text-[10px] uppercase font-bold text-[#6B6055] bg-white px-1.5 py-0.5 rounded border border-[#E7DFD2]">
                                  {extBook.genre}
                                </span>
                                <span className="text-[11px] font-medium text-[#6B6055] italic">
                                  {result.reason}
                                </span>
                              </div>
                              <h4 className="font-serif font-bold text-sm sm:text-base text-[#2B241E] line-clamp-1">
                                {extBook.title}
                              </h4>
                              <p className="text-xs text-[#6B6055] line-clamp-1 mb-1">
                                {extBook.author} ({extBook.publicationYear})
                              </p>
                              <p className="text-xs text-[#6B6055]/90 line-clamp-2 leading-relaxed">
                                {extBook.description}
                              </p>
                            </div>

                            <div className="mt-2 pt-2 border-t border-[#E7DFD2]/60 flex items-center justify-between">
                              <StatusBadge book={extBook} size="sm" />
                              <button
                                onClick={() => {
                                  onRequestBook(extBook.title, extBook.author);
                                  onClose();
                                }}
                                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#FAF6EE] hover:bg-[#E4EEE6] text-[#3E6B4C] border border-[#3E6B4C]/40 rounded-lg text-xs font-semibold transition-colors cursor-pointer shadow-2xs"
                              >
                                <BookPlus className="w-3.5 h-3.5" />
                                <span>Request this book</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="p-4 rounded-xl bg-[#FAF6EE] text-center text-xs text-[#6B6055]">
                    No external unowned titles matched this criteria.
                  </div>
                )}
              </section>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
