import React from 'react';

interface WoodenBookcaseProps {
  children: React.ReactNode;
  title?: string;
  subtitle?: string;
  badge?: string;
  className?: string;
  headerAction?: React.ReactNode;
}

export const WoodenBookcase: React.FC<WoodenBookcaseProps> = ({
  children,
  title,
  subtitle,
  badge,
  className = '',
  headerAction
}) => {
  return (
    <div 
      className={`relative my-8 sm:my-12 rounded-2xl sm:rounded-3xl shadow-[0_20px_45px_rgba(43,36,30,0.35),0_4px_12px_rgba(0,0,0,0.2)] border-4 border-[#3D2513] overflow-hidden bg-[#E7D6BE] ${className}`}
    >
      {/* Outer Thick Solid Wood Frame Surround (Top Crown Molding) */}
      <div className="bg-gradient-to-b from-[#6A3F1F] via-[#5A3418] to-[#462711] px-5 sm:px-8 py-3.5 sm:py-4 border-b-2 border-[#301A0B] shadow-[inset_0_2px_4px_rgba(255,255,255,0.2),0_4px_10px_rgba(0,0,0,0.35)] flex flex-wrap items-center justify-between gap-3 relative z-20">
        {/* Crown wood grain highlight bevel */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-200/30 via-amber-100/50 to-amber-200/30" />

        <div className="flex items-center gap-3">
          {/* Brass Library Bookcase Plaque */}
          <div className="px-3.5 py-1.5 rounded-lg bg-gradient-to-b from-[#D4AF37] via-[#C5A028] to-[#997A15] border border-[#F5E6CC]/60 shadow-[inset_0_1px_1px_rgba(255,255,255,0.4),0_2px_4px_rgba(0,0,0,0.3)] text-[#2B241E] flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[#5A381E]/60 shadow-xs" />
            <h2 className="font-serif font-bold text-sm sm:text-base tracking-wide uppercase drop-shadow-xs">
              {title || "College Library Bookshelf"}
            </h2>
            <span className="w-1.5 h-1.5 rounded-full bg-[#5A381E]/60 shadow-xs" />
          </div>

          {subtitle && (
            <span className="text-xs sm:text-sm text-[#F5E6CC]/90 font-medium hidden md:inline-block">
              {subtitle}
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          {badge && (
            <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-[#24452F] text-[#B8D8BF] border border-[#3E6B4C]">
              {badge}
            </span>
          )}
          {headerAction}
        </div>
      </div>

      {/* Main Bookcase Body with Thick Vertical Left/Right Wood Pillars */}
      <div className="relative flex">
        
        {/* Thick Left Wood Pillar Column with Brass Peg Insets */}
        <div className="w-4 sm:w-8 md:w-10 bg-gradient-to-r from-[#4E2B14] via-[#5E3619] to-[#3D200E] border-r-2 border-[#2F1709] shadow-[inset_-2px_0_6px_rgba(0,0,0,0.4),2px_0_6px_rgba(0,0,0,0.3)] shrink-0 flex flex-col justify-around py-8 items-center select-none">
          {/* Wood grain striping */}
          <div className="w-full h-full opacity-30 bg-[repeating-linear-gradient(0deg,transparent,transparent_60px,rgba(0,0,0,0.4)_61px,transparent_62px)] flex flex-col justify-around items-center">
            <div className="w-1.5 h-1.5 rounded-full bg-[#1A0B04] shadow-[inset_0_1px_1px_rgba(0,0,0,0.8)]" />
            <div className="w-1.5 h-1.5 rounded-full bg-[#1A0B04] shadow-[inset_0_1px_1px_rgba(0,0,0,0.8)]" />
            <div className="w-1.5 h-1.5 rounded-full bg-[#1A0B04] shadow-[inset_0_1px_1px_rgba(0,0,0,0.8)]" />
            <div className="w-1.5 h-1.5 rounded-full bg-[#1A0B04] shadow-[inset_0_1px_1px_rgba(0,0,0,0.8)]" />
            <div className="w-1.5 h-1.5 rounded-full bg-[#1A0B04] shadow-[inset_0_1px_1px_rgba(0,0,0,0.8)]" />
          </div>
        </div>

        {/* Interior Wood Backing Panel (Warm Oak Backboard behind all shelves) */}
        <div className="flex-1 min-w-0 bg-[#E8D9C2] bg-[radial-gradient(#CBB99F_1px,transparent_1px)] [background-size:16px_16px] relative shadow-[inset_0_0_25px_rgba(43,36,30,0.18)]">
          {/* Deep corner shadows for skeuomorphic depth */}
          <div className="absolute inset-0 pointer-events-none shadow-[inset_6px_6px_18px_rgba(0,0,0,0.15),inset_-6px_6px_18px_rgba(0,0,0,0.15)] z-10" />

          {/* Shelves Content */}
          <div className="relative z-0">
            {children}
          </div>
        </div>

        {/* Thick Right Wood Pillar Column with Brass Peg Insets */}
        <div className="w-4 sm:w-8 md:w-10 bg-gradient-to-l from-[#4E2B14] via-[#5E3619] to-[#3D200E] border-l-2 border-[#2F1709] shadow-[inset_2px_0_6px_rgba(0,0,0,0.4),-2px_0_6px_rgba(0,0,0,0.3)] shrink-0 flex flex-col justify-around py-8 items-center select-none">
          <div className="w-full h-full opacity-30 bg-[repeating-linear-gradient(0deg,transparent,transparent_60px,rgba(0,0,0,0.4)_61px,transparent_62px)] flex flex-col justify-around items-center">
            <div className="w-1.5 h-1.5 rounded-full bg-[#1A0B04] shadow-[inset_0_1px_1px_rgba(0,0,0,0.8)]" />
            <div className="w-1.5 h-1.5 rounded-full bg-[#1A0B04] shadow-[inset_0_1px_1px_rgba(0,0,0,0.8)]" />
            <div className="w-1.5 h-1.5 rounded-full bg-[#1A0B04] shadow-[inset_0_1px_1px_rgba(0,0,0,0.8)]" />
            <div className="w-1.5 h-1.5 rounded-full bg-[#1A0B04] shadow-[inset_0_1px_1px_rgba(0,0,0,0.8)]" />
            <div className="w-1.5 h-1.5 rounded-full bg-[#1A0B04] shadow-[inset_0_1px_1px_rgba(0,0,0,0.8)]" />
          </div>
        </div>

      </div>

      {/* Thick Bottom Baseboard / Plinth */}
      <div className="bg-gradient-to-b from-[#462711] via-[#351C0A] to-[#251206] h-6 sm:h-8 border-t-2 border-[#5A381E] shadow-[inset_0_2px_4px_rgba(0,0,0,0.6)] relative z-20 flex items-center justify-between px-6">
        <div className="w-full h-full opacity-20 bg-[repeating-linear-gradient(90deg,transparent,transparent_40px,rgba(255,255,255,0.2)_41px,transparent_42px)]" />
      </div>
    </div>
  );
};
