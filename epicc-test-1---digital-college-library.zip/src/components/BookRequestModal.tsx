import React, { useState, useEffect } from 'react';
import { BookPlus, X, CheckCircle2, ArrowRight } from 'lucide-react';
import { submitBookRequest } from '../services/requests';

interface BookRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTitle?: string;
  initialAuthor?: string;
}

export const BookRequestModal: React.FC<BookRequestModalProps> = ({
  isOpen,
  onClose,
  initialTitle = '',
  initialAuthor = '',
}) => {
  const [title, setTitle] = useState(initialTitle);
  const [author, setAuthor] = useState(initialAuthor);
  const [note, setNote] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  useEffect(() => {
    setTitle(initialTitle);
    setAuthor(initialAuthor);
    setIsSubmitted(false);
  }, [initialTitle, initialAuthor, isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    submitBookRequest({
      title,
      author: author.trim() || undefined,
      note: note.trim() || undefined
    });

    setIsSubmitted(true);
  };

  const handleReset = () => {
    setTitle('');
    setAuthor('');
    setNote('');
    setIsSubmitted(false);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        id="book-request-modal"
        role="dialog"
        aria-label="Request a Book"
        className="w-full max-w-lg bg-[#FFFDF8] border-2 border-[#8B5E34]/30 rounded-3xl shadow-[0_20px_50px_rgba(43,36,30,0.4)] overflow-hidden animate-in zoom-in-95 duration-200"
      >
        {/* Header */}
        <div className="p-5 sm:p-6 bg-[#FAF6EE] border-b border-[#E7DFD2] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#FAF6EE] border border-[#D5CABE] flex items-center justify-center text-[#B15A3E]">
              <BookPlus className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-serif font-bold text-lg text-[#2B241E]">
                Request a Book
              </h2>
              <p className="text-xs text-[#6B6055]">
                Tell our college librarians what to acquire next
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            aria-label="Close dialog"
            className="p-1.5 rounded-full text-[#6B6055] hover:text-[#2B241E] hover:bg-[#E7DFD2] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form or Confirmation */}
        <div className="p-5 sm:p-6">
          {isSubmitted ? (
            <div className="py-6 text-center space-y-4">
              <div className="w-12 h-12 rounded-full bg-[#E4EEE6] text-[#3E6B4C] flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <div className="space-y-1">
                <h3 className="font-serif font-bold text-lg text-[#2B241E]">
                  Request sent
                </h3>
                <p className="text-sm text-[#6B6055] max-w-sm mx-auto">
                  The librarian can review this request in the collection acquisition queue.
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-[#FAF6EE] border border-[#E7DFD2] text-left text-xs space-y-1">
                <p className="font-semibold text-[#2B241E]">{title}</p>
                {author && <p className="text-[#6B6055]">by {author}</p>}
                {note && <p className="text-[#6B6055] italic">"{note}"</p>}
              </div>

              <button
                onClick={handleReset}
                className="w-full py-2.5 px-4 bg-[#3E6B4C] hover:bg-[#2B4B34] text-[#FAF6EE] rounded-xl text-sm font-semibold transition-colors cursor-pointer"
              >
                Done
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#2B241E] mb-1">
                  Book Title <span className="text-[#B15A3E]">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. The Psychology of Money"
                  className="w-full px-3.5 py-2.5 bg-[#FFFDF8] border border-[#D5CABE] rounded-xl text-sm text-[#2B241E] placeholder:text-[#6B6055]/60 focus:outline-none focus:ring-2 focus:ring-[#3E6B4C]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#2B241E] mb-1">
                  Author <span className="text-[#6B6055] font-normal">(optional)</span>
                </label>
                <input
                  type="text"
                  value={author}
                  onChange={(e) => setAuthor(e.target.value)}
                  placeholder="e.g. Morgan Housel"
                  className="w-full px-3.5 py-2.5 bg-[#FFFDF8] border border-[#D5CABE] rounded-xl text-sm text-[#2B241E] placeholder:text-[#6B6055]/60 focus:outline-none focus:ring-2 focus:ring-[#3E6B4C]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#2B241E] mb-1">
                  Note / Reason <span className="text-[#6B6055] font-normal">(optional)</span>
                </label>
                <textarea
                  rows={3}
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="e.g. Course syllabus reading, research project, or personal interest..."
                  className="w-full px-3.5 py-2.5 bg-[#FFFDF8] border border-[#D5CABE] rounded-xl text-sm text-[#2B241E] placeholder:text-[#6B6055]/60 focus:outline-none focus:ring-2 focus:ring-[#3E6B4C] resize-none"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-sm text-[#6B6055] hover:text-[#2B241E] font-medium cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!title.trim()}
                  className="px-5 py-2.5 bg-[#3E6B4C] hover:bg-[#2B4B34] disabled:opacity-50 text-[#FAF6EE] rounded-xl text-sm font-semibold flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
                >
                  <span>Submit request</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
