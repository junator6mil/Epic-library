import React, { useState, useEffect } from 'react';
import { Bookmark } from 'lucide-react';
import { Book, ExternalBook, WorldBook } from '../types';
import { isBookSaved, toggleSaveBook, subscribeToSavedBooks } from '../services/savedBooks';

interface BookCoverProps {
  book: Book | ExternalBook | WorldBook;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showStatusDot?: boolean;
  showSaveButton?: boolean;
  className?: string;
  onClick?: () => void;
  priority?: boolean;
}

export const BookCover: React.FC<BookCoverProps> = ({
  book,
  size = 'md',
  showStatusDot = false,
  showSaveButton = true,
  className = '',
  onClick
}) => {
  const [imgError, setImgError] = useState(false);
  const [imgLoaded, setImgLoaded] = useState(false);
  const [saved, setSaved] = useState(() => isBookSaved(book.bookId));

  useEffect(() => {
    const unsub = subscribeToSavedBooks(() => {
      setSaved(isBookSaved(book.bookId));
    });
    return unsub;
  }, [book.bookId]);

  const handleToggleSave = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    const next = toggleSaveBook(book as any);
    setSaved(next);
  };

  // Dimensions based on literary standard 1:1.55 aspect ratio
  const sizeClasses = {
    sm: 'w-20 h-32 text-xs',
    md: 'w-28 sm:w-36 h-44 sm:h-56 text-xs',
    lg: 'w-44 sm:w-52 h-68 sm:h-80 text-sm',
    xl: 'w-56 sm:w-64 h-84 sm:h-96 text-base'
  };

  // Check availability status if book is in library
  const isInLibrary = 'availableCopies' in book;
  const isAvailable = isInLibrary && (book as Book).availableCopies > 0;

  // Aesthetic fallback palette generator based on genre/title hash
  const getCoverColor = (title: string, genre: string) => {
    const hash = (title + genre).split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const hues = [
      'bg-[#2C3E50] text-[#ECF0F1]', // Navy
      'bg-[#34495E] text-[#F39C12]', // Dark Slate & Gold
      'bg-[#4A3B32] text-[#F5E6CC]', // Deep Mocha
      'bg-[#1E3A2F] text-[#D4AF37]', // Forest & Gold
      'bg-[#5C241C] text-[#FADBD8]', // Burgundy
      'bg-[#2E4053] text-[#E5E8E8]', // Midnight
      'bg-[#4A235A] text-[#EBDEF0]', // Deep Plum
    ];
    return hues[hash % hues.length];
  };

  return (
    <div
      id={`book-cover-${book.bookId}`}
      onClick={onClick}
      role={onClick ? "button" : undefined}
      tabIndex={onClick ? 0 : undefined}
      onKeyDown={(e) => {
        if (onClick && (e.key === 'Enter' || e.key === ' ')) {
          e.preventDefault();
          onClick();
        }
      }}
      className={`relative group select-none shrink-0 cursor-pointer rounded-[3px] transition-transform duration-200 ease-out hover:-translate-y-2 hover:scale-[1.02] focus:outline-none focus:ring-2 focus:ring-[#3E6B4C] focus:ring-offset-2 ${sizeClasses[size]} ${className}`}
    >
      {/* 3D Book Edge & Spine Shadow */}
      <div className="absolute inset-0 rounded-[3px] shadow-[2px_6px_12px_rgba(0,0,0,0.22),0_1px_3px_rgba(0,0,0,0.15)] group-hover:shadow-[4px_14px_24px_rgba(43,36,30,0.32)] transition-shadow duration-200 overflow-hidden">
        
        {/* Book Spine crease effect */}
        <div className="absolute left-0 top-0 bottom-0 w-[6px] sm:w-[8px] bg-gradient-to-r from-black/35 via-black/15 to-transparent z-10 pointer-events-none" />
        
        {/* Right page edge hint */}
        <div className="absolute right-0 top-0 bottom-0 w-[2px] bg-gradient-to-l from-black/20 to-transparent z-10 pointer-events-none" />

        {/* Top glossy sheen */}
        <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/5 to-white/15 pointer-events-none z-10" />

        {!imgError && book.coverUrl ? (
          <div className="w-full h-full bg-[#E7DFD2] relative">
            <img
              src={book.coverUrl}
              alt={`Cover of ${book.title} by ${book.author}`}
              referrerPolicy="no-referrer"
              loading="lazy"
              onLoad={() => setImgLoaded(true)}
              onError={() => setImgError(true)}
              className={`w-full h-full object-cover rounded-[2px] transition-opacity duration-300 ${
                imgLoaded ? 'opacity-100' : 'opacity-0'
              }`}
            />
            {!imgLoaded && (
              <div className="absolute inset-0 flex items-center justify-center bg-[#E7DFD2] animate-pulse">
                <div className="w-6 h-6 border-2 border-[#8B5E34] border-t-transparent rounded-full animate-spin" />
              </div>
            )}
          </div>
        ) : (
          /* Styled literary foil-embossed fallback cover */
          <div className={`w-full h-full p-3 sm:p-4 flex flex-col justify-between rounded-[2px] ${getCoverColor(book.title, book.genre)} border border-black/20`}>
            <div className="space-y-1">
              <span className="text-[10px] tracking-wider uppercase opacity-75 font-sans block">
                {book.genre}
              </span>
              <h4 className="font-serif font-bold text-xs sm:text-sm line-clamp-3 leading-snug">
                {book.title}
              </h4>
            </div>

            <div className="pt-2 border-t border-current/20 space-y-1">
              <p className="font-sans text-[11px] sm:text-xs opacity-90 line-clamp-1 font-medium">
                {book.author}
              </p>
              {'shelf' in book && (
                <span className="inline-block text-[9px] font-mono px-1.5 py-0.5 rounded bg-black/25 text-white/90">
                  {(book as Book).shelf}
                </span>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Saved Bookmark Ribbon Overlay */}
      {saved && (
        <div 
          className="absolute -top-1 left-2.5 z-30 pointer-events-none drop-shadow-md animate-in fade-in slide-in-from-top-2 duration-150"
          title="Saved to your Reading List"
        >
          <div className="w-4 sm:w-5 h-6 sm:h-7 bg-[#D4AF37] border-t border-[#F5E6CC] flex items-center justify-center text-[#2B241E] shadow-sm [clip-path:polygon(0_0,100%_0,100%_100%,50%_75%,0_100%)]">
            <Bookmark className="w-2.5 sm:w-3 h-2.5 sm:h-3 fill-current text-[#4A3B32] -mt-1" />
          </div>
        </div>
      )}

      {/* Quick Save Hover Action (Desktop hover / touch target) */}
      {showSaveButton && (
        <button
          type="button"
          onClick={handleToggleSave}
          title={saved ? "Remove from Saved for Later" : "Save for Later"}
          aria-label={saved ? "Remove from Saved for Later" : "Save for Later"}
          className={`absolute top-1.5 right-1.5 z-30 p-1.5 rounded-full transition-all duration-150 cursor-pointer shadow-md ${
            saved 
              ? 'bg-[#3E6B4C] text-[#FAF6EE] opacity-100' 
              : 'bg-black/60 hover:bg-[#3E6B4C] text-white opacity-0 group-hover:opacity-100 hover:scale-110'
          }`}
        >
          <Bookmark className={`w-3 h-3 ${saved ? 'fill-current text-[#D4AF37]' : ''}`} />
        </button>
      )}

      {/* Optional subtle status indicator dot */}
      {showStatusDot && isInLibrary && (
        <span
          title={isAvailable ? `Available (${(book as Book).availableCopies} copies)` : 'Currently unavailable'}
          className={`absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full border-2 border-[#FAF6EE] shadow-sm z-20 ${
            isAvailable ? 'bg-[#3E6B4C]' : 'bg-[#B15A3E]'
          }`}
        />
      )}
    </div>
  );
};
