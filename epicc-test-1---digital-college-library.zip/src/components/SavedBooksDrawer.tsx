import React, { useState, useEffect } from 'react';
import { BookmarkCheck, Trash2, X, BookOpen, ExternalLink, Sparkles, ArrowRight } from 'lucide-react';
import { getSavedBooks, removeSavedBook, clearSavedBooks, subscribeToSavedBooks, SavedBookRecord } from '../services/savedBooks';
import { BookCover } from './BookCover';

interface SavedBooksDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectBook: (bookId: string) => void;
}

export const SavedBooksDrawer: React.FC<SavedBooksDrawerProps> = ({
  isOpen,
  onClose,
  onSelectBook
}) => {
  const [savedList, setSavedList] = useState<SavedBookRecord[]>(() => getSavedBooks());
  const [filterGenre, setFilterGenre] = useState<string>('all');

  useEffect(() => {
    if (isOpen) {
      setSavedList(getSavedBooks());
    }
    const unsub = subscribeToSavedBooks(() => {
      setSavedList(getSavedBooks());
    });
    return unsub;
  }, [isOpen]);

  if (!isOpen) return null;

  const genres = ['all', ...Array.from(new Set(savedList.map(item => item.genre)))];
  const filtered = filterGenre === 'all' 
    ? savedList 
    : savedList.filter(item => item.genre === filterGenre);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden flex justify-end">
      {/* Backdrop */}
      <div 
        onClick={onClose} 
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity" 
      />

      {/* Drawer Body */}
      <div className="relative z-10 w-full max-w-xl bg-[#FAF6EE] border-l-4 border-[#3D2513] shadow-2xl h-full flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#4E2B14] via-[#5E3619] to-[#3D200E] p-5 text-[#FAF6EE] flex items-center justify-between shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#D4AF37] text-[#2B241E] flex items-center justify-center shadow-md">
              <BookmarkCheck className="w-5 h-5 fill-current" />
            </div>
            <div>
              <h2 className="font-serif font-bold text-lg text-[#FAF6EE] flex items-center gap-2">
                Saved for Later
                <span className="text-xs font-sans font-normal px-2 py-0.5 rounded-full bg-white/20 text-[#FAF6EE]">
                  {savedList.length} {savedList.length === 1 ? 'book' : 'books'}
                </span>
              </h2>
              <p className="text-xs text-[#E7DFD2]/80 font-sans">
                Personal reading list stored on your device
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {savedList.length > 0 && (
              <button
                onClick={() => {
                  if (window.confirm("Remove all saved books from your list?")) {
                    clearSavedBooks();
                  }
                }}
                className="text-xs text-[#E7DFD2]/80 hover:text-white px-2.5 py-1 rounded hover:bg-white/10 transition-colors"
                title="Clear all saved books"
              >
                Clear all
              </button>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-lg text-[#E7DFD2] hover:text-white hover:bg-white/10 transition-colors"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filter Pills */}
        {genres.length > 2 && (
          <div className="px-5 py-3 border-b border-[#D5CABE] bg-[#F3EDE2] flex items-center gap-1.5 overflow-x-auto no-scrollbar">
            {genres.map(genre => (
              <button
                key={genre}
                onClick={() => setFilterGenre(genre)}
                className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
                  filterGenre === genre
                    ? 'bg-[#3E6B4C] text-[#FAF6EE]'
                    : 'bg-white text-[#6B6055] hover:bg-[#E7DFD2]'
                }`}
              >
                {genre === 'all' ? 'All Saved' : genre}
              </button>
            ))}
          </div>
        )}

        {/* List Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {savedList.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-8 text-[#6B6055]">
              <div className="w-16 h-16 rounded-2xl bg-[#E7DFD2] flex items-center justify-center mb-4 text-[#8B5E34]">
                <BookmarkCheck className="w-8 h-8 opacity-60" />
              </div>
              <h3 className="font-serif font-bold text-lg text-[#2B241E] mb-1">
                Your Reading List is Empty
              </h3>
              <p className="text-sm max-w-sm mb-6 text-[#6B6055]">
                Tap the bookmark icon on any book on campus shelves or in the World Library to save it here for later.
              </p>
              <button
                onClick={onClose}
                className="px-4 py-2 rounded-xl bg-[#3E6B4C] hover:bg-[#2B4B34] text-[#FAF6EE] text-sm font-medium transition-colors shadow-xs flex items-center gap-2"
              >
                <BookOpen className="w-4 h-4" />
                <span>Explore Bookshelf</span>
              </button>
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-12 text-[#6B6055]">
              No saved books in the &quot;{filterGenre}&quot; category.
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-3.5">
              {filtered.map((item) => (
                <div
                  key={item.bookId}
                  onClick={() => {
                    onSelectBook(item.bookId);
                    onClose();
                  }}
                  className="bg-white rounded-xl p-3.5 border border-[#D5CABE] shadow-xs hover:border-[#3E6B4C] hover:shadow-md transition-all flex items-center gap-4 cursor-pointer group relative"
                >
                  {/* Book Mini Cover */}
                  <div className="shrink-0 w-16 h-24 rounded shadow-sm overflow-hidden bg-[#E7DFD2] relative">
                    {item.coverUrl ? (
                      <img 
                        src={item.coverUrl} 
                        alt={item.title}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200" 
                      />
                    ) : (
                      <div className="w-full h-full p-2 bg-[#3D2513] text-amber-100 flex flex-col justify-between text-[8px]">
                        <span className="font-bold line-clamp-2">{item.title}</span>
                        <span className="opacity-80">{item.author}</span>
                      </div>
                    )}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0 pr-8">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded bg-[#E8D9C2] text-[#5A381E]">
                        {item.genre}
                      </span>
                      {item.isWorldBook ? (
                        <span className="text-[10px] font-medium px-2 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-200">
                          World Library
                        </span>
                      ) : (
                        <span className="text-[10px] font-medium px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                          {item.shelf ? `Shelf ${item.shelf}` : 'Campus Library'}
                        </span>
                      )}
                    </div>
                    
                    <h4 className="font-serif font-bold text-sm text-[#2B241E] group-hover:text-[#3E6B4C] transition-colors line-clamp-1">
                      {item.title}
                    </h4>
                    <p className="text-xs text-[#6B6055] line-clamp-1">
                      by {item.author}
                    </p>

                    <p className="text-[11px] text-[#A69C90] mt-1.5">
                      Saved {new Date(item.savedAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                    </p>
                  </div>

                  {/* Remove Button */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      removeSavedBook(item.bookId);
                    }}
                    title="Remove from saved"
                    className="absolute top-3 right-3 p-1.5 rounded-lg text-[#A69C90] hover:text-[#B15A3E] hover:bg-red-50 transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        {savedList.length > 0 && (
          <div className="p-4 border-t border-[#D5CABE] bg-[#F3EDE2] text-xs text-[#6B6055] flex items-center justify-between">
            <span>{savedList.length} items preserved across sessions</span>
            <button
              onClick={onClose}
              className="text-xs font-semibold text-[#3E6B4C] hover:underline"
            >
              Back to Catalog
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
