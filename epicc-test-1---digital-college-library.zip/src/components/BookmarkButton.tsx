import React, { useState, useEffect } from 'react';
import { Bookmark, BookmarkCheck } from 'lucide-react';
import { Book, WorldBook } from '../types';
import { isBookSaved, toggleSaveBook, subscribeToSavedBooks } from '../services/savedBooks';

interface BookmarkButtonProps {
  book: Book | WorldBook | { bookId: string; title: string; author: string; genre: string; coverUrl: string };
  size?: 'sm' | 'md' | 'lg';
  showLabel?: boolean;
  className?: string;
  onToggle?: (isSaved: boolean) => void;
}

export const BookmarkButton: React.FC<BookmarkButtonProps> = ({
  book,
  size = 'md',
  showLabel = false,
  className = '',
  onToggle
}) => {
  const [saved, setSaved] = useState(() => isBookSaved(book.bookId));

  useEffect(() => {
    const unsub = subscribeToSavedBooks(() => {
      setSaved(isBookSaved(book.bookId));
    });
    return unsub;
  }, [book.bookId]);

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    const next = toggleSaveBook(book as any);
    setSaved(next);
    onToggle?.(next);
  };

  const iconSizes = {
    sm: 'w-3.5 h-3.5',
    md: 'w-4 h-4',
    lg: 'w-5 h-5'
  };

  return (
    <button
      type="button"
      onClick={handleClick}
      aria-label={saved ? `Remove "${book.title}" from Saved for Later` : `Save "${book.title}" for later`}
      title={saved ? "Saved to your Reading List (Click to remove)" : "Save for Later"}
      className={`inline-flex items-center gap-1.5 rounded-lg font-medium transition-all duration-150 cursor-pointer ${
        saved
          ? 'bg-[#3E6B4C] text-[#FAF6EE] border border-[#2B4B34] shadow-xs hover:bg-[#32573D]'
          : 'bg-white/90 text-[#6B6055] hover:text-[#2B241E] hover:bg-white border border-[#D5CABE] shadow-xs'
      } ${size === 'sm' ? 'p-1.5 text-xs' : size === 'lg' ? 'px-4 py-2.5 text-sm' : 'px-2.5 py-1.5 text-xs'} ${className}`}
    >
      {saved ? (
        <BookmarkCheck className={`${iconSizes[size]} fill-current text-[#D4AF37]`} />
      ) : (
        <Bookmark className={iconSizes[size]} />
      )}
      {showLabel && (
        <span>{saved ? 'Saved for Later' : 'Save for Later'}</span>
      )}
    </button>
  );
};
