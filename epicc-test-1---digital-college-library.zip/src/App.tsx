import React, { useState, useEffect } from 'react';
import { Book, WorldBook, BookRequest, DemandInsight, ViewMode, StudentRoute } from './types';
import { subscribeToCatalog, getBookById } from './services/catalog';
import { subscribeToRequests } from './services/requests';
import { subscribeToInsights } from './services/insights';
import { getAllCuratedWorldBooks } from './services/worldBooks';
import { Header } from './components/Header';
import { FloatingNav } from './components/FloatingNav';
import { SearchDrawer } from './components/SearchDrawer';
import { AIBookFinderModal } from './components/AIBookFinderModal';
import { BookRequestModal } from './components/BookRequestModal';
import { SavedBooksDrawer } from './components/SavedBooksDrawer';
import { HomePage } from './pages/HomePage';
import { BookDetailPage } from './pages/BookDetailPage';
import { LibrarianDashboard } from './pages/LibrarianDashboard';

export const App: React.FC = () => {
  // Core Subscribed State
  const [books, setBooks] = useState<Book[]>([]);
  const [requests, setRequests] = useState<BookRequest[]>([]);
  const [insights, setInsights] = useState<DemandInsight[]>([]);

  // Navigation & View State
  const [viewMode, setViewMode] = useState<ViewMode>('student');
  const [studentRoute, setStudentRoute] = useState<StudentRoute>({ type: 'home' });

  // Overlays / Modals State
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isAIFinderOpen, setIsAIFinderOpen] = useState(false);
  const [isRequestOpen, setIsRequestOpen] = useState(false);
  const [isSavedDrawerOpen, setIsSavedDrawerOpen] = useState(false);
  const [requestPrefill, setRequestPrefill] = useState<{ title: string; author?: string }>({
    title: '',
    author: ''
  });

  // Subscribe to reactive service stores
  useEffect(() => {
    const unsubCatalog = subscribeToCatalog((latest) => setBooks(latest));
    const unsubRequests = subscribeToRequests((latest) => setRequests(latest));
    const unsubInsights = subscribeToInsights((latest) => setInsights(latest));

    return () => {
      unsubCatalog();
      unsubRequests();
      unsubInsights();
    };
  }, []);

  // Handlers
  const handleSelectBook = (bookId: string) => {
    setViewMode('student');
    setStudentRoute({ type: 'book-detail', bookId });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectWorldBook = (wb: WorldBook) => {
    setViewMode('student');
    setStudentRoute({ type: 'book-detail', bookId: wb.bookId, worldBook: wb });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigateHome = () => {
    setViewMode('student');
    setStudentRoute({ type: 'home' });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenRequest = (title?: string, author?: string) => {
    setRequestPrefill({
      title: title || '',
      author: author || ''
    });
    setIsRequestOpen(true);
  };

  const handleToggleLibrarian = () => {
    setViewMode(prev => prev === 'librarian' ? 'student' : 'librarian');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleScrollToShelves = () => {
    if (studentRoute.type !== 'home') {
      setStudentRoute({ type: 'home' });
      setTimeout(() => {
        const elem = document.getElementById('campus-shelves');
        elem?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      const elem = document.getElementById('campus-shelves');
      elem?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Resolve selected book for detail page (from local catalog or world books)
  const selectedBook = studentRoute.type === 'book-detail' 
    ? (
        studentRoute.worldBook || 
        books.find(b => b.bookId === studentRoute.bookId) || 
        getBookById(studentRoute.bookId) ||
        getAllCuratedWorldBooks().find(b => b.bookId === studentRoute.bookId)
      )
    : undefined;

  return (
    <div className="min-h-screen bg-[#FAF6EE] text-[#2B241E] flex flex-col relative selection:bg-[#E4EEE6] selection:text-[#3E6B4C]">
      
      {/* Top Header */}
      <Header
        isLibrarian={viewMode === 'librarian'}
        onToggleLibrarian={handleToggleLibrarian}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenAIFinder={() => setIsAIFinderOpen(true)}
        onNavigateHome={handleNavigateHome}
        onOpenSavedBooks={() => setIsSavedDrawerOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {viewMode === 'librarian' ? (
          <LibrarianDashboard
            books={books}
            requests={requests}
            insights={insights}
            onSelectBook={handleSelectBook}
            onExitLibrarian={() => setViewMode('student')}
          />
        ) : (
          <>
            {studentRoute.type === 'home' && (
              <HomePage
                books={books}
                onSelectBook={handleSelectBook}
                onSelectWorldBook={handleSelectWorldBook}
                onOpenAIFinder={() => setIsAIFinderOpen(true)}
                onOpenSearch={() => setIsSearchOpen(true)}
                onOpenRequest={(title, author) => handleOpenRequest(title, author)}
                onOpenSavedDrawer={() => setIsSavedDrawerOpen(true)}
              />
            )}

            {studentRoute.type === 'book-detail' && selectedBook && (
              <BookDetailPage
                book={selectedBook}
                allBooks={books}
                onBack={handleNavigateHome}
                onSelectBook={handleSelectBook}
                onRequestBook={(title, author) => handleOpenRequest(title, author)}
              />
            )}

            {studentRoute.type === 'book-detail' && !selectedBook && (
              <div className="max-w-md mx-auto py-24 text-center px-4">
                <h2 className="font-serif font-bold text-xl text-[#2B241E]">
                  Book Not Found
                </h2>
                <p className="text-sm text-[#6B6055] mt-2 mb-6">
                  The requested catalog entry could not be located on the shelves.
                </p>
                <button
                  onClick={handleNavigateHome}
                  className="px-4 py-2 bg-[#3E6B4C] text-[#FAF6EE] rounded-xl text-sm font-semibold cursor-pointer"
                >
                  Return to Library Discovery
                </button>
              </div>
            )}
          </>
        )}
      </main>

      {/* Floating Bottom-Center Control */}
      <FloatingNav
        currentView={studentRoute.type}
        onNavigateHome={handleNavigateHome}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenAIFinder={() => setIsAIFinderOpen(true)}
        onOpenRequest={() => handleOpenRequest()}
        onToggleLibrarian={handleToggleLibrarian}
        isLibrarian={viewMode === 'librarian'}
        onScrollToShelves={handleScrollToShelves}
        onOpenSavedBooks={() => setIsSavedDrawerOpen(true)}
      />

      {/* Overlays / Modals */}
      <SearchDrawer
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectBook={handleSelectBook}
      />

      <AIBookFinderModal
        isOpen={isAIFinderOpen}
        onClose={() => setIsAIFinderOpen(false)}
        onSelectBook={handleSelectBook}
        onRequestBook={(title, author) => handleOpenRequest(title, author)}
      />

      <BookRequestModal
        isOpen={isRequestOpen}
        onClose={() => setIsRequestOpen(false)}
        initialTitle={requestPrefill.title}
        initialAuthor={requestPrefill.author}
      />

      <SavedBooksDrawer
        isOpen={isSavedDrawerOpen}
        onClose={() => setIsSavedDrawerOpen(false)}
        onSelectBook={handleSelectBook}
        onSelectWorldBook={handleSelectWorldBook}
        onRequestBook={(title, author) => handleOpenRequest(title, author)}
      />

    </div>
  );
};

export default App;
