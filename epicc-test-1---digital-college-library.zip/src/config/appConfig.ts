// Application Configuration & Branding
// "EPICC TEST 1" is stored as a single config value so it is trivial to rename later.
export const APP_CONFIG = {
  appName: "EPICC TEST 1",
  librarySubtitle: "College Library Discovery Platform",
  institutionName: "College Library Athenaeum",
  welcomeLine: "Step into your college library. Browse physical shelves, locate call numbers, or discover your next read.",
  version: "1.0.0-prototype",
  callNumberPrefix: "COL-LIB",
  defaultFloor: "Main Library Level 2",
};
