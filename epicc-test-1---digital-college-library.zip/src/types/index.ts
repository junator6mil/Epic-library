// Core Data Types for EPICC TEST 1 Digital College Library

export interface Book {
  bookId: string;
  isbn: string;
  title: string;
  author: string;
  genre: string;
  description: string;
  coverUrl: string;
  publisher: string;
  publicationYear: number;
  pages: number;
  totalCopies: number;
  availableCopies: number;
  shelf: string;      // e.g. "F-12"
  section: string;    // e.g. "Fiction"
  tags: string[];
}

export interface ExternalBook extends Omit<Book, 'totalCopies' | 'availableCopies' | 'shelf' | 'section'> {
  // books the AI can suggest that are NOT owned by the library
}

export interface BookRequest {
  id: string;
  title: string;
  author?: string;
  note?: string;
  submittedAt: string;
  status?: 'pending' | 'in-review' | 'cataloged' | 'acquired';
}

export interface RecommendationResult {
  book: Book | ExternalBook | WorldBook;
  inLibrary: boolean;
  matchedTags: string[];
  reason: string;   // short human-readable explanation
  score: number;
}

export interface DemandInsight {
  title: string;
  author?: string;
  genre: string;
  requestCount: number;
  uniqueRequesterEstimate: number;
  searchCount: number;
  inLibrary: boolean;
  signal: 'Frequently requested' | 'Frequently searched' | 'High student interest';
  similarInCatalog?: string;
}

export interface WorldBook {
  bookId: string;
  isbn: string;
  title: string;
  author: string;
  genre: string;
  description: string;
  coverUrl: string;
  publisher?: string;
  publicationYear: number;
  pages?: number;
  tags: string[];
  openLibraryKey?: string;
  editionCount?: number;
  firstPublishYear?: number;
  subjects?: string[];
  inLibrary?: boolean;
  libraryBook?: Book;
}

export type ViewMode = 'student' | 'librarian';

export type StudentRoute = 
  | { type: 'home' }
  | { type: 'book-detail'; bookId: string; worldBook?: WorldBook }
  | { type: 'genre-browse'; genre: string };

export type LibrarianTab = 'catalog' | 'upload' | 'requests' | 'insights';

export interface SearchFilters {
  genre?: string;
  author?: string;
  availableOnly?: boolean;
}
