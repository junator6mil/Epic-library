import React, { useState, useMemo } from 'react';
import { 
  Book, 
  BookRequest, 
  DemandInsight, 
  LibrarianTab 
} from '../types';
import { 
  updateCopies, 
  addBook, 
  updateBook, 
  deleteBook 
} from '../services/catalog';
import { parseCatalogFile, applyCatalogImport } from '../services/importCatalog';
import { updateRequestStatus } from '../services/requests';
import { StatusBadge } from '../components/StatusBadge';
import { BookCover } from '../components/BookCover';
import { 
  Library, 
  UploadCloud, 
  MessageSquareQuote, 
  TrendingUp, 
  Plus, 
  Edit3, 
  Trash2, 
  Search, 
  Check, 
  AlertTriangle, 
  CheckCircle2, 
  FileSpreadsheet, 
  RefreshCw,
  Users,
  Eye,
  SlidersHorizontal
} from 'lucide-react';
import { APP_CONFIG } from '../config/appConfig';

interface LibrarianDashboardProps {
  books: Book[];
  requests: BookRequest[];
  insights: DemandInsight[];
  onSelectBook: (bookId: string) => void;
  onExitLibrarian: () => void;
}

export const LibrarianDashboard: React.FC<LibrarianDashboardProps> = ({
  books,
  requests,
  insights,
  onSelectBook,
  onExitLibrarian,
}) => {
  const [activeTab, setActiveTab] = useState<LibrarianTab>('catalog');
  
  // Catalog Management State
  const [catalogSearch, setCatalogSearch] = useState('');
  const [genreFilter, setGenreFilter] = useState('all');
  const [editingBookId, setEditingBookId] = useState<string | null>(null);
  const [editTotal, setEditTotal] = useState<number>(1);
  const [editAvail, setEditAvail] = useState<number>(1);
  
  // Add/Edit Book Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalBook, setModalBook] = useState<Partial<Book>>({
    title: '',
    author: '',
    genre: 'Fiction',
    description: '',
    isbn: '',
    publisher: 'College Library Press',
    publicationYear: new Date().getFullYear(),
    pages: 300,
    totalCopies: 3,
    availableCopies: 2,
    shelf: 'F-01',
    section: 'Fiction',
    tags: ['fiction', 'literary']
  });

  // CSV Upload State
  const [isDragging, setIsDragging] = useState(false);
  const [parsedRows, setParsedRows] = useState<Partial<Book>[]>([]);
  const [parseErrors, setParseErrors] = useState<string[]>([]);
  const [uploadedFileName, setUploadedFileName] = useState<string>('');
  const [importSuccess, setImportSuccess] = useState<string | null>(null);
  const [isParsing, setIsParsing] = useState(false);

  // Filtered Catalog
  const filteredCatalog = useMemo(() => {
    return books.filter(b => {
      const matchSearch = 
        !catalogSearch || 
        b.title.toLowerCase().includes(catalogSearch.toLowerCase()) ||
        b.author.toLowerCase().includes(catalogSearch.toLowerCase()) ||
        b.isbn.includes(catalogSearch) ||
        b.shelf.toLowerCase().includes(catalogSearch.toLowerCase());
      
      const matchGenre = genreFilter === 'all' || b.genre.toLowerCase() === genreFilter.toLowerCase();
      return matchSearch && matchGenre;
    });
  }, [books, catalogSearch, genreFilter]);

  const allGenres = useMemo(() => {
    return ['all', ...Array.from(new Set(books.map(b => b.genre)))];
  }, [books]);

  // Handle Quick Inline Copy Edit
  const handleStartEdit = (book: Book) => {
    setEditingBookId(book.bookId);
    setEditTotal(book.totalCopies);
    setEditAvail(book.availableCopies);
  };

  const handleSaveCopies = (bookId: string) => {
    updateCopies(bookId, editTotal, editAvail);
    setEditingBookId(null);
  };

  // Handle Add/Edit Submit
  const handleSaveBook = (e: React.FormEvent) => {
    e.preventDefault();
    if (!modalBook.title) return;

    if (modalBook.bookId) {
      updateBook(modalBook as Book);
    } else {
      addBook(modalBook as Omit<Book, 'bookId'>);
    }

    setIsModalOpen(false);
  };

  // Handle CSV Upload
  const handleFileUpload = async (file: File) => {
    setIsParsing(true);
    setUploadedFileName(file.name);
    setImportSuccess(null);

    const { rows, errors } = await parseCatalogFile(file);
    setParsedRows(rows);
    setParseErrors(errors);
    setIsParsing(false);
  };

  const handleConfirmImport = () => {
    if (parsedRows.length === 0) return;
    const { addedCount, updatedCount } = applyCatalogImport(parsedRows);
    setImportSuccess(`Successfully imported ${addedCount} new titles and updated ${updatedCount} existing records.`);
    setParsedRows([]);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-10 pb-36 animate-in fade-in duration-300">
      
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#FFFDF8] border border-[#E7DFD2] p-5 sm:p-6 rounded-2xl shadow-xs mb-8">
        <div>
          <div className="flex items-center gap-2 text-[#3E6B4C] text-xs font-bold uppercase tracking-wider mb-1">
            <Library className="w-4 h-4" />
            <span>Staff Administration Interface</span>
          </div>
          <h1 className="font-serif font-bold text-2xl text-[#2B241E]">
            Librarian Collection Management
          </h1>
          <p className="text-xs sm:text-sm text-[#6B6055] mt-1">
            Manage physical copies, import batch records, review student acquisition requests, and monitor demand signals.
          </p>
        </div>

        <button
          onClick={onExitLibrarian}
          className="px-4 py-2 bg-[#FAF6EE] hover:bg-[#E7DFD2] text-[#2B241E] border border-[#D5CABE] rounded-xl text-xs sm:text-sm font-semibold transition-colors cursor-pointer shrink-0 self-start sm:self-center"
        >
          Return to Student View
        </button>
      </div>

      {/* Navigation Subtabs */}
      <div className="flex flex-wrap gap-2 border-b border-[#E7DFD2] pb-3 mb-6">
        <button
          onClick={() => setActiveTab('catalog')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
            activeTab === 'catalog'
              ? 'bg-[#3E6B4C] text-[#FAF6EE] shadow-xs'
              : 'bg-[#FFFDF8] text-[#6B6055] hover:text-[#2B241E] border border-[#E7DFD2]'
          }`}
        >
          <Library className="w-4 h-4" />
          <span>Catalog Inventory ({books.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('upload')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
            activeTab === 'upload'
              ? 'bg-[#3E6B4C] text-[#FAF6EE] shadow-xs'
              : 'bg-[#FFFDF8] text-[#6B6055] hover:text-[#2B241E] border border-[#E7DFD2]'
          }`}
        >
          <UploadCloud className="w-4 h-4" />
          <span>Batch CSV Import</span>
        </button>

        <button
          onClick={() => setActiveTab('requests')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
            activeTab === 'requests'
              ? 'bg-[#3E6B4C] text-[#FAF6EE] shadow-xs'
              : 'bg-[#FFFDF8] text-[#6B6055] hover:text-[#2B241E] border border-[#E7DFD2]'
          }`}
        >
          <MessageSquareQuote className="w-4 h-4" />
          <span>Student Requests ({requests.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('insights')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
            activeTab === 'insights'
              ? 'bg-[#3E6B4C] text-[#FAF6EE] shadow-xs'
              : 'bg-[#FFFDF8] text-[#6B6055] hover:text-[#2B241E] border border-[#E7DFD2]'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>Demand & Acquisition Insights ({insights.length})</span>
        </button>
      </div>

      {/* --- SUBTAB 1: CATALOG MANAGEMENT --- */}
      {activeTab === 'catalog' && (
        <div className="space-y-6">
          {/* Controls Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#FFFDF8] p-4 rounded-xl border border-[#E7DFD2]">
            <div className="flex flex-1 items-center gap-3">
              <div className="relative flex-1 max-w-md">
                <Search className="w-4 h-4 text-[#8B5E34] absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={catalogSearch}
                  onChange={(e) => setCatalogSearch(e.target.value)}
                  placeholder="Search catalog inventory..."
                  className="w-full pl-9 pr-3 py-1.5 bg-[#FAF6EE] border border-[#D5CABE] rounded-lg text-xs sm:text-sm text-[#2B241E] focus:outline-none focus:ring-1 focus:ring-[#3E6B4C]"
                />
              </div>

              <select
                value={genreFilter}
                onChange={(e) => setGenreFilter(e.target.value)}
                className="bg-[#FAF6EE] border border-[#D5CABE] rounded-lg px-2.5 py-1.5 text-xs text-[#2B241E] focus:outline-none"
              >
                {allGenres.map(g => (
                  <option key={g} value={g}>{g === 'all' ? 'All Genres' : g}</option>
                ))}
              </select>
            </div>

            <button
              onClick={() => {
                setModalBook({
                  title: '',
                  author: '',
                  genre: 'Fiction',
                  description: '',
                  isbn: `978${Math.floor(1000000000 + Math.random() * 9000000000)}`,
                  publisher: 'University Press',
                  publicationYear: 2024,
                  pages: 320,
                  totalCopies: 3,
                  availableCopies: 2,
                  shelf: 'F-20',
                  section: 'Fiction',
                  tags: ['fiction', 'student-interest']
                });
                setIsModalOpen(true);
              }}
              className="flex items-center gap-1.5 px-3.5 py-1.5 bg-[#3E6B4C] hover:bg-[#2B4B34] text-[#FAF6EE] rounded-lg text-xs font-semibold transition-colors cursor-pointer shrink-0 shadow-2xs"
            >
              <Plus className="w-4 h-4" />
              <span>Add Book to Catalog</span>
            </button>
          </div>

          {/* Catalog Table */}
          <div className="bg-[#FFFDF8] rounded-2xl border border-[#E7DFD2] overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs sm:text-sm divide-y divide-[#E7DFD2]">
                <thead className="bg-[#FAF6EE] text-[#6B6055] font-semibold">
                  <tr>
                    <th className="py-3 px-4">Title & Author</th>
                    <th className="py-3 px-4">Genre & Section</th>
                    <th className="py-3 px-4">Shelf / Call No.</th>
                    <th className="py-3 px-4">Physical Copies</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E7DFD2] text-[#2B241E]">
                  {filteredCatalog.map(book => (
                    <tr key={book.bookId} className="hover:bg-[#FAF6EE]/50 transition-colors">
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <BookCover book={book} size="sm" className="hidden sm:block" />
                          <div>
                            <span 
                              onClick={() => onSelectBook(book.bookId)}
                              className="font-serif font-bold text-sm text-[#2B241E] hover:text-[#3E6B4C] cursor-pointer block line-clamp-1"
                            >
                              {book.title}
                            </span>
                            <span className="text-xs text-[#6B6055]">{book.author} ({book.publicationYear})</span>
                            <span className="text-[10px] font-mono text-[#6B6055] block sm:hidden">ISBN: {book.isbn}</span>
                          </div>
                        </div>
                      </td>

                      <td className="py-3 px-4">
                        <span className="inline-block uppercase font-bold text-[10px] text-[#8B5E34] bg-[#FAF6EE] px-2 py-0.5 rounded border border-[#E7DFD2]">
                          {book.genre}
                        </span>
                        <span className="text-xs text-[#6B6055] block mt-0.5">{book.section}</span>
                      </td>

                      <td className="py-3 px-4">
                        <span className="font-mono font-bold text-xs bg-white px-2 py-1 rounded border border-[#D5CABE] text-[#3E6B4C]">
                          {book.shelf}
                        </span>
                      </td>

                      <td className="py-3 px-4">
                        {editingBookId === book.bookId ? (
                          <div className="flex items-center gap-1">
                            <input
                              type="number"
                              min="0"
                              max={editTotal}
                              value={editAvail}
                              onChange={(e) => setEditAvail(parseInt(e.target.value) || 0)}
                              className="w-12 px-1 py-0.5 border border-[#3E6B4C] rounded text-xs text-center"
                              title="Available copies"
                            />
                            <span>/</span>
                            <input
                              type="number"
                              min="1"
                              value={editTotal}
                              onChange={(e) => setEditTotal(parseInt(e.target.value) || 1)}
                              className="w-12 px-1 py-0.5 border border-[#3E6B4C] rounded text-xs text-center"
                              title="Total copies"
                            />
                            <button
                              onClick={() => handleSaveCopies(book.bookId)}
                              className="p-1 bg-[#3E6B4C] text-white rounded hover:bg-[#2B4B34]"
                              title="Save copy counts"
                            >
                              <Check className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : (
                          <div 
                            onClick={() => handleStartEdit(book)}
                            className="inline-flex items-center gap-1.5 cursor-pointer hover:text-[#3E6B4C] font-semibold text-xs py-1 px-2 rounded hover:bg-[#FAF6EE]"
                            title="Click to adjust copies"
                          >
                            <span>{book.availableCopies} available of {book.totalCopies} total</span>
                            <Edit3 className="w-3 h-3 text-[#6B6055]" />
                          </div>
                        )}
                      </td>

                      <td className="py-3 px-4">
                        <StatusBadge book={book} size="sm" />
                      </td>

                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => {
                              setModalBook(book);
                              setIsModalOpen(true);
                            }}
                            className="p-1.5 text-[#6B6055] hover:text-[#3E6B4C] hover:bg-[#FAF6EE] rounded cursor-pointer"
                            title="Edit book details"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => {
                              if (confirm(`Delete "${book.title}" from library catalog?`)) {
                                deleteBook(book.bookId);
                              }
                            }}
                            className="p-1.5 text-[#6B6055] hover:text-[#B15A3E] hover:bg-[#FAF6EE] rounded cursor-pointer"
                            title="Delete book"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* --- SUBTAB 2: BATCH CSV IMPORT --- */}
      {activeTab === 'upload' && (
        <div className="space-y-6">
          <div className="bg-[#FFFDF8] rounded-2xl border border-[#E7DFD2] p-6 sm:p-8">
            <h2 className="font-serif font-bold text-lg text-[#2B241E] mb-1">
              Upload Catalog Data
            </h2>
            <p className="text-xs sm:text-sm text-[#6B6055] mb-6">
              Batch import or update physical book inventory. Tolerantly maps header variations (e.g. `book_id`, `isbn`, `title`, `author`, `genre`, `total_copies`, `available_copies`, `shelf`, `section`, `tags`).
            </p>

            {/* Drop Zone */}
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={(e) => {
                e.preventDefault();
                setIsDragging(false);
                if (e.dataTransfer.files?.[0]) {
                  handleFileUpload(e.dataTransfer.files[0]);
                }
              }}
              className={`border-2 border-dashed rounded-2xl p-8 text-center transition-all cursor-pointer ${
                isDragging
                  ? 'border-[#3E6B4C] bg-[#E4EEE6]/50'
                  : 'border-[#D5CABE] bg-[#FAF6EE]/50 hover:bg-[#FAF6EE]'
              }`}
            >
              <FileSpreadsheet className="w-12 h-12 text-[#8B5E34] mx-auto mb-3" />
              <h3 className="font-serif font-bold text-base text-[#2B241E]">
                Drag and drop your catalog CSV here
              </h3>
              <p className="text-xs text-[#6B6055] mt-1 mb-4">
                Supports CSV with UTF-8 encoding
              </p>

              <label className="inline-flex items-center gap-2 px-4 py-2 bg-[#3E6B4C] hover:bg-[#2B4B34] text-[#FAF6EE] rounded-xl text-xs sm:text-sm font-semibold transition-colors cursor-pointer shadow-xs">
                <UploadCloud className="w-4 h-4" />
                <span>Browse Files</span>
                <input
                  type="file"
                  accept=".csv,.txt"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files?.[0]) {
                      handleFileUpload(e.target.files[0]);
                    }
                  }}
                />
              </label>
            </div>

            {/* Sample CSV Format Template Helper */}
            <div className="mt-4 p-3.5 rounded-xl bg-[#FAF6EE] border border-[#E7DFD2] text-xs text-[#6B6055]">
              <span className="font-semibold text-[#2B241E]">Sample CSV header format: </span>
              <code className="font-mono text-[11px] bg-white px-1 py-0.5 rounded border border-[#D5CABE] text-[#8B5E34]">
                isbn,title,author,genre,description,publisher,year,pages,total_copies,available_copies,shelf,section,tags
              </code>
            </div>

            {/* Parsing State */}
            {isParsing && (
              <div className="mt-6 flex items-center justify-center gap-2 text-sm text-[#3E6B4C] font-semibold py-4">
                <RefreshCw className="w-5 h-5 animate-spin" />
                <span>Parsing catalog structure...</span>
              </div>
            )}

            {/* Import Success Alert */}
            {importSuccess && (
              <div className="mt-6 p-4 rounded-xl bg-[#E4EEE6] border border-[#B8D8BF] text-[#24452F] flex items-center gap-3 text-sm">
                <CheckCircle2 className="w-5 h-5 text-[#3E6B4C] shrink-0" />
                <span className="font-semibold">{importSuccess}</span>
              </div>
            )}

            {/* Validation Errors */}
            {parseErrors.length > 0 && (
              <div className="mt-6 p-4 rounded-xl bg-[#F3E3DC] border border-[#E8C7BC] text-[#6E2E1D] space-y-2">
                <div className="flex items-center gap-2 font-bold text-xs uppercase tracking-wider">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Validation Notices ({parseErrors.length})</span>
                </div>
                <ul className="list-disc list-inside text-xs space-y-1">
                  {parseErrors.map((err, i) => (
                    <li key={i}>{err}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Parsed Rows Preview */}
            {parsedRows.length > 0 && (
              <div className="mt-8 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-serif font-bold text-base text-[#2B241E]">
                    Preview Parsed Records ({parsedRows.length} rows ready)
                  </h3>
                  <button
                    onClick={handleConfirmImport}
                    className="px-5 py-2.5 bg-[#3E6B4C] hover:bg-[#2B4B34] text-[#FAF6EE] rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Confirm & Merge into Catalog</span>
                  </button>
                </div>

                <div className="border border-[#E7DFD2] rounded-xl overflow-x-auto max-h-72">
                  <table className="w-full text-left text-xs divide-y divide-[#E7DFD2]">
                    <thead className="bg-[#FAF6EE] text-[#6B6055] font-semibold sticky top-0">
                      <tr>
                        <th className="p-2.5">Title</th>
                        <th className="p-2.5">Author</th>
                        <th className="p-2.5">Genre</th>
                        <th className="p-2.5">Copies</th>
                        <th className="p-2.5">Shelf</th>
                        <th className="p-2.5">ISBN</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#E7DFD2] bg-white">
                      {parsedRows.map((row, idx) => (
                        <tr key={idx} className="hover:bg-[#FAF6EE]/50">
                          <td className="p-2.5 font-semibold text-[#2B241E]">{row.title}</td>
                          <td className="p-2.5 text-[#6B6055]">{row.author}</td>
                          <td className="p-2.5">{row.genre}</td>
                          <td className="p-2.5">{row.availableCopies} / {row.totalCopies}</td>
                          <td className="p-2.5 font-mono">{row.shelf}</td>
                          <td className="p-2.5 font-mono text-[#6B6055]">{row.isbn}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* --- SUBTAB 3: STUDENT REQUESTS --- */}
      {activeTab === 'requests' && (
        <div className="space-y-6">
          <div className="bg-[#FFFDF8] rounded-2xl border border-[#E7DFD2] p-6">
            <h2 className="font-serif font-bold text-lg text-[#2B241E] mb-1">
              Student Book Acquisition Queue
            </h2>
            <p className="text-xs sm:text-sm text-[#6B6055] mb-6">
              Titles submitted directly by students via the digital discovery interface.
            </p>

            <div className="space-y-3">
              {requests.map((req) => (
                <div
                  key={req.id}
                  className="p-4 rounded-xl border border-[#E7DFD2] bg-[#FAF6EE]/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="space-y-1 max-w-xl">
                    <div className="flex items-center gap-2">
                      <h4 className="font-serif font-bold text-base text-[#2B241E]">
                        {req.title}
                      </h4>
                      {req.author && (
                        <span className="text-xs text-[#6B6055]">by {req.author}</span>
                      )}
                    </div>
                    {req.note && (
                      <p className="text-xs text-[#6B6055] italic bg-white/70 p-2 rounded-lg border border-[#E7DFD2]/60">
                        "{req.note}"
                      </p>
                    )}
                    <span className="text-[10px] text-[#6B6055] block">
                      Submitted: {new Date(req.submittedAt).toLocaleDateString()} at {new Date(req.submittedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <select
                      value={req.status || 'pending'}
                      onChange={(e) => updateRequestStatus(req.id, e.target.value as BookRequest['status'])}
                      className="bg-white border border-[#D5CABE] rounded-lg px-2.5 py-1 text-xs text-[#2B241E] focus:outline-none"
                    >
                      <option value="pending">Pending</option>
                      <option value="in-review">In Review</option>
                      <option value="acquired">Acquired</option>
                      <option value="cataloged">Cataloged</option>
                    </select>

                    <button
                      onClick={() => {
                        setModalBook({
                          title: req.title,
                          author: req.author || 'Unknown',
                          genre: 'General',
                          description: req.note || `Requested by students.`,
                          isbn: `978${Math.floor(1000000000 + Math.random() * 9000000000)}`,
                          publisher: 'Acquisition',
                          publicationYear: 2024,
                          pages: 250,
                          totalCopies: 2,
                          availableCopies: 2,
                          shelf: 'GEN-01',
                          section: 'General',
                          tags: ['student-request']
                        });
                        setIsModalOpen(true);
                      }}
                      className="px-3 py-1 bg-[#3E6B4C] hover:bg-[#2B4B34] text-[#FAF6EE] text-xs font-semibold rounded-lg transition-colors cursor-pointer"
                    >
                      Add to Catalog
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* --- SUBTAB 4: DEMAND & ACQUISITION INSIGHTS --- */}
      {activeTab === 'insights' && (
        <div className="space-y-6">
          <div className="bg-[#FFFDF8] rounded-2xl border border-[#E7DFD2] p-6 sm:p-8">
            <div className="max-w-2xl mb-6">
              <h2 className="font-serif font-bold text-lg sm:text-xl text-[#2B241E] mb-1">
                Student Demand & Discovery Signals
              </h2>
              <p className="text-xs sm:text-sm text-[#6B6055] leading-relaxed">
                Objective discovery signals aggregated from student search activity and catalog requests. Surfaces interest metrics without prescriptive purchasing directives.
              </p>
            </div>

            {/* Insights Table */}
            <div className="border border-[#E7DFD2] rounded-xl overflow-x-auto">
              <table className="w-full text-left text-xs sm:text-sm divide-y divide-[#E7DFD2]">
                <thead className="bg-[#FAF6EE] text-[#6B6055] font-semibold">
                  <tr>
                    <th className="py-3 px-4">Title & Author</th>
                    <th className="py-3 px-4">Genre / Category</th>
                    <th className="py-3 px-4 text-center">Requests</th>
                    <th className="py-3 px-4 text-center">Searches</th>
                    <th className="py-3 px-4">Demand Signal</th>
                    <th className="py-3 px-4">Catalog Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E7DFD2] bg-white">
                  {insights.map((insight, idx) => (
                    <tr key={idx} className="hover:bg-[#FAF6EE]/50">
                      <td className="py-3.5 px-4">
                        <span className="font-serif font-bold text-[#2B241E] block">
                          {insight.title}
                        </span>
                        {insight.author && (
                          <span className="text-xs text-[#6B6055]">by {insight.author}</span>
                        )}
                        {insight.similarInCatalog && (
                          <span className="text-[11px] text-[#6B6055] block mt-0.5">
                            Similar in catalog: <em className="text-[#8B5E34]">{insight.similarInCatalog}</em>
                          </span>
                        )}
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="inline-block uppercase font-bold text-[10px] text-[#8B5E34] bg-[#FAF6EE] px-2 py-0.5 rounded border border-[#E7DFD2]">
                          {insight.genre}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        <div className="inline-flex flex-col items-center">
                          <span className="font-bold text-sm text-[#2B241E]">{insight.requestCount}</span>
                          <span className="text-[10px] text-[#6B6055] flex items-center gap-0.5">
                            <Users className="w-3 h-3" /> ~{insight.uniqueRequesterEstimate} students
                          </span>
                        </div>
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        <div className="inline-flex items-center gap-1 font-semibold text-[#6B6055]">
                          <Eye className="w-3.5 h-3.5" />
                          <span>{insight.searchCount}</span>
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${
                          insight.signal === 'High student interest'
                            ? 'bg-[#E4EEE6] text-[#3E6B4C] border border-[#B8D8BF]'
                            : insight.signal === 'Frequently requested'
                            ? 'bg-[#FAF6EE] text-[#8B5E34] border border-[#D5CABE]'
                            : 'bg-[#FAF6EE] text-[#6B6055] border border-[#E7DFD2]'
                        }`}>
                          <TrendingUp className="w-3 h-3" />
                          <span>{insight.signal}</span>
                        </span>
                      </td>

                      <td className="py-3.5 px-4">
                        {insight.inLibrary ? (
                          <span className="inline-flex items-center gap-1 text-xs font-semibold text-[#3E6B4C]">
                            <CheckCircle2 className="w-4 h-4" />
                            <span>In collection</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-xs text-[#6B6055]">
                            <span>Unowned</span>
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* --- ADD / EDIT BOOK MODAL --- */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="w-full max-w-xl bg-[#FFFDF8] border border-[#8B5E34]/30 rounded-3xl p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
            <h3 className="font-serif font-bold text-lg text-[#2B241E] mb-4">
              {modalBook.bookId ? 'Edit Book Record' : 'Add New Title to Catalog'}
            </h3>

            <form onSubmit={handleSaveBook} className="space-y-3.5 text-xs sm:text-sm">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#2B241E] mb-1">Title *</label>
                  <input
                    type="text"
                    required
                    value={modalBook.title || ''}
                    onChange={(e) => setModalBook({ ...modalBook, title: e.target.value })}
                    className="w-full px-3 py-2 bg-white border border-[#D5CABE] rounded-lg text-[#2B241E]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#2B241E] mb-1">Author *</label>
                  <input
                    type="text"
                    required
                    value={modalBook.author || ''}
                    onChange={(e) => setModalBook({ ...modalBook, author: e.target.value })}
                    className="w-full px-3 py-2 bg-white border border-[#D5CABE] rounded-lg text-[#2B241E]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-[#2B241E] mb-1">Genre</label>
                  <input
                    type="text"
                    value={modalBook.genre || ''}
                    onChange={(e) => setModalBook({ ...modalBook, genre: e.target.value })}
                    className="w-full px-3 py-2 bg-white border border-[#D5CABE] rounded-lg text-[#2B241E]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#2B241E] mb-1">Shelf Code (e.g. F-12)</label>
                  <input
                    type="text"
                    value={modalBook.shelf || ''}
                    onChange={(e) => setModalBook({ ...modalBook, shelf: e.target.value })}
                    className="w-full px-3 py-2 bg-white border border-[#D5CABE] rounded-lg text-[#2B241E]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#2B241E] mb-1">ISBN</label>
                  <input
                    type="text"
                    value={modalBook.isbn || ''}
                    onChange={(e) => setModalBook({ ...modalBook, isbn: e.target.value })}
                    className="w-full px-3 py-2 bg-white border border-[#D5CABE] rounded-lg text-[#2B241E]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <label className="block font-semibold text-[#2B241E] mb-1">Total Copies</label>
                  <input
                    type="number"
                    min="1"
                    value={modalBook.totalCopies || 1}
                    onChange={(e) => setModalBook({ ...modalBook, totalCopies: parseInt(e.target.value) || 1 })}
                    className="w-full px-3 py-2 bg-white border border-[#D5CABE] rounded-lg text-[#2B241E]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#2B241E] mb-1">Available</label>
                  <input
                    type="number"
                    min="0"
                    max={modalBook.totalCopies || 1}
                    value={modalBook.availableCopies || 0}
                    onChange={(e) => setModalBook({ ...modalBook, availableCopies: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-white border border-[#D5CABE] rounded-lg text-[#2B241E]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#2B241E] mb-1">Pages</label>
                  <input
                    type="number"
                    value={modalBook.pages || 250}
                    onChange={(e) => setModalBook({ ...modalBook, pages: parseInt(e.target.value) || 250 })}
                    className="w-full px-3 py-2 bg-white border border-[#D5CABE] rounded-lg text-[#2B241E]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#2B241E] mb-1">Year</label>
                  <input
                    type="number"
                    value={modalBook.publicationYear || 2024}
                    onChange={(e) => setModalBook({ ...modalBook, publicationYear: parseInt(e.target.value) || 2024 })}
                    className="w-full px-3 py-2 bg-white border border-[#D5CABE] rounded-lg text-[#2B241E]"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#2B241E] mb-1">Description</label>
                <textarea
                  rows={3}
                  value={modalBook.description || ''}
                  onChange={(e) => setModalBook({ ...modalBook, description: e.target.value })}
                  className="w-full px-3 py-2 bg-white border border-[#D5CABE] rounded-lg text-[#2B241E] resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-[#E7DFD2]">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-[#6B6055] hover:text-[#2B241E]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#3E6B4C] hover:bg-[#2B4B34] text-[#FAF6EE] text-xs font-semibold rounded-xl"
                >
                  Save Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
