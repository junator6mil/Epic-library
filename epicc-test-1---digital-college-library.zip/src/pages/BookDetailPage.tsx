import React, { useMemo } from 'react';
import { Book, WorldBook } from '../types';
import { BookCover } from '../components/BookCover';
import { StatusBadge } from '../components/StatusBadge';
import { BookmarkButton } from '../components/BookmarkButton';
import { Shelf } from '../components/Shelf';
import { 
  ArrowLeft, 
  MapPin, 
  Hash, 
  Building2, 
  Calendar, 
  FileText, 
  Tag, 
  BookPlus, 
  CheckCircle2, 
  Globe
} from 'lucide-react';
import { APP_CONFIG } from '../config/appConfig';

interface BookDetailPageProps {
  book: Book | WorldBook;
  allBooks: Book[];
  onBack: () => void;
  onSelectBook: (bookId: string) => void;
  onRequestBook: (title: string, author?: string) => void;
}

export const BookDetailPage: React.FC<BookDetailPageProps> = ({
  book,
  allBooks,
  onBack,
  onSelectBook,
  onRequestBook,
}) => {
  // Check if book has physical library presence
  const isLibraryBook = 'availableCopies' in book && 'shelf' in book;
  const libraryBook = isLibraryBook ? (book as Book) : (book as WorldBook).libraryBook;
  const isAvailable = libraryBook ? libraryBook.availableCopies > 0 : false;
  const worldBookData = !isLibraryBook ? (book as WorldBook) : undefined;

  // Find related books in catalog by shared genre or tags
  const relatedBooks = useMemo(() => {
    return allBooks
      .filter(b => b.bookId !== book.bookId)
      .map(b => {
        let score = 0;
        if (b.genre.toLowerCase() === book.genre.toLowerCase()) score += 5;
        const sharedTags = b.tags.filter(t => (book.tags || []).includes(t));
        score += sharedTags.length * 2;
        return { book: b, score };
      })
      .filter(item => item.score > 0)
      .sort((a, b) => b.score - a.score)
      .map(item => item.book)
      .slice(0, 6);
  }, [book, allBooks]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-10 pb-36 animate-in fade-in duration-300">
      
      {/* Back Button & Top Bookmark Action */}
      <div className="flex items-center justify-between gap-4 mb-6">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-[#8B5E34] hover:text-[#5A3B22] px-3.5 py-2 rounded-xl bg-[#FFFDF8] border border-[#E7DFD2] transition-colors cursor-pointer shadow-2xs"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to main discovery</span>
        </button>

        <BookmarkButton book={book} size="md" showLabel={true} />
      </div>

      {/* Main Two-Column Editorial Book Layout */}
      <div className="bg-[#FFFDF8] rounded-3xl border border-[#E7DFD2] p-6 sm:p-8 lg:p-10 shadow-[0_4px_20px_rgba(43,36,30,0.06)]">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
          
          {/* Left Column: Large Cover & Prominent Availability Box */}
          <div className="lg:col-span-5 flex flex-col items-center lg:items-start space-y-6">
            <div className="w-full flex justify-center lg:justify-start">
              <BookCover book={book} size="xl" className="shadow-2xl" />
            </div>

            {/* UNMISSABLE AVAILABILITY CARD */}
            {libraryBook ? (
              <div className={`w-full rounded-2xl p-5 border ${
                isAvailable 
                  ? 'bg-[#E4EEE6] border-[#B8D8BF] text-[#24452F]' 
                  : 'bg-[#F3E3DC] border-[#E8C7BC] text-[#6E2E1D]'
              }`}>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <StatusBadge book={libraryBook} size="lg" />
                  <span className="text-xs font-mono font-bold bg-white/80 px-2.5 py-1 rounded-lg text-[#2B241E] border border-black/10">
                    Shelf {libraryBook.shelf}
                  </span>
                </div>

                <div className="space-y-2 mt-3 pt-3 border-t border-current/15 text-xs sm:text-sm">
                  <div className="flex items-center justify-between">
                    <span className="opacity-80">Collection status:</span>
                    <span className="font-bold">
                      {libraryBook.availableCopies} of {libraryBook.totalCopies} copies on shelf
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="opacity-80">Physical Location:</span>
                    <span className="font-semibold flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5" />
                      Section: {libraryBook.section} · Shelf {libraryBook.shelf}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="opacity-80">Call Number Prefix:</span>
                    <span className="font-mono font-medium">
                      {APP_CONFIG.callNumberPrefix}-{libraryBook.shelf}-{libraryBook.isbn.slice(-4)}
                    </span>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="mt-4 pt-3 border-t border-current/15 flex flex-col sm:flex-row gap-2">
                  {isAvailable ? (
                    <div className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 bg-[#3E6B4C] text-[#FAF6EE] rounded-xl text-xs sm:text-sm font-semibold shadow-xs">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Ready in {libraryBook.section} section</span>
                    </div>
                  ) : (
                    <button
                      onClick={() => onRequestBook(book.title, book.author)}
                      className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 bg-[#B15A3E] hover:bg-[#96472F] text-[#FAF6EE] rounded-xl text-xs sm:text-sm font-semibold transition-colors cursor-pointer shadow-xs"
                    >
                      <BookPlus className="w-4 h-4" />
                      <span>Request hold</span>
                    </button>
                  )}
                  <BookmarkButton book={book} size="md" showLabel={false} className="py-2.5 px-3" />
                </div>
              </div>
            ) : (
              /* WORLD CATALOG TITLE AVAILABILITY CARD */
              <div className="w-full rounded-2xl p-5 bg-[#FAF6EE] border border-[#D5CABE] text-[#2B241E]">
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#8B5E34] text-[#FAF6EE] text-xs font-semibold">
                    <Globe className="w-3.5 h-3.5" />
                    <span>Universal World Library</span>
                  </span>
                  <span className="text-xs font-medium text-[#6B6055]">
                    Not currently on campus shelf
                  </span>
                </div>

                <p className="text-xs text-[#6B6055] mt-2 mb-4 leading-relaxed">
                  This title is cataloged in the global literature index. You can submit a 1-click acquisition request to have our librarian procure or inter-library loan a copy.
                </p>

                <div className="flex flex-col sm:flex-row gap-2">
                  <button
                    onClick={() => onRequestBook(book.title, book.author)}
                    className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 bg-[#3E6B4C] hover:bg-[#2B4B34] text-[#FAF6EE] rounded-xl text-xs sm:text-sm font-semibold transition-colors cursor-pointer shadow-xs"
                  >
                    <BookPlus className="w-4 h-4" />
                    <span>Request College Library to Acquire</span>
                  </button>
                  <BookmarkButton book={book} size="md" showLabel={false} className="py-2.5 px-3" />
                </div>
              </div>
            )}
          </div>

          {/* Right Column: Title, Author, Description, Deep Literary Metadata */}
          <div className="lg:col-span-7 flex flex-col justify-between space-y-6">
            <div>
              {/* Genre Pill & Year */}
              <div className="flex items-center gap-2.5 mb-2">
                <span className="text-xs uppercase tracking-wider font-bold text-[#8B5E34] bg-[#FAF6EE] px-2.5 py-1 rounded-md border border-[#E7DFD2]">
                  {book.genre}
                </span>
                <span className="text-xs text-[#6B6055] font-medium">
                  First Published {book.publicationYear > 0 ? book.publicationYear : `${Math.abs(book.publicationYear)} BCE`}
                </span>
                {worldBookData?.editionCount && (
                  <span className="text-xs text-[#3E6B4C] bg-[#E4EEE6] px-2 py-0.5 rounded-full font-medium">
                    {worldBookData.editionCount} Global Editions
                  </span>
                )}
              </div>

              {/* Book Title & Author */}
              <h1 className="font-serif font-bold text-2xl sm:text-3xl lg:text-4xl text-[#2B241E] leading-tight mb-2">
                {book.title}
              </h1>
              <p className="font-sans text-base sm:text-lg text-[#6B6055] font-medium mb-6">
                by <span className="text-[#2B241E] font-semibold">{book.author}</span>
              </p>

              {/* Description */}
              <div className="prose prose-stone max-w-none text-[#2B241E]/90 text-sm sm:text-base leading-relaxed mb-8 bg-[#FAF6EE]/50 p-4 sm:p-5 rounded-2xl border border-[#E7DFD2]">
                <h3 className="font-serif font-bold text-sm text-[#8B5E34] uppercase tracking-wider mb-2">
                  Synopsis & Literary Context
                </h3>
                <p>{book.description}</p>
              </div>

              {/* Literary Metadata Matrix */}
              <div>
                <h3 className="font-serif font-bold text-sm text-[#8B5E34] uppercase tracking-wider mb-3">
                  Catalog Specifications
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs sm:text-sm">
                  <div className="p-3 rounded-xl bg-[#FAF6EE] border border-[#E7DFD2]">
                    <span className="text-[#6B6055] text-xs flex items-center gap-1 mb-1">
                      <Hash className="w-3.5 h-3.5" /> ISBN / Ident
                    </span>
                    <span className="font-mono font-semibold text-[#2B241E] line-clamp-1">{book.isbn}</span>
                  </div>

                  <div className="p-3 rounded-xl bg-[#FAF6EE] border border-[#E7DFD2]">
                    <span className="text-[#6B6055] text-xs flex items-center gap-1 mb-1">
                      <Building2 className="w-3.5 h-3.5" /> Publisher
                    </span>
                    <span className="font-semibold text-[#2B241E] line-clamp-1">{book.publisher || 'Universal Press'}</span>
                  </div>

                  <div className="p-3 rounded-xl bg-[#FAF6EE] border border-[#E7DFD2]">
                    <span className="text-[#6B6055] text-xs flex items-center gap-1 mb-1">
                      <FileText className="w-3.5 h-3.5" /> Estimated Pages
                    </span>
                    <span className="font-semibold text-[#2B241E]">{book.pages || 300} pages</span>
                  </div>

                  <div className="p-3 rounded-xl bg-[#FAF6EE] border border-[#E7DFD2]">
                    <span className="text-[#6B6055] text-xs flex items-center gap-1 mb-1">
                      <Calendar className="w-3.5 h-3.5" /> Release Year
                    </span>
                    <span className="font-semibold text-[#2B241E]">
                      {book.publicationYear > 0 ? book.publicationYear : `${Math.abs(book.publicationYear)} BCE`}
                    </span>
                  </div>

                  {libraryBook ? (
                    <>
                      <div className="p-3 rounded-xl bg-[#FAF6EE] border border-[#E7DFD2]">
                        <span className="text-[#6B6055] text-xs flex items-center gap-1 mb-1">
                          <MapPin className="w-3.5 h-3.5" /> Shelf Reference
                        </span>
                        <span className="font-mono font-bold text-[#3E6B4C]">{libraryBook.shelf}</span>
                      </div>

                      <div className="p-3 rounded-xl bg-[#FAF6EE] border border-[#E7DFD2]">
                        <span className="text-[#6B6055] text-xs flex items-center gap-1 mb-1">
                          <Building2 className="w-3.5 h-3.5" /> Campus Section
                        </span>
                        <span className="font-semibold text-[#2B241E]">{libraryBook.section}</span>
                      </div>
                    </>
                  ) : (
                    <div className="p-3 rounded-xl bg-[#FAF6EE] border border-[#E7DFD2] col-span-2">
                      <span className="text-[#6B6055] text-xs flex items-center gap-1 mb-1">
                        <Globe className="w-3.5 h-3.5" /> Archive Source
                      </span>
                      <span className="font-semibold text-[#8B5E34]">Open Library Global World Catalog</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Tags */}
              <div className="mt-6">
                <div className="flex items-center gap-1.5 text-xs text-[#6B6055] font-semibold uppercase tracking-wider mb-2">
                  <Tag className="w-3.5 h-3.5" />
                  <span>Subject & Discovery Tags:</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {(book.tags || []).map((tag) => (
                    <span
                      key={tag}
                      className="text-xs px-2.5 py-1 rounded-full bg-[#FAF6EE] border border-[#D5CABE] text-[#2B241E] font-medium"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Related Books Shelf */}
      {relatedBooks.length > 0 && (
        <div className="mt-12">
          <Shelf
            genre={`Related College Library Titles`}
            subtitle={`Explore matching campus shelf books`}
            books={relatedBooks}
            onSelectBook={onSelectBook}
          />
        </div>
      )}
    </div>
  );
};
