import React, { useState, useMemo, useEffect } from 'react';
import { Book, WorldBook } from '../types';
import { Shelf } from '../components/Shelf';
import { WoodenBookcase } from '../components/WoodenBookcase';
import { WorldLibraryExplorer } from '../components/WorldLibraryExplorer';
import { getAllCuratedWorldBooks } from '../services/worldBooks';
import { getSavedBooks, subscribeToSavedBooks, SavedBookRecord } from '../services/savedBooks';
import { 
  Sparkles, 
  ArrowRight, 
  BookOpen, 
  Layers, 
  Globe, 
  Building2, 
  Search,
  BookmarkCheck,
  Compass,
  Library
} from 'lucide-react';
import { APP_CONFIG } from '../config/appConfig';

interface HomePageProps {
  books: Book[];
  onSelectBook: (bookId: string) => void;
  onSelectWorldBook: (worldBook: WorldBook) => void;
  onOpenAIFinder: () => void;
  onOpenSearch: () => void;
  onOpenRequest: (title?: string, author?: string) => void;
  onOpenSavedDrawer?: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  books,
  onSelectBook,
  onSelectWorldBook,
  onOpenAIFinder,
  onOpenSearch,
  onOpenRequest,
  onOpenSavedDrawer
}) => {
  const [savedBooks, setSavedBooks] = useState<SavedBookRecord[]>(() => getSavedBooks());

  useEffect(() => {
    const unsub = subscribeToSavedBooks(() => {
      setSavedBooks(getSavedBooks());
    });
    return unsub;
  }, []);

  // Group books dynamically by genre for physical shelves
  const genreGroups = useMemo(() => {
    const map = new Map<string, Book[]>();
    books.forEach((book) => {
      const g = book.genre || 'General';
      if (!map.has(g)) {
        map.set(g, []);
      }
      map.get(g)!.push(book);
    });
    return Array.from(map.entries());
  }, [books]);

  // Featured books (curated newly added or highlight titles)
  const featuredBooks = useMemo(() => {
    const highlightIds = ["b-sci-05", "b-fan-04", "b-mys-03", "b-his-01", "b-sh-01", "b-fic-01"];
    const found = books.filter(b => highlightIds.includes(b.bookId));
    return found.length > 0 ? found : books.slice(0, 6);
  }, [books]);

  const scrollToSection = (elementId: string) => {
    const elem = document.getElementById(elementId);
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const scrollToGenre = (genre: string) => {
    const elem = document.getElementById(`shelf-${genre.toLowerCase().replace(/\s+/g, '-')}`);
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  return (
    <div className="pb-32 animate-in fade-in duration-300">
      
      {/* Top Banner & Quick Navigation Bar */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 sm:pt-8">
        
        {/* Unified Discovery Action Bar */}
        <div className="bg-[#FFFDF8] p-3 sm:p-4 rounded-2xl sm:rounded-3xl border border-[#E7DFD2] shadow-sm flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 mb-6">
          
          {/* Quick Jump Navigation Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => scrollToSection('campus-shelves')}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#3E6B4C] text-[#FAF6EE] text-xs sm:text-sm font-semibold shadow-2xs hover:bg-[#2F523A] transition-all cursor-pointer"
            >
              <Building2 className="w-4 h-4" />
              <span>Campus Shelves</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-[#24452F] text-white">
                {books.length}
              </span>
            </button>

            <button
              onClick={() => scrollToSection('world-library-section')}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#FAF6EE] text-[#2B241E] hover:bg-[#E8D9C2] border border-[#D5CABE] text-xs sm:text-sm font-semibold transition-all cursor-pointer"
            >
              <Globe className="w-4 h-4 text-[#8B5E34]" />
              <span>World Books Archive</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-[#D4AF37] text-[#2B241E] font-bold">
                30M+
              </span>
            </button>

            {savedBooks.length > 0 && (
              <button
                onClick={() => {
                  if (onOpenSavedDrawer) onOpenSavedDrawer();
                  else scrollToSection('saved-for-later-section');
                }}
                className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#FAF6EE] text-[#2B241E] hover:bg-[#E8D9C2] border border-[#D5CABE] text-xs sm:text-sm font-semibold transition-all cursor-pointer"
              >
                <BookmarkCheck className="w-4 h-4 text-[#D4AF37] fill-current" />
                <span>Saved for Later</span>
                <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-[#3E6B4C] text-white font-bold">
                  {savedBooks.length}
                </span>
              </button>
            )}
          </div>

          {/* Quick AI & Search Helpers */}
          <div className="flex items-center gap-2 text-xs">
            <button
              onClick={onOpenAIFinder}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#E4EEE6] text-[#24452F] hover:bg-[#D4E4D8] font-semibold transition-colors cursor-pointer border border-[#B8D8BF]"
            >
              <Sparkles className="w-4 h-4 text-[#3E6B4C]" />
              <span>AI Book Finder</span>
            </button>
            <button
              onClick={onOpenSearch}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#FAF6EE] text-[#2B241E] hover:bg-[#E7DFD2] font-semibold transition-colors cursor-pointer border border-[#D5CABE]"
            >
              <Search className="w-4 h-4 text-[#8B5E34]" />
              <span>Instant Search</span>
            </button>
          </div>
        </div>

        {/* Welcome Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-[#E7DFD2] pb-6">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 text-[#8B5E34] text-xs font-semibold uppercase tracking-wider mb-1.5">
              <span>{APP_CONFIG.institutionName}</span>
              <span>•</span>
              <span>{APP_CONFIG.defaultFloor}</span>
            </div>
            <h1 className="font-serif font-bold text-2xl sm:text-3xl lg:text-4xl text-[#2B241E] leading-tight">
              Physical Shelves & World Literature
            </h1>
            <p className="mt-2 text-sm sm:text-base text-[#6B6055] leading-relaxed">
              Browse physical books available right now in the library, or scroll below to discover millions of global titles, manga masterpieces, and world epics.
            </p>
          </div>

          {/* Quick Stats */}
          <div className="flex items-center gap-4 text-xs text-[#6B6055] shrink-0 bg-[#FFFDF8] p-3 rounded-xl border border-[#E7DFD2]">
            <div className="flex items-center gap-1.5">
              <BookOpen className="w-4 h-4 text-[#3E6B4C]" />
              <span><strong className="text-[#2B241E]">{books.length}</strong> Physical Titles</span>
            </div>
            <div className="h-4 w-px bg-[#E7DFD2]" />
            <div className="flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-[#8B5E34]" />
              <span><strong className="text-[#2B241E]">{genreGroups.length}</strong> Wooden Shelves</span>
            </div>
          </div>
        </div>

        {/* Genre Quick-Jump Bar */}
        <div className="mt-4 flex items-center gap-2 overflow-x-auto py-2 shelf-scrollbar">
          <span className="text-xs font-semibold text-[#6B6055] uppercase tracking-wider shrink-0 mr-1">
            Jump to shelf:
          </span>
          {genreGroups.map(([genre, gBooks]) => (
            <button
              key={genre}
              onClick={() => scrollToGenre(genre)}
              className="text-xs px-3 py-1 rounded-full bg-[#FFFDF8] hover:bg-[#3E6B4C] hover:text-white text-[#2B241E] border border-[#D5CABE] transition-colors whitespace-nowrap cursor-pointer font-medium shadow-2xs"
            >
              {genre} ({gBooks.length})
            </button>
          ))}
        </div>
      </section>

      {/* SECTION 1: CAMPUS PHYSICAL SHELVES (ENCLOSED IN THICK SOLID WOOD BOOKCASE) */}
      <section id="campus-shelves" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
        <WoodenBookcase
          title="Campus Library Collection"
          subtitle="Available in Stacks A-1 through E-12"
          badge={`${books.length} Books on Shelf`}
        >
          {/* Featured / Highlight Shelf */}
          <Shelf
            genre="Featured & New Additions"
            subtitle="Curated college collection highlights"
            books={featuredBooks}
            onSelectBook={onSelectBook}
            isFeatured={true}
          />

          {/* Stack of College Genre Shelves with Thick Planks */}
          {genreGroups.map(([genre, gBooks]) => (
            <Shelf
              key={genre}
              genre={genre}
              books={gBooks}
              onSelectBook={onSelectBook}
            />
          ))}
        </WoodenBookcase>
      </section>

      {/* SECTION 2: SAVED FOR LATER PREVIEW (IF ANY SAVED) */}
      {savedBooks.length > 0 && (
        <section id="saved-for-later-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 my-8">
          <div className="bg-[#FAF6EE] rounded-2xl border-2 border-[#D4AF37] p-5 sm:p-6 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-[#D4AF37] text-[#2B241E] flex items-center justify-center shadow-xs shrink-0">
                <BookmarkCheck className="w-6 h-6 fill-current" />
              </div>
              <div>
                <h3 className="font-serif font-bold text-lg text-[#2B241E] flex items-center gap-2">
                  Saved for Later
                  <span className="text-xs font-sans font-semibold px-2.5 py-0.5 rounded-full bg-[#3E6B4C] text-[#FAF6EE]">
                    {savedBooks.length} {savedBooks.length === 1 ? 'book' : 'books'}
                  </span>
                </h3>
                <p className="text-xs sm:text-sm text-[#6B6055]">
                  Your personal reading list is saved in local browser storage.
                </p>
              </div>
            </div>

            <button
              onClick={() => onOpenSavedDrawer && onOpenSavedDrawer()}
              className="px-4 py-2 rounded-xl bg-[#3E6B4C] hover:bg-[#2B4B34] text-[#FAF6EE] text-xs sm:text-sm font-semibold transition-colors shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <span>Open Reading List</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </section>
      )}

      {/* SECTION 3: AI BOOK FINDER PROMOTION CARD */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 my-8 sm:my-10">
        <div 
          onClick={onOpenAIFinder}
          className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#E4EEE6] via-[#FAF6EE] to-[#EAE0D2] border border-[#3E6B4C]/30 p-6 sm:p-8 shadow-[0_6px_20px_rgba(62,107,76,0.12)] hover:shadow-[0_10px_28px_rgba(62,107,76,0.2)] transition-all cursor-pointer group"
        >
          <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-6">
            <div className="max-w-xl">
              <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-[#3E6B4C] text-[#FAF6EE] text-xs font-semibold mb-3 shadow-2xs">
                <Sparkles className="w-3.5 h-3.5" />
                <span>AI Reading Assistant</span>
              </div>
              <h2 className="font-serif font-bold text-xl sm:text-2xl text-[#2B241E] tracking-tight">
                Looking for something specific or similar to another book?
              </h2>
              <p className="mt-1 text-sm text-[#6B6055] leading-relaxed">
                Describe anything from &quot;something like One Piece with pirates and epic adventure&quot;, &quot;dark psychological thrillers&quot;, or &quot;short philosophical essays&quot; — we search both physical campus shelves and the world catalog!
              </p>
            </div>

            <div className="shrink-0">
              <span className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-[#3E6B4C] group-hover:bg-[#2B4B34] text-[#FAF6EE] text-sm font-semibold shadow-sm transition-colors">
                <span>Ask AI Book Finder</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 4: EVERY BOOK IN THE WORLD (INTEGRATED DIRECTLY ON MAIN PAGE) */}
      <section id="world-library-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 pt-8 border-t-2 border-[#D5CABE]/70">
        
        {/* World Library Header Divider */}
        <div className="mb-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#4A2D17] text-[#D4AF37] text-xs font-semibold uppercase tracking-wider mb-2">
            <Globe className="w-3.5 h-3.5" />
            <span>Global Book Repository</span>
          </div>
          <h2 className="font-serif font-bold text-2xl sm:text-3xl text-[#2B241E]">
            Every Book in the World (30 Million+ Archive)
          </h2>
          <p className="text-sm text-[#6B6055] max-w-3xl mt-1.5 leading-relaxed">
            Search the full world catalog including manga masterpieces (One Piece, Berserk, Attack on Titan), global sci-fi, Nobel Prize laureates, and classics. Request any unowned book with 1-click for library acquisition.
          </p>
        </div>

        {/* Embedded World Library Explorer */}
        <WorldLibraryExplorer
          onSelectWorldBook={onSelectWorldBook}
          onRequestBook={(title, author) => onOpenRequest(title, author)}
          onJumpToPhysicalShelf={(shelf) => {
            scrollToSection('campus-shelves');
          }}
        />
      </section>

    </div>
  );
};
