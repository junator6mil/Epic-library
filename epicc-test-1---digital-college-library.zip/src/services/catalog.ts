// In-memory Catalog Service & Reactive Store
import { Book } from '../types';
import { INITIAL_BOOKS } from '../data/seedData';

// In-memory catalog state
let catalogStore: Book[] = [...INITIAL_BOOKS];

type CatalogListener = (books: Book[]) => void;
const listeners: Set<CatalogListener> = new Set();

function notify() {
  const current = [...catalogStore];
  listeners.forEach(fn => fn(current));
}

export function subscribeToCatalog(listener: CatalogListener): () => void {
  listeners.add(listener);
  listener([...catalogStore]);
  return () => {
    listeners.delete(listener);
  };
}

export function getBooks(): Book[] {
  // In a future phase, this would query a real backend / PostgreSQL catalog database
  return [...catalogStore];
}

export function getBookById(id: string): Book | undefined {
  return catalogStore.find(b => b.bookId === id || b.isbn === id);
}

export function getGenres(): string[] {
  const genreSet = new Set<string>();
  catalogStore.forEach(b => {
    if (b.genre) genreSet.add(b.genre);
  });
  return Array.from(genreSet);
}

export function getFeaturedBooks(): Book[] {
  // Return a curated selection of featured / newly added books
  const featuredIds = ["b-sci-05", "b-fan-04", "b-mys-03", "b-his-01", "b-sh-01", "b-fic-01"];
  const featured = catalogStore.filter(b => featuredIds.includes(b.bookId));
  return featured.length > 0 ? featured : catalogStore.slice(0, 6);
}

export function addBook(bookData: Omit<Book, 'bookId'> & { bookId?: string }): Book {
  const newBook: Book = {
    ...bookData,
    bookId: bookData.bookId || `b-custom-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
  };
  catalogStore = [newBook, ...catalogStore];
  notify();
  return newBook;
}

export function updateBook(updated: Book): Book {
  catalogStore = catalogStore.map(b => b.bookId === updated.bookId ? updated : b);
  notify();
  return updated;
}

export function deleteBook(bookId: string): boolean {
  const prevLen = catalogStore.length;
  catalogStore = catalogStore.filter(b => b.bookId !== bookId);
  if (catalogStore.length !== prevLen) {
    notify();
    return true;
  }
  return false;
}

export function updateCopies(bookId: string, totalCopies: number, availableCopies: number): Book | undefined {
  const book = getBookById(bookId);
  if (!book) return undefined;
  
  const clampedAvail = Math.max(0, Math.min(availableCopies, totalCopies));
  const updated: Book = {
    ...book,
    totalCopies: Math.max(1, totalCopies),
    availableCopies: clampedAvail,
  };
  return updateBook(updated);
}

export function resetCatalog(): void {
  catalogStore = [...INITIAL_BOOKS];
  notify();
}
