// Catalog Import & CSV Parsing Service
import { Book } from '../types';
import { addBook, updateBook, getBooks } from './catalog';

// Helper to parse CSV lines respecting quotes
function parseCSVText(text: string): string[][] {
  const lines: string[][] = [];
  let row: string[] = [];
  let inQuotes = false;
  let currentToken = '';

  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    const nextChar = text[i + 1];

    if (char === '"') {
      if (inQuotes && nextChar === '"') {
        currentToken += '"';
        i++; // skip escaped quote
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === ',' && !inQuotes) {
      row.push(currentToken.trim());
      currentToken = '';
    } else if ((char === '\r' || char === '\n') && !inQuotes) {
      if (char === '\r' && nextChar === '\n') {
        i++;
      }
      row.push(currentToken.trim());
      currentToken = '';
      if (row.length > 0 && row.some(cell => cell.length > 0)) {
        lines.push(row);
      }
      row = [];
    } else {
      currentToken += char;
    }
  }

  if (currentToken.length > 0 || row.length > 0) {
    row.push(currentToken.trim());
    if (row.some(cell => cell.length > 0)) {
      lines.push(row);
    }
  }

  return lines;
}

// Column normalizer
function normalizeHeader(header: string): string {
  return header.toLowerCase().replace(/[^a-z0-9]/g, '');
}

export async function parseCatalogFile(file: File): Promise<{ rows: Partial<Book>[]; errors: string[] }> {
  const errors: string[] = [];
  const rows: Partial<Book>[] = [];

  try {
    const text = await file.text();
    const parsedLines = parseCSVText(text);

    if (parsedLines.length < 2) {
      return {
        rows: [],
        errors: ["The file appears to be empty or contains no data rows beyond headers."]
      };
    }

    const rawHeaders = parsedLines[0];
    const headerMap: Record<number, keyof Book | 'tags_raw'> = {};

    rawHeaders.forEach((raw, idx) => {
      const norm = normalizeHeader(raw);
      if (['title', 'booktitle', 'name'].includes(norm)) headerMap[idx] = 'title';
      else if (['author', 'authors', 'writer'].includes(norm)) headerMap[idx] = 'author';
      else if (['isbn', 'isbn13', 'isbn10'].includes(norm)) headerMap[idx] = 'isbn';
      else if (['genre', 'category', 'subject'].includes(norm)) headerMap[idx] = 'genre';
      else if (['description', 'desc', 'summary', 'synopsis'].includes(norm)) headerMap[idx] = 'description';
      else if (['coverurl', 'cover', 'image', 'imageurl'].includes(norm)) headerMap[idx] = 'coverUrl';
      else if (['publisher', 'press'].includes(norm)) headerMap[idx] = 'publisher';
      else if (['publicationyear', 'year', 'pubyear'].includes(norm)) headerMap[idx] = 'publicationYear';
      else if (['pages', 'pagecount', 'numpages'].includes(norm)) headerMap[idx] = 'pages';
      else if (['totalcopies', 'copies', 'total'].includes(norm)) headerMap[idx] = 'totalCopies';
      else if (['availablecopies', 'available'].includes(norm)) headerMap[idx] = 'availableCopies';
      else if (['shelf', 'shelfcode', 'callnumber', 'location'].includes(norm)) headerMap[idx] = 'shelf';
      else if (['section', 'librarysection'].includes(norm)) headerMap[idx] = 'section';
      else if (['bookid', 'id'].includes(norm)) headerMap[idx] = 'bookId';
      else if (['tags', 'keywords', 'topics'].includes(norm)) headerMap[idx] = 'tags_raw';
    });

    if (!Object.values(headerMap).includes('title')) {
      errors.push("Missing required column: 'Title' (or 'book_title', 'name').");
    }

    for (let r = 1; r < parsedLines.length; r++) {
      const line = parsedLines[r];
      const rowItem: Partial<Book> & { tags_raw?: string } = {};

      line.forEach((val, colIdx) => {
        const field = headerMap[colIdx];
        if (!field) return;

        if (field === 'publicationYear' || field === 'pages' || field === 'totalCopies' || field === 'availableCopies') {
          const num = parseInt(val, 10);
          rowItem[field] = isNaN(num) ? 0 : num;
        } else if (field === 'tags_raw') {
          rowItem.tags = val.split(/[;,|]/).map(t => t.trim().toLowerCase()).filter(Boolean);
        } else {
          // @ts-expect-error dynamic string assignment
          rowItem[field] = val;
        }
      });

      // Validation
      if (!rowItem.title) {
        errors.push(`Row ${r + 1}: Skipped row missing required 'Title'.`);
        continue;
      }

      if (!rowItem.author) {
        rowItem.author = "Unknown Author";
      }

      if (!rowItem.genre) {
        rowItem.genre = "General";
      }

      if (rowItem.totalCopies === undefined || rowItem.totalCopies < 1) {
        rowItem.totalCopies = 1;
      }

      if (rowItem.availableCopies === undefined) {
        rowItem.availableCopies = rowItem.totalCopies;
      } else if (rowItem.availableCopies > rowItem.totalCopies) {
        rowItem.availableCopies = rowItem.totalCopies;
      }

      if (!rowItem.shelf) {
        rowItem.shelf = "GEN-01";
      }

      if (!rowItem.section) {
        rowItem.section = rowItem.genre;
      }

      if (!rowItem.tags || rowItem.tags.length === 0) {
        rowItem.tags = [rowItem.genre.toLowerCase()];
      }

      if (!rowItem.coverUrl && rowItem.isbn) {
        rowItem.coverUrl = `https://covers.openlibrary.org/b/isbn/${rowItem.isbn.replace(/[^0-9X]/gi, '')}-L.jpg`;
      }

      rows.push(rowItem);
    }

    return { rows, errors };
  } catch (err: unknown) {
    return {
      rows: [],
      errors: [`Failed to read file: ${err instanceof Error ? err.message : String(err)}`]
    };
  }
}

export function applyCatalogImport(importedRows: Partial<Book>[]): { addedCount: number; updatedCount: number } {
  const currentBooks = getBooks();
  let addedCount = 0;
  let updatedCount = 0;

  importedRows.forEach(row => {
    if (!row.title) return;

    // Check if book exists by ISBN or exact Title
    const existing = currentBooks.find(b => 
      (row.isbn && b.isbn === row.isbn) || 
      (row.bookId && b.bookId === row.bookId) ||
      b.title.toLowerCase() === row.title!.toLowerCase()
    );

    if (existing) {
      const merged: Book = {
        ...existing,
        ...row,
        bookId: existing.bookId,
        totalCopies: row.totalCopies ?? existing.totalCopies,
        availableCopies: row.availableCopies ?? existing.availableCopies,
        tags: Array.from(new Set([...(existing.tags || []), ...(row.tags || [])]))
      };
      updateBook(merged);
      updatedCount++;
    } else {
      const newBook: Book = {
        bookId: row.bookId || `b-imp-${Date.now()}-${Math.floor(Math.random() * 10000)}`,
        isbn: row.isbn || `978000000${Math.floor(Math.random() * 1000)}`,
        title: row.title!,
        author: row.author || "Unknown",
        genre: row.genre || "General",
        description: row.description || `Catalog entry for ${row.title}.`,
        coverUrl: row.coverUrl || (row.isbn ? `https://covers.openlibrary.org/b/isbn/${row.isbn}-L.jpg` : ''),
        publisher: row.publisher || "College Library Press",
        publicationYear: row.publicationYear || new Date().getFullYear(),
        pages: row.pages || 200,
        totalCopies: row.totalCopies ?? 1,
        availableCopies: row.availableCopies ?? 1,
        shelf: row.shelf || "GEN-01",
        section: row.section || row.genre || "General",
        tags: row.tags || [row.genre?.toLowerCase() || 'general']
      };
      addBook(newBook);
      addedCount++;
    }
  });

  return { addedCount, updatedCount };
}
