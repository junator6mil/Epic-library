// Book Requests Service
import { BookRequest } from '../types';
import { SEED_REQUESTS } from '../data/seedData';
import { recordBookRequest } from './insights';

let requestsStore: BookRequest[] = [...SEED_REQUESTS];

type RequestListener = (requests: BookRequest[]) => void;
const listeners: Set<RequestListener> = new Set();

function notify() {
  const current = [...requestsStore];
  listeners.forEach(fn => fn(current));
}

export function subscribeToRequests(listener: RequestListener): () => void {
  listeners.add(listener);
  listener([...requestsStore]);
  return () => {
    listeners.delete(listener);
  };
}

export function getBookRequests(): BookRequest[] {
  return [...requestsStore].sort((a, b) => new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime());
}

export function submitBookRequest(request: Omit<BookRequest, 'id' | 'submittedAt'>): BookRequest {
  const newRequest: BookRequest = {
    id: `req-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    title: request.title.trim(),
    author: request.author?.trim(),
    note: request.note?.trim(),
    submittedAt: new Date().toISOString(),
    status: 'pending'
  };

  requestsStore = [newRequest, ...requestsStore];
  notify();

  // Inform demand insights of this new request
  recordBookRequest(newRequest.title, newRequest.author);

  return newRequest;
}

export function updateRequestStatus(id: string, status: BookRequest['status']): void {
  requestsStore = requestsStore.map(req => req.id === id ? { ...req, status } : req);
  notify();
}
