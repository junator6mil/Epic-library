// Demand & Acquisition Insights Service
import { DemandInsight } from '../types';
import { SEED_INSIGHTS } from '../data/seedData';
import { getBookById, getBooks } from './catalog';

let insightsStore: DemandInsight[] = [...SEED_INSIGHTS];

type InsightsListener = (insights: DemandInsight[]) => void;
const listeners: Set<InsightsListener> = new Set();

function notify() {
  const current = [...insightsStore];
  listeners.forEach(fn => fn(current));
}

export function subscribeToInsights(listener: InsightsListener): () => void {
  listeners.add(listener);
  listener([...insightsStore]);
  return () => {
    listeners.delete(listener);
  };
}

export function getDemandInsights(): DemandInsight[] {
  // Sync inLibrary status with current catalog state
  const books = getBooks();
  return insightsStore.map(insight => {
    const exists = books.some(b => b.title.toLowerCase() === insight.title.toLowerCase());
    return {
      ...insight,
      inLibrary: exists
    };
  });
}

export function recordSearch(query: string): void {
  const clean = query.trim().toLowerCase();
  if (clean.length < 3) return;

  let changed = false;
  insightsStore = insightsStore.map(insight => {
    if (insight.title.toLowerCase().includes(clean) || clean.includes(insight.title.toLowerCase())) {
      changed = true;
      const newSearchCount = insight.searchCount + 1;
      const signal: DemandInsight['signal'] = 
        insight.requestCount >= 15 ? 'High student interest' :
        newSearchCount >= 30 ? 'Frequently searched' :
        insight.requestCount >= 5 ? 'Frequently requested' : 'Frequently searched';

      return {
        ...insight,
        searchCount: newSearchCount,
        signal
      };
    }
    return insight;
  });

  if (changed) {
    notify();
  }
}

export function recordBookRequest(title: string, author?: string): void {
  const cleanTitle = title.trim();
  const existingIdx = insightsStore.findIndex(
    i => i.title.toLowerCase() === cleanTitle.toLowerCase()
  );

  if (existingIdx >= 0) {
    const existing = insightsStore[existingIdx];
    const newReqCount = existing.requestCount + 1;
    const newUniqueEstimate = existing.uniqueRequesterEstimate + 1;
    const signal: DemandInsight['signal'] = 
      newReqCount >= 15 ? 'High student interest' :
      newReqCount >= 6 ? 'Frequently requested' : 'Frequently searched';

    insightsStore[existingIdx] = {
      ...existing,
      requestCount: newReqCount,
      uniqueRequesterEstimate: newUniqueEstimate,
      signal
    };
  } else {
    // Check if in library catalog
    const inLib = getBooks().some(b => b.title.toLowerCase() === cleanTitle.toLowerCase());
    const newInsight: DemandInsight = {
      title: cleanTitle,
      author: author || "Unknown",
      genre: "General Collection",
      requestCount: 1,
      uniqueRequesterEstimate: 1,
      searchCount: 1,
      inLibrary: inLib,
      signal: "Frequently requested",
      similarInCatalog: "Standard collection"
    };
    insightsStore.unshift(newInsight);
  }

  notify();
}
