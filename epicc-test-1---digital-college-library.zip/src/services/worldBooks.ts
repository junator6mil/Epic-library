// Service for browsing, searching, and fetching Every Book in the World
// Connects curated World Literature collections with live Open Library Search & Subject APIs
import { Book, WorldBook } from '../types';
import { getBooks } from './catalog';

// Curated Master Collection of World Literature & Universal Masterpieces
export const CURATED_WORLD_BOOKS: WorldBook[] = [
  // --- WORLD CLASSICS & ALL-TIME MASTERPIECES ---
  {
    bookId: "wb-cls-01",
    isbn: "9780142437230",
    title: "Don Quixote",
    author: "Miguel de Cervantes",
    genre: "World Classics",
    description: "Widely regarded as the first modern novel, chronicling the adventures of the noble Alonso Quixano who reads so many chivalric romances that he loses his mind and decides to become a knight-errant.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780142437230-L.jpg",
    publisher: "Penguin Classics",
    publicationYear: 1605,
    pages: 1072,
    tags: ["world-classics", "spanish-literature", "satire", "adventure", "literary"],
    subjects: ["Spanish literature", "Knights and knighthood", "Chivalry", "Satire"],
    editionCount: 1420
  },
  {
    bookId: "wb-cls-02",
    isbn: "9780140449136",
    title: "Crime and Punishment",
    author: "Fyodor Dostoevsky",
    genre: "World Classics",
    description: "A desperate former student in Saint Petersburg formulates a plan to kill a corrupt pawnbroker to relieve his poverty and test his theory of extraordinary men, descending into fevered guilt and redemption.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780140449136-L.jpg",
    publisher: "Penguin Classics",
    publicationYear: 1866,
    pages: 671,
    tags: ["world-classics", "russian-literature", "psychological", "philosophical", "dark"],
    subjects: ["Psychological fiction", "Murder", "Guilt", "Saint Petersburg", "Redemption"],
    editionCount: 980
  },
  {
    bookId: "wb-cls-03",
    isbn: "9780140449174",
    title: "The Brothers Karamazov",
    author: "Fyodor Dostoevsky",
    genre: "World Classics",
    description: "A passionate philosophical novel set in 19th-century Russia, entering deeply into the ethical debates of God, free will, morality, and patricide.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780140449174-L.jpg",
    publisher: "Penguin Classics",
    publicationYear: 1880,
    pages: 796,
    tags: ["world-classics", "russian-literature", "philosophical", "psychological", "theology"],
    subjects: ["Patricide", "Faith", "Morality", "Russian literature"],
    editionCount: 750
  },
  {
    bookId: "wb-cls-04",
    isbn: "9780140447934",
    title: "War and Peace",
    author: "Leo Tolstoy",
    genre: "World Classics",
    description: "Epic panorama of Russian society during the Napoleonic Wars, tracing the fortunes of five aristocratic families across love, battlefields, spiritual quest, and history.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780140447934-L.jpg",
    publisher: "Penguin Classics",
    publicationYear: 1869,
    pages: 1225,
    tags: ["world-classics", "historical", "russian-literature", "war", "epic"],
    subjects: ["Napoleonic Wars", "Russia", "Aristocracy", "Historical fiction"],
    editionCount: 890
  },
  {
    bookId: "wb-cls-05",
    isbn: "9780140447941",
    title: "Anna Karenina",
    author: "Leo Tolstoy",
    genre: "World Classics",
    description: "A tragic story of a married aristocrat and her affair with the affluent Count Vronsky, contrasted with Konstantin Levin's search for faith and rural agrarian truth.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780140447941-L.jpg",
    publisher: "Penguin Classics",
    publicationYear: 1878,
    pages: 864,
    tags: ["world-classics", "romance", "russian-literature", "psychological", "tragedy"],
    subjects: ["Adultery", "Aristocracy", "Imperial Russia", "Tragedy"],
    editionCount: 810
  },
  {
    bookId: "wb-cls-06",
    isbn: "9780140268867",
    title: "The Odyssey",
    author: "Homer",
    genre: "World Classics",
    description: "The fundamental ancient Greek epic poem following Odysseus, king of Ithaca, on his arduous ten-year journey home after the Trojan War against monsters, sirens, and gods.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780140268867-L.jpg",
    publisher: "Penguin Classics",
    publicationYear: -700,
    pages: 541,
    tags: ["mythology", "world-classics", "ancient-greece", "adventure", "epic", "poetry"],
    subjects: ["Greek epic", "Odysseus", "Mythology", "Monsters", "Homecoming"],
    editionCount: 1600
  },
  {
    bookId: "wb-cls-07",
    isbn: "9780140448955",
    title: "The Divine Comedy",
    author: "Dante Alighieri",
    genre: "World Classics",
    description: "The monumental Italian narrative poem describing Dante's journey through Inferno, Purgatorio, and Paradiso, guided by Virgil and Beatrice.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780140448955-L.jpg",
    publisher: "Penguin Classics",
    publicationYear: 1320,
    pages: 798,
    tags: ["world-classics", "italian-literature", "poetry", "theology", "philosophical"],
    subjects: ["Afterlife", "Christian poetry", "Medieval literature", "Italian epic"],
    editionCount: 1100
  },
  {
    bookId: "wb-cls-08",
    isbn: "9780141439518",
    title: "Pride and Prejudice",
    author: "Jane Austen",
    genre: "World Classics",
    description: "A romantic masterpiece following Elizabeth Bennet as she learns the difference between superficial goodness and actual goodness, overcoming class prejudice and Mr. Darcy's initial pride.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780141439518-L.jpg",
    publisher: "Penguin Classics",
    publicationYear: 1813,
    pages: 432,
    tags: ["world-classics", "romance", "british-literature", "satire", "social"],
    subjects: ["English society", "Sisters", "Courtship", "Class distinction"],
    editionCount: 2200
  },
  {
    bookId: "wb-cls-09",
    isbn: "9780451524935",
    title: "1984",
    author: "George Orwell",
    genre: "Dystopian & Sci-Fi",
    description: "The chilling depiction of totalitarianism, surveillance, Doublethink, and the Ministry of Truth in a superstate dominated by Big Brother.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780451524935-L.jpg",
    publisher: "Signet Classic",
    publicationYear: 1949,
    pages: 328,
    tags: ["dystopian", "political", "dark", "science-fiction", "philosophical"],
    subjects: ["Totalitarianism", "Surveillance", "Propaganda", "Dystopia"],
    editionCount: 1950
  },
  {
    bookId: "wb-cls-10",
    isbn: "9780141187761",
    title: "The Metamorphosis",
    author: "Franz Kafka",
    genre: "World Classics",
    description: "Gregor Samsa wakes up one morning to find himself transformed into a monstrous vermin, sparking an existential exploration of alienation and modern bureaucracy.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780141187761-L.jpg",
    publisher: "Penguin Modern Classics",
    publicationYear: 1915,
    pages: 114,
    tags: ["existential", "world-classics", "german-literature", "surreal", "short"],
    subjects: ["Alienation", "Transformation", "Family conflict", "Absurdism"],
    editionCount: 650
  },

  // --- NOBEL LAUREATES & GLOBAL VOICES ---
  {
    bookId: "wb-nob-01",
    isbn: "9780060883287",
    title: "One Hundred Years of Solitude",
    author: "Gabriel García Márquez",
    genre: "Latin American & Nobel",
    description: "The pinnacle of magical realism tracing seven generations of the Buendía family in the mythical Colombian town of Macondo.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780060883287-L.jpg",
    publisher: "Harper Perennial",
    publicationYear: 1967,
    pages: 417,
    tags: ["magical-realism", "latin-american", "nobel-prize", "literary", "epic"],
    subjects: ["Macondo", "Family dynasty", "Colombian fiction", "Magical realism"],
    editionCount: 890
  },
  {
    bookId: "wb-nob-02",
    isbn: "9780385474542",
    title: "Things Fall Apart",
    author: "Chinua Achebe",
    genre: "African Literature",
    description: "The iconic Nigerian novel chronicling Okonkwo, a proud Igbo warrior whose life and village are upended by British colonial administrators and missionaries.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780385474542-L.jpg",
    publisher: "Anchor",
    publicationYear: 1958,
    pages: 209,
    tags: ["african-literature", "nigerian", "colonialism", "historical", "cultural"],
    subjects: ["Igbo culture", "Colonialism", "Nigeria", "Tragedy"],
    editionCount: 520
  },
  {
    bookId: "wb-nob-03",
    isbn: "9780679720201",
    title: "The Stranger",
    author: "Albert Camus",
    genre: "Philosophy & Nobel",
    description: "Through the story of Meursault, a French Algerian who shoots an Arab on a sun-drenched beach, Camus explores the absurdity of human existence and social hypocrisy.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780679720201-L.jpg",
    publisher: "Vintage",
    publicationYear: 1942,
    pages: 123,
    tags: ["philosophical", "existential", "nobel-prize", "french-literature", "absurdism"],
    subjects: ["Absurdism", "Algeria", "Existentialism", "Murder"],
    editionCount: 780
  },
  {
    bookId: "wb-nob-04",
    isbn: "9780679731726",
    title: "The Remains of the Day",
    author: "Kazuo Ishiguro",
    genre: "Contemporary & Nobel",
    description: "Stevens, an aging English butler, embarks on a motoring trip in the 1950s, reflecting on his decades of unquestioning service to Lord Darlington and the love he repressed.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780679731726-L.jpg",
    publisher: "Vintage International",
    publicationYear: 1989,
    pages: 245,
    tags: ["nobel-prize", "british-literature", "psychological", "historical", "memory"],
    subjects: ["Butler", "Dignity", "Repression", "Post-war Britain"],
    editionCount: 390
  },
  {
    bookId: "wb-nob-05",
    isbn: "9780375706868",
    title: "My Name Is Red",
    author: "Orhan Pamuk",
    genre: "World Literature & Nobel",
    description: "In 16th-century Ottoman Istanbul, miniature painters are commissioned to create a secret book in the European style, provoking religious fury and murder mysteries.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780375706868-L.jpg",
    publisher: "Vintage",
    publicationYear: 1998,
    pages: 417,
    tags: ["nobel-prize", "turkish-literature", "mystery", "historical", "art"],
    subjects: ["Ottoman Empire", "Istanbul", "Miniature painting", "Murder mystery"],
    editionCount: 310
  },

  // --- ASIAN & EASTERN EPICS & MANGA MASTERPIECES ---
  {
    bookId: "wb-manga-01",
    isbn: "9781569319017",
    title: "One Piece, Vol. 1: Romance Dawn",
    author: "Eiichiro Oda",
    genre: "Manga & Graphic Novels",
    description: "As a child, Monkey D. Luffy dreamed of becoming King of the Pirates. But his life changed when he accidentally gained the power to stretch like rubber... at the cost of never being able to swim again! Decades later, Luffy sets off in a rowboat in search of the legendary 'One Piece', the greatest treasure in the world.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9781569319017-L.jpg",
    publisher: "VIZ Media / Shonen Jump",
    publicationYear: 1997,
    pages: 216,
    tags: ["manga", "shonen", "pirates", "adventure", "japanese-literature", "action", "fantasy", "one-piece", "luffy", "anime"],
    subjects: ["Pirates", "Manga", "Superpowers", "Grand Line", "Shonen Jump", "Adventure"],
    editionCount: 1200
  },
  {
    bookId: "wb-manga-02",
    isbn: "9781593070205",
    title: "Berserk, Vol. 1",
    author: "Kentaro Miura",
    genre: "Manga & Graphic Novels",
    description: "The dark fantasy magnum opus chronicling Guts, the Black Swordsman, wielding a gargantuan dragon slayer sword as he wanders a medieval hellscape brandished with an unholy curse.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9781593070205-L.jpg",
    publisher: "Dark Horse Manga",
    publicationYear: 1989,
    pages: 224,
    tags: ["manga", "dark-fantasy", "dark", "action", "japanese-literature", "grim", "monsters"],
    subjects: ["Dark fantasy", "Mercenaries", "Demons", "Black Swordsman"],
    editionCount: 540
  },
  {
    bookId: "wb-manga-03",
    isbn: "9781612620244",
    title: "Attack on Titan, Vol. 1",
    author: "Hajime Isayama",
    genre: "Manga & Graphic Novels",
    description: "In a world where the last remnants of humanity live barricaded within gigantic concentric walls, giant humanoid Titans suddenly breach Wall Maria, forcing Eren Yeager to join the Survey Corps.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9781612620244-L.jpg",
    publisher: "Kodansha Comics",
    publicationYear: 2009,
    pages: 192,
    tags: ["manga", "dark-fantasy", "dystopian", "action", "japanese-literature", "mystery", "monsters"],
    subjects: ["Titans", "Survival", "Wall Maria", "Military fiction", "Manga"],
    editionCount: 620
  },
  {
    bookId: "wb-manga-04",
    isbn: "9781421501680",
    title: "Death Note, Vol. 1: Boredom",
    author: "Tsugumi Ohba & Takeshi Obata",
    genre: "Manga & Graphic Novels",
    description: "Light Yagami is an ace student with great prospects who finds a supernatural notebook dropped by a Shinigami: any human whose name is written in it will die. Light resolves to rid the world of criminals, pursued by the enigmatic genius detective L.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9781421501680-L.jpg",
    publisher: "VIZ Media",
    publicationYear: 2003,
    pages: 195,
    tags: ["manga", "psychological", "thriller", "mystery", "supernatural", "detective", "mind-bending"],
    subjects: ["Shinigami", "Psychological warfare", "Justice", "Manga"],
    editionCount: 480
  },
  {
    bookId: "wb-manga-05",
    isbn: "9781591169208",
    title: "Fullmetal Alchemist, Vol. 1",
    author: "Hiromu Arakawa",
    genre: "Manga & Graphic Novels",
    description: "In an alchemical world where equivalent exchange governs all matter, young brothers Edward and Alphonse Elric commit the ultimate taboo of human transmutation, setting out on a quest for the Philosopher's Stone.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9781591169208-L.jpg",
    publisher: "VIZ Media",
    publicationYear: 2001,
    pages: 192,
    tags: ["manga", "fantasy", "adventure", "magic", "action", "steampunk"],
    subjects: ["Alchemy", "Brothers", "State Alchemists", "Manga"],
    editionCount: 510
  },
  {
    bookId: "wb-pop-01",
    isbn: "9780547928210",
    title: "The Fellowship of the Ring",
    author: "J.R.R. Tolkien",
    genre: "World Fantasy & Epics",
    description: "The first part of the monumental high fantasy epic, following Frodo Baggins as he inherits the One Ring of Sauron and sets out with eight companions to destroy it in the fires of Mount Doom.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780547928210-L.jpg",
    publisher: "Mariner Books",
    publicationYear: 1954,
    pages: 432,
    tags: ["fantasy", "epic", "adventure", "magic", "mythology", "classic-fantasy", "tolkien"],
    subjects: ["Middle-earth", "One Ring", "Hobbits", "High fantasy"],
    editionCount: 1540
  },
  {
    bookId: "wb-pop-02",
    isbn: "9780590353427",
    title: "Harry Potter and the Sorcerer's Stone",
    author: "J.K. Rowling",
    genre: "World Fantasy & Epics",
    description: "An eleven-year-old orphan discovers he is a wizard and is whisked away from his neglectful aunt and uncle to Hogwarts School of Witchcraft and Wizardry.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780590353427-L.jpg",
    publisher: "Scholastic",
    publicationYear: 1997,
    pages: 309,
    tags: ["fantasy", "magic", "wizards", "coming-of-age", "adventure", "school"],
    subjects: ["Hogwarts", "Magic", "Witches and wizards", "Friendship"],
    editionCount: 2200
  },
  {
    bookId: "wb-pop-03",
    isbn: "9780307743657",
    title: "The Shining",
    author: "Stephen King",
    genre: "Horror & Suspense",
    description: "Jack Torrance's new job at the Overlook Hotel is the perfect chance for a fresh start as the off-season caretaker. But as the winter weather shuts him in, the hotel's psychic and sinister forces begin to gather around young Danny's shining gift.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780307743657-L.jpg",
    publisher: "Anchor",
    publicationYear: 1977,
    pages: 688,
    tags: ["horror", "psychological", "dark", "supernatural", "atmospheric", "thriller", "stephen-king"],
    subjects: ["Overlook Hotel", "Psychic power", "Isolation", "Haunting"],
    editionCount: 890
  },
  {
    bookId: "wb-pop-04",
    isbn: "9781451627282",
    title: "11/22/63",
    author: "Stephen King",
    genre: "Speculative & Thriller",
    description: "A high school English teacher discovers a portal in a local diner's pantry that transports him back to September 9, 1958, giving him a chance to prevent the assassination of John F. Kennedy.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9781451627282-L.jpg",
    publisher: "Gallery Books",
    publicationYear: 2011,
    pages: 849,
    tags: ["time-travel", "historical", "thriller", "suspense", "stephen-king", "mind-bending"],
    subjects: ["JFK assassination", "Time travel", "1960s America", "Alternative history"],
    editionCount: 420
  },
  {
    bookId: "wb-pop-05",
    isbn: "9780765382030",
    title: "The Three-Body Problem",
    author: "Cixin Liu",
    genre: "World Sci-Fi",
    description: "Set against the backdrop of China's Cultural Revolution, a secret military project sends signals into space to establish contact with aliens. An alien civilization on the brink of destruction captures the signal and plans to invade Earth.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780765382030-L.jpg",
    publisher: "Tor Books",
    publicationYear: 2008,
    pages: 400,
    tags: ["science-fiction", "hard-scifi", "space", "chinese-literature", "alien-contact", "physics", "mind-bending"],
    subjects: ["Extraterrestrial life", "Cultural Revolution", "Astrophysics", "Hugo Award Winner"],
    editionCount: 650
  },
  {
    bookId: "wb-pop-06",
    isbn: "9780062315007",
    title: "The Alchemist",
    author: "Paulo Coelho",
    genre: "World Classics & Philosophy",
    description: "The mystical story of Santiago, an Andalusian shepherd boy who yearns to travel in search of a worldly treasure in the Egyptian pyramids, discovering his Personal Legend along the way.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780062315007-L.jpg",
    publisher: "HarperOne",
    publicationYear: 1988,
    pages: 208,
    tags: ["philosophical", "inspirational", "adventure", "fable", "latin-american", "spirituality"],
    subjects: ["Personal Legend", "Desert quest", "Fable", "Self-discovery"],
    editionCount: 1800
  },
  {
    bookId: "wb-asi-01",
    isbn: "9780142437148",
    title: "The Tale of Genji",
    author: "Murasaki Shikibu",
    genre: "Asian Literature",
    description: "Written in 11th-century Heian Japan by a noblewoman, universally celebrated as the world's first comprehensive psychological novel of aristocratic romance and Buddhist impermanence.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780142437148-L.jpg",
    publisher: "Penguin Classics",
    publicationYear: 1010,
    pages: 1184,
    tags: ["asian-literature", "japanese-literature", "world-classics", "romance", "epic"],
    subjects: ["Heian court", "Japanese classics", "Genji", "Courtly love"],
    editionCount: 460
  },
  {
    bookId: "wb-asi-02",
    isbn: "9780679767244",
    title: "The Wind-Up Bird Chronicle",
    author: "Haruki Murakami",
    genre: "Asian Literature",
    description: "Toru Okada searches for his wife's missing cat in suburban Tokyo, only to be drawn into a surreal subterranean netherworld of Japanese wartime guilt, psychic healing, and mystery.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780679767244-L.jpg",
    publisher: "Vintage",
    publicationYear: 1994,
    pages: 607,
    tags: ["japanese-literature", "surreal", "mind-bending", "mystery", "contemporary"],
    subjects: ["Tokyo", "Surrealism", "World War II memories", "Missing persons"],
    editionCount: 340
  },
  {
    bookId: "wb-asi-03",
    isbn: "9780140449198",
    title: "Journey to the West",
    author: "Wu Cheng'en",
    genre: "Asian Literature",
    description: "One of the Four Great Classical Novels of Chinese literature, following the monk Xuanzang and his mythical disciple the Monkey King Sun Wukong traveling to India in search of sacred Buddhist sutras.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780140449198-L.jpg",
    publisher: "Penguin Classics",
    publicationYear: 1592,
    pages: 2340,
    tags: ["chinese-literature", "mythology", "fantasy", "adventure", "world-classics"],
    subjects: ["Monkey King", "Buddhism", "Chinese folklore", "Silk Road quest"],
    editionCount: 680
  },

  // --- WORLD PHILOSOPHY & HUMAN THOUGHT ---
  {
    bookId: "wb-phi-01",
    isbn: "9780812968255",
    title: "Meditations",
    author: "Marcus Aurelius",
    genre: "Philosophy",
    description: "The private spiritual reflections and Stoic exercises of Roman Emperor Marcus Aurelius on duty, death, nature, emotional fortitude, and humility.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780812968255-L.jpg",
    publisher: "Modern Library",
    publicationYear: 180,
    pages: 256,
    tags: ["philosophy", "stoicism", "ancient-rome", "wisdom", "self-help"],
    subjects: ["Stoicism", "Roman philosophy", "Ethics", "Spiritual exercises"],
    editionCount: 890
  },
  {
    bookId: "wb-phi-02",
    isbn: "9780140449143",
    title: "The Republic",
    author: "Plato",
    genre: "Philosophy",
    description: "Socrates and his interlocutors examine the meaning of justice, the ideal state structure, the Allegory of the Cave, and the nature of the immortal soul.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780140449143-L.jpg",
    publisher: "Penguin Classics",
    publicationYear: -375,
    pages: 416,
    tags: ["philosophy", "ancient-greece", "political", "justice", "ethics"],
    subjects: ["Justice", "Utopia", "Cave allegory", "Greek philosophy"],
    editionCount: 1400
  },
  {
    bookId: "wb-phi-03",
    isbn: "9780140441314",
    title: "Tao Te Ching",
    author: "Lao Tzu",
    genre: "Philosophy",
    description: "The foundational text of Taoism, offering 81 poetic verses on Wu Wei (effortless action), harmony with the natural cosmic order, and tranquil leadership.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780140441314-L.jpg",
    publisher: "Penguin Classics",
    publicationYear: -400,
    pages: 160,
    tags: ["philosophy", "taoism", "eastern-philosophy", "wisdom", "spirituality"],
    subjects: ["Taoism", "Chinese philosophy", "Wu Wei", "Harmonious living"],
    editionCount: 1200
  },
  {
    bookId: "wb-phi-04",
    isbn: "9780140449235",
    title: "Beyond Good and Evil",
    author: "Friedrich Nietzsche",
    genre: "Philosophy",
    description: "Nietzsche dramatically critiques past philosophers for blind acceptance of Christian morality and proposes the will to power and master-slave morality frameworks.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780140449235-L.jpg",
    publisher: "Penguin Classics",
    publicationYear: 1886,
    pages: 240,
    tags: ["philosophy", "existential", "german-philosophy", "ethics", "mind-bending"],
    subjects: ["Will to power", "Morality", "Perspectivism", "Continental philosophy"],
    editionCount: 650
  },
  {
    bookId: "wb-phi-05",
    isbn: "9780199539420",
    title: "The Art of War",
    author: "Sun Tzu",
    genre: "Philosophy & Strategy",
    description: "The definitive ancient Chinese treatise on military strategy, tactical deception, psychological warfare, diplomacy, and winning without conflict.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780199539420-L.jpg",
    publisher: "Oxford World's Classics",
    publicationYear: -500,
    pages: 128,
    tags: ["strategy", "philosophy", "ancient-china", "military", "leadership"],
    subjects: ["Military strategy", "Tactics", "Chinese military treatise", "Leadership"],
    editionCount: 950
  },

  // --- SCI-FI, SPECULATIVE & COSMOS ---
  {
    bookId: "wb-sci-01",
    isbn: "9780765377067",
    title: "The Three-Body Problem",
    author: "Liu Cixin",
    genre: "Science Fiction",
    description: "During China's Cultural Revolution, a secret military project sends signals into space, leading a dying alien civilization on Trisolaris to target Earth for invasion.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780765377067-L.jpg",
    publisher: "Tor Books",
    publicationYear: 2008,
    pages: 400,
    tags: ["science-fiction", "hard-scifi", "chinese-literature", "space", "mind-bending"],
    subjects: ["First contact", "Astrophysics", "Virtual reality", "Fermi paradox"],
    editionCount: 280
  },
  {
    bookId: "wb-sci-02",
    isbn: "9780553293357",
    title: "Foundation",
    author: "Isaac Asimov",
    genre: "Science Fiction",
    description: "Mathematician Hari Seldon creates psychohistory to foresee the imminent fall of the Galactic Empire and establishes the Foundation to preserve human knowledge.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780553293357-L.jpg",
    publisher: "Spectra",
    publicationYear: 1951,
    pages: 255,
    tags: ["science-fiction", "space-opera", "psychohistory", "classic-scifi"],
    subjects: ["Galactic Empire", "Psychohistory", "Future history", "Space opera"],
    editionCount: 540
  },
  {
    bookId: "wb-sci-03",
    isbn: "9780441478125",
    title: "The Left Hand of Darkness",
    author: "Ursula K. Le Guin",
    genre: "Science Fiction",
    description: "A human envoy travels to the icy world of Gethen, where inhabitants possess no fixed gender, pioneering speculative sociology and political intrigue.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780441478125-L.jpg",
    publisher: "Ace",
    publicationYear: 1969,
    pages: 304,
    tags: ["science-fiction", "anthropological-scifi", "gender", "philosophical", "masterpiece"],
    subjects: ["Gethen", "Ambisexual society", "Winter planet", "First contact"],
    editionCount: 420
  },
  {
    bookId: "wb-sci-04",
    isbn: "9780345339683",
    title: "The Hobbit",
    author: "J.R.R. Tolkien",
    genre: "Fantasy",
    description: "Bilbo Baggins is swept out of his comfortable hobbit-hole into an epic quest with Gandalf and thirteen dwarves to reclaim the Lonely Mountain from Smaug the Dragon.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780345339683-L.jpg",
    publisher: "Del Rey",
    publicationYear: 1937,
    pages: 310,
    tags: ["fantasy", "adventure", "middle-earth", "dragons", "magic"],
    subjects: ["Hobbits", "Middle-earth", "Dragons", "Quests"],
    editionCount: 1800
  },
  {
    bookId: "wb-sci-05",
    isbn: "9780394715964",
    title: "Cosmos",
    author: "Carl Sagan",
    genre: "Science & Cosmos",
    description: "A lyrical exploration of 15 billion years of cosmic evolution and the development of human science, civilization, and astronomy.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780394715964-L.jpg",
    publisher: "Ballantine Books",
    publicationYear: 1980,
    pages: 384,
    tags: ["science", "astronomy", "cosmos", "humanity", "inspirational"],
    subjects: ["Astronomy", "Cosmology", "Evolution", "Space exploration"],
    editionCount: 380
  },

  // --- WORLD HISTORY, BIOGRAPHY & CIVILIZATION ---
  {
    bookId: "wb-his-01",
    isbn: "9780062316097",
    title: "Sapiens: A Brief History of Humankind",
    author: "Yuval Noah Harari",
    genre: "World History",
    description: "Explores how an insignificant ape became the ruler of planet Earth through the Cognitive, Agricultural, and Scientific revolutions.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780062316097-L.jpg",
    publisher: "Harper",
    publicationYear: 2014,
    pages: 443,
    tags: ["history", "anthropology", "evolution", "civilization", "science"],
    subjects: ["Human evolution", "Cognitive revolution", "World history", "Anthropology"],
    editionCount: 420
  },
  {
    bookId: "wb-his-02",
    isbn: "9780393317558",
    title: "Guns, Germs, and Steel",
    author: "Jared Diamond",
    genre: "World History",
    description: "Explains how environmental and geographical factors, rather than genetic differences, shaped the fates of human societies across continents.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780393317558-L.jpg",
    publisher: "W. W. Norton",
    publicationYear: 1997,
    pages: 494,
    tags: ["history", "geography", "civilization", "anthropology"],
    subjects: ["Geographic determinism", "Civilization", "Agriculture", "Global history"],
    editionCount: 310
  },
  {
    bookId: "wb-his-03",
    isbn: "9780307277671",
    title: "The Looming Tower: Al-Qaeda and the Road to 9/11",
    author: "Lawrence Wright",
    genre: "World History & Politics",
    description: "A sweeping Pulitzer Prize-winning historical investigation tracing the transformation of Islamic fundamentalism and intelligence failures.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780307277671-L.jpg",
    publisher: "Knopf",
    publicationYear: 2006,
    pages: 480,
    tags: ["history", "middle-east", "geopolitics", "journalism", "pulitzer"],
    subjects: ["Al-Qaeda", "Middle East history", "Terrorism", "Geopolitics"],
    editionCount: 160
  },

  // --- WORLD MYSTERY, THRILLER & NOIR ---
  {
    bookId: "wb-mys-01",
    isbn: "9780062073488",
    title: "And Then There Were None",
    author: "Agatha Christie",
    genre: "Mystery & Thriller",
    description: "Ten strangers are lured to an isolated island off the Devon coast by a mysterious host, only to be executed one by one according to a nursery rhyme.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780062073488-L.jpg",
    publisher: "William Morrow",
    publicationYear: 1939,
    pages: 272,
    tags: ["mystery", "whodunnit", "classic-mystery", "thriller", "suspense"],
    subjects: ["Locked room mystery", "Island murder", "Detective fiction", "Ten little soldier boys"],
    editionCount: 1100
  },
  {
    bookId: "wb-mys-02",
    isbn: "9780156001311",
    title: "The Name of the Rose",
    author: "Umberto Eco",
    genre: "Mystery & Thriller",
    description: "In 1327, Franciscan friar William of Baskerville investigates a series of murders in a wealthy Italian Benedictine monastery harboring a secret labyrinthine library.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780156001311-L.jpg",
    publisher: "Mariner Books",
    publicationYear: 1980,
    pages: 536,
    tags: ["mystery", "historical", "semiotics", "italian-literature", "labyrinth"],
    subjects: ["Medieval monastery", "Inquisition", "Aristotle's Poetics", "Library labyrinth"],
    editionCount: 450
  },
  {
    bookId: "wb-mys-03",
    isbn: "9780307949486",
    title: "The Girl with the Dragon Tattoo",
    author: "Stieg Larsson",
    genre: "Mystery & Thriller",
    description: "Disgraced financial journalist Mikael Blomkvist and hacker Lisbeth Salander uncover decades of familial corruption and serial killings in Sweden.",
    coverUrl: "https://covers.openlibrary.org/b/isbn/9780307949486-L.jpg",
    publisher: "Vintage Crime",
    publicationYear: 2005,
    pages: 465,
    tags: ["nordic-noir", "mystery", "thriller", "cyberpunk", "dark"],
    subjects: ["Swedish crime", "Lisbeth Salander", "Vanger family", "Investigative journalism"],
    editionCount: 520
  }
];

// Helper: Cross-reference a WorldBook with the physical College Library
export function annotateWithLibraryStatus(worldBook: WorldBook): WorldBook {
  const libraryBooks = getBooks();
  
  // Try to match by ISBN first
  if (worldBook.isbn) {
    const cleanIsbn = worldBook.isbn.replace(/[-\s]/g, '');
    const foundByIsbn = libraryBooks.find(b => b.isbn.replace(/[-\s]/g, '') === cleanIsbn);
    if (foundByIsbn) {
      return {
        ...worldBook,
        inLibrary: true,
        libraryBook: foundByIsbn
      };
    }
  }

  // Match by Title + Author fuzzily
  const targetTitle = worldBook.title.toLowerCase().trim();
  const targetAuthor = worldBook.author.toLowerCase().trim();

  const foundByTitle = libraryBooks.find(b => {
    const titleMatch = b.title.toLowerCase().trim() === targetTitle || 
                       b.title.toLowerCase().includes(targetTitle) || 
                       targetTitle.includes(b.title.toLowerCase());
    const authorMatch = b.author.toLowerCase().includes(targetAuthor.split(' ').pop() || '') ||
                        targetAuthor.includes(b.author.toLowerCase().split(' ').pop() || '');
    return titleMatch && authorMatch;
  });

  if (foundByTitle) {
    return {
      ...worldBook,
      inLibrary: true,
      libraryBook: foundByTitle
    };
  }

  return {
    ...worldBook,
    inLibrary: false
  };
}

// Live Open Library Search Query interface
export async function searchOpenLibraryWorld(query: string, page = 1, limit = 24): Promise<{
  books: WorldBook[];
  totalFound: number;
}> {
  const trimmed = query.trim();
  if (!trimmed) {
    const annotated = CURATED_WORLD_BOOKS.map(annotateWithLibraryStatus);
    return { books: annotated, totalFound: annotated.length };
  }

  try {
    const encoded = encodeURIComponent(trimmed);
    const url = `https://openlibrary.org/search.json?q=${encoded}&page=${page}&limit=${limit}&fields=key,title,author_name,first_publish_year,cover_i,isbn,publisher,number_of_pages_median,subject`;
    
    // Set a 6-second timeout to maintain instant UI snappiness
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 6000);

    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timer);

    if (!res.ok) {
      throw new Error(`Open Library API responded with ${res.status}`);
    }

    const data = await res.json();
    const docs = data.docs || [];

    const parsed: WorldBook[] = docs.map((doc: any, index: number) => {
      const isbnList = doc.isbn || [];
      const primaryIsbn = isbnList[0] || `ol-${doc.key.replace(/\//g, '-')}`;
      const coverId = doc.cover_i;
      const coverUrl = coverId 
        ? `https://covers.openlibrary.org/b/id/${coverId}-L.jpg`
        : (primaryIsbn ? `https://covers.openlibrary.org/b/isbn/${primaryIsbn}-L.jpg` : '');

      const authors = doc.author_name || ['Unknown Author'];
      const subjects = (doc.subject || []).slice(0, 5);
      const genre = subjects[0] || 'World Literature';

      const wb: WorldBook = {
        bookId: `ol-${doc.key.replace(/\//g, '-')}-${index}`,
        isbn: primaryIsbn,
        title: doc.title || 'Untitled Work',
        author: authors.join(', '),
        genre: genre,
        description: `Published first in ${doc.first_publish_year || 'historical antiquity'}. Cataloged across ${doc.edition_count || 'multiple'} editions worldwide in the Universal Open Library archive.`,
        coverUrl: coverUrl,
        publisher: (doc.publisher || [])[0] || 'Universal Global Catalog',
        publicationYear: doc.first_publish_year || 2000,
        pages: doc.number_of_pages_median || 300,
        tags: subjects.map((s: string) => s.toLowerCase().replace(/[^\w\s-]/g, '').replace(/\s+/g, '-')).slice(0, 6),
        subjects: subjects,
        openLibraryKey: doc.key,
        editionCount: doc.edition_count || 1,
        firstPublishYear: doc.first_publish_year
      };

      return annotateWithLibraryStatus(wb);
    });

    return {
      books: parsed,
      totalFound: data.numFound || parsed.length
    };
  } catch (err) {
    console.warn('Live Open Library lookup fell back to local curated world index:', err);
    // Offline / timeout fallback: search locally in curated collection
    const localFiltered = CURATED_WORLD_BOOKS.filter(b => 
      b.title.toLowerCase().includes(trimmed.toLowerCase()) ||
      b.author.toLowerCase().includes(trimmed.toLowerCase()) ||
      b.genre.toLowerCase().includes(trimmed.toLowerCase()) ||
      b.tags.some(t => t.toLowerCase().includes(trimmed.toLowerCase()))
    ).map(annotateWithLibraryStatus);

    return {
      books: localFiltered,
      totalFound: localFiltered.length
    };
  }
}

// Fetch World Books by Subject / Topic
export async function fetchWorldBooksBySubject(subject: string, limit = 20): Promise<WorldBook[]> {
  try {
    const encoded = encodeURIComponent(subject.toLowerCase().replace(/\s+/g, '_'));
    const url = `https://openlibrary.org/subjects/${encoded}.json?limit=${limit}`;

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 6000);

    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timer);

    if (!res.ok) throw new Error(`Subject search error`);

    const data = await res.json();
    const works = data.works || [];

    return works.map((work: any, index: number) => {
      const coverId = work.cover_id;
      const coverUrl = coverId 
        ? `https://covers.openlibrary.org/b/id/${coverId}-L.jpg`
        : '';

      const authors = (work.authors || []).map((a: any) => a.name).join(', ') || 'Unknown Author';
      const subjects = (work.subject || []).slice(0, 4);

      const wb: WorldBook = {
        bookId: `subj-${work.key.replace(/\//g, '-')}-${index}`,
        isbn: `subj-${work.cover_edition_key || index}`,
        title: work.title,
        author: authors,
        genre: subject,
        description: `Subject classification: ${subject}. World editions recorded: ${work.edition_count || 1}.`,
        coverUrl: coverUrl,
        publisher: 'Universal Subject Archive',
        publicationYear: work.first_publish_year || 1990,
        pages: 280,
        tags: [subject.toLowerCase(), ...subjects.map((s: string) => s.toLowerCase().replace(/\s+/g, '-'))],
        subjects: subjects,
        openLibraryKey: work.key,
        editionCount: work.edition_count
      };

      return annotateWithLibraryStatus(wb);
    });
  } catch (err) {
    // Fallback: Return curated matches
    return CURATED_WORLD_BOOKS
      .filter(b => b.genre.toLowerCase().includes(subject.toLowerCase()) || b.tags.includes(subject.toLowerCase()))
      .map(annotateWithLibraryStatus);
  }
}

// Get all curated world books pre-annotated
export function getAllCuratedWorldBooks(): WorldBook[] {
  return CURATED_WORLD_BOOKS.map(annotateWithLibraryStatus);
}
