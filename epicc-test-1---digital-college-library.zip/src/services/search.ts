// Search Service
import { Book, SearchFilters } from '../types';
import { getBooks } from './catalog';

export function searchBooks(query: string, filters?: SearchFilters): Book[] {
  const books = getBooks();
  const trimmed = query.trim().toLowerCase();

  return books.filter(book => {
    // Apply filters first
    if (filters?.genre && filters.genre !== 'all') {
      if (book.genre.toLowerCase() !== filters.genre.toLowerCase()) {
        return false;
      }
    }

    if (filters?.author && filters.author !== 'all') {
      if (!book.author.toLowerCase().includes(filters.author.toLowerCase())) {
        return false;
      }
    }

    if (filters?.availableOnly) {
      if (book.availableCopies <= 0) {
        return false;
      }
    }

    if (!trimmed) {
      return true;
    }

    // Match against title, author, genre, ISBN, tags, and description keywords
    const titleMatch = book.title.toLowerCase().includes(trimmed);
    const authorMatch = book.author.toLowerCase().includes(trimmed);
    const genreMatch = book.genre.toLowerCase().includes(trimmed);
    const isbnMatch = book.isbn.toLowerCase().includes(trimmed);
    const shelfMatch = book.shelf.toLowerCase().includes(trimmed);
    const tagMatch = book.tags.some(t => t.toLowerCase().includes(trimmed));
    const descMatch = book.description.toLowerCase().includes(trimmed);

    // Multi-term matching for queries like "sci fi frank herbert"
    const terms = trimmed.split(/\s+/).filter(Boolean);
    const allTermsMatch = terms.every(term => 
      book.title.toLowerCase().includes(term) ||
      book.author.toLowerCase().includes(term) ||
      book.genre.toLowerCase().includes(term) ||
      book.tags.some(t => t.toLowerCase().includes(term)) ||
      book.description.toLowerCase().includes(term)
    );

    return titleMatch || authorMatch || genreMatch || isbnMatch || shelfMatch || tagMatch || descMatch || allTermsMatch;
  });
}
