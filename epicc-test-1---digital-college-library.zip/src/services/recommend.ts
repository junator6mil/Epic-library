// AI Book Finder Recommendation Engine
import { Book, ExternalBook, WorldBook, RecommendationResult } from '../types';
import { getBooks } from './catalog';
import { EXTERNAL_BOOKS } from '../data/seedData';
import { CURATED_WORLD_BOOKS } from './worldBooks';
import { recordSearch } from './insights';

// Synonym mapping to canonical tags
const SYNONYM_MAP: Record<string, string[]> = {
  // Manga & Anime & Japanese
  "manga": ["manga", "japanese-literature", "graphic-novels", "adventure"],
  "anime": ["manga", "japanese-literature", "shonen", "adventure"],
  "shonen": ["manga", "shonen", "adventure", "action"],
  "graphic novel": ["manga", "graphic-novels", "comic"],
  "graphic novels": ["manga", "graphic-novels"],
  "comics": ["manga", "graphic-novels"],
  "comic": ["manga", "graphic-novels"],
  "superhero": ["action", "adventure", "fantasy"],
  "ninja": ["manga", "japanese-literature", "action"],

  // Science Fiction & Tech
  "sci-fi": ["science-fiction"],
  "sci fi": ["science-fiction"],
  "scifi": ["science-fiction"],
  "science fiction": ["science-fiction"],
  "hard sci fi": ["science-fiction", "hard-scifi", "space"],
  "hard science fiction": ["science-fiction", "hard-scifi", "space"],
  "space opera": ["science-fiction", "space", "adventure"],
  "cyberpunk": ["science-fiction", "dark", "mind-bending"],
  "space": ["space", "science-fiction"],
  "galaxy": ["space", "science-fiction"],
  "alien": ["science-fiction", "alien-contact", "space"],
  "aliens": ["science-fiction", "alien-contact", "space"],
  "time travel": ["time-travel", "science-fiction", "mind-bending"],
  "astronaut": ["space", "science-fiction"],
  "planets": ["space", "science-fiction"],
  
  // Pirates & High Seas
  "pirate": ["pirates", "adventure"],
  "pirates": ["pirates", "adventure"],
  "high seas": ["pirates", "adventure"],
  "corsair": ["pirates", "adventure"],
  "salvage": ["pirates", "space", "adventure"],
  "treasure": ["adventure", "pirates", "quest"],

  // Mind-bending / Surreal
  "mind bending": ["mind-bending"],
  "mind-bending": ["mind-bending"],
  "mindbending": ["mind-bending"],
  "trippy": ["mind-bending"],
  "surreal": ["mind-bending", "atmospheric"],
  "twist": ["mind-bending", "mystery", "thriller"],
  "twists": ["mind-bending", "thriller", "mystery"],
  "labyrinth": ["mind-bending", "atmospheric"],

  // Tone & Style
  "dark": ["dark", "dark-fantasy"],
  "grim": ["dark", "dark-fantasy"],
  "gritty": ["dark"],
  "bleak": ["dark"],
  "sinister": ["dark", "thriller", "horror"],
  "scary": ["dark", "thriller", "horror"],
  "spooky": ["atmospheric", "mystery", "horror"],
  "horror": ["horror", "dark", "thriller", "psychological"],
  "atmospheric": ["atmospheric"],
  "moody": ["atmospheric"],
  "haunting": ["atmospheric", "dark"],

  // Length & Readability
  "short": ["short"],
  "quick read": ["short", "easy-read"],
  "quick": ["short", "easy-read"],
  "novella": ["short"],
  "brief": ["short"],
  "concise": ["short"],
  "easy": ["easy-read"],
  "easy read": ["easy-read"],
  "simple": ["easy-read"],
  "accessible": ["easy-read"],
  "light": ["easy-read"],
  "breeze": ["easy-read"],
  "fast": ["easy-read", "short"],

  // Philosophy & Deep Themes
  "philosophical": ["philosophical", "philosophy"],
  "philosophy": ["philosophical", "philosophy"],
  "stoic": ["philosophy", "stoicism", "wisdom"],
  "stoicism": ["philosophy", "stoicism", "wisdom"],
  "meaning of life": ["philosophical", "inspirational"],
  "existential": ["philosophical", "existential"],
  "wisdom": ["philosophical", "inspirational", "wisdom"],
  "deep": ["philosophical", "literary"],
  "thought provoking": ["philosophical", "literary"],

  // Fantasy & Magic
  "fantasy": ["fantasy", "magic"],
  "magic": ["magic", "fantasy"],
  "magical": ["magic", "fantasy"],
  "wizard": ["magic", "fantasy", "wizards"],
  "wizards": ["magic", "fantasy", "wizards"],
  "sorcery": ["magic", "fantasy"],
  "spell": ["magic", "fantasy"],
  "dragons": ["fantasy", "adventure"],
  "mythology": ["mythology", "fantasy"],
  "myth": ["mythology"],
  "gods": ["mythology", "ancient-greece"],
  "greek": ["mythology", "ancient-greece"],

  // Mystery & Thriller
  "mystery": ["mystery"],
  "mysterious": ["mystery", "atmospheric"],
  "detective": ["mystery", "detective"],
  "whodunnit": ["mystery", "detective"],
  "investigation": ["mystery", "detective"],
  "murder": ["mystery", "dark", "thriller"],
  "thriller": ["thriller"],
  "suspense": ["thriller", "suspense"],
  "intense": ["thriller"],
  "psychological": ["psychological"],
  "psychology": ["psychological"],
  "mind": ["psychological"],
  "mental": ["psychological"],
  "trauma": ["psychological"],

  // Romance
  "romance": ["romance"],
  "romantic": ["romance"],
  "love": ["romance"],
  "relationship": ["romance"],

  // Self-Help & Finance
  "self-help": ["self-help"],
  "self help": ["self-help"],
  "habits": ["self-help", "psychological"],
  "productivity": ["self-help"],
  "improvement": ["self-help", "inspirational"],
  "finance": ["finance"],
  "money": ["finance"],
  "investing": ["finance"],
  "wealth": ["finance"],
  "business": ["finance"],
  "startup": ["finance"],

  // History & Biography
  "history": ["history", "historical"],
  "historical": ["history", "historical"],
  "civilization": ["history"],
  "war": ["history", "dark"],
  "biography": ["biography"],
  "memoir": ["biography", "coming-of-age"],
  "autobiography": ["biography"],
  "true story": ["biography"],

  // General themes
  "adventure": ["adventure"],
  "journey": ["adventure"],
  "quest": ["adventure", "fantasy"],
  "inspirational": ["inspirational"],
  "inspiring": ["inspirational"],
  "motivational": ["inspirational", "self-help"],
  "dystopian": ["dystopian"],
  "dystopia": ["dystopian"],
  "post apocalyptic": ["dystopian", "dark"],
  "coming of age": ["coming-of-age"],
  "growing up": ["coming-of-age"],
  "political": ["political"],
  "politics": ["political"],
  "literary": ["literary"]
};

// Comp title shortcuts for pop-culture franchise mentions
const COMP_TITLES: Record<string, string[]> = {
  "one piece": ["manga", "shonen", "pirates", "adventure", "one-piece", "luffy"],
  "onepiece": ["manga", "shonen", "pirates", "adventure", "one-piece"],
  "luffy": ["manga", "shonen", "pirates", "adventure", "one-piece"],
  "eiichiro oda": ["manga", "shonen", "pirates", "adventure", "one-piece"],
  "oda": ["manga", "shonen", "pirates", "adventure", "one-piece"],
  "berserk": ["manga", "dark-fantasy", "dark", "action", "monsters"],
  "attack on titan": ["manga", "dark-fantasy", "dystopian", "action", "monsters"],
  "aot": ["manga", "dark-fantasy", "dystopian"],
  "shingeki": ["manga", "dark-fantasy", "dystopian"],
  "death note": ["manga", "psychological", "thriller", "mystery", "supernatural", "detective"],
  "fullmetal alchemist": ["manga", "fantasy", "adventure", "magic"],
  "naruto": ["manga", "shonen", "ninja", "adventure"],
  "chainsaw man": ["manga", "dark-fantasy", "action"],
  "harry potter": ["fantasy", "magic", "adventure", "coming-of-age", "wizards"],
  "lord of the rings": ["fantasy", "adventure", "mythology", "magic", "epic", "tolkien"],
  "lotr": ["fantasy", "adventure", "mythology", "tolkien"],
  "tolkien": ["fantasy", "adventure", "mythology", "magic", "tolkien"],
  "game of thrones": ["fantasy", "dark", "political", "magic", "epic"],
  "asoiaf": ["fantasy", "dark", "political"],
  "stephen king": ["horror", "psychological", "dark", "thriller", "suspense", "stephen-king"],
  "three body problem": ["science-fiction", "hard-scifi", "space", "alien-contact"],
  "three-body problem": ["science-fiction", "hard-scifi", "space", "alien-contact"],
  "alchemist": ["philosophical", "inspirational", "adventure"],
  "hunger games": ["dystopian", "dark", "adventure", "coming-of-age"],
  "matrix": ["science-fiction", "mind-bending", "dark", "dystopian"],
  "interstellar": ["science-fiction", "space", "philosophical"],
  "sherlock": ["mystery", "psychological", "detective"],
  "sherlock holmes": ["mystery", "detective"],
  "gone girl": ["mystery", "thriller", "psychological", "dark"],
  "atomic habits": ["self-help", "psychological", "inspirational"]
};

export function recommendBooks(query: string): {
  inLibrary: RecommendationResult[];
  notInLibrary: RecommendationResult[];
} {
  const rawLower = query.toLowerCase().trim();
  const normalized = rawLower.replace(/[^\w\s-]/g, ' ').trim();
  
  if (!normalized) {
    return { inLibrary: [], notInLibrary: [] };
  }

  // Record query for demand signal analytics
  try {
    recordSearch(normalized);
  } catch (e) {
    // safe guard
  }

  // 1. Extract canonical tags from comp titles
  const extractedTags = new Set<string>();

  for (const [compTitle, tags] of Object.entries(COMP_TITLES)) {
    if (normalized.includes(compTitle) || rawLower.includes(compTitle)) {
      tags.forEach(t => extractedTags.add(t));
    }
  }

  // 2. Extract canonical tags from synonym dictionary
  for (const [synonym, tags] of Object.entries(SYNONYM_MAP)) {
    const regex = new RegExp(`\\b${synonym.replace('-', '[- ]?')}\\b`, 'i');
    if (regex.test(normalized)) {
      tags.forEach(t => extractedTags.add(t));
    }
  }

  // 3. Extract direct token tags
  const tokens = normalized.split(/\s+/).filter(Boolean);
  tokens.forEach(tok => {
    if (SYNONYM_MAP[tok]) {
      SYNONYM_MAP[tok].forEach(t => extractedTags.add(t));
    }
  });

  const queryTags = Array.from(extractedTags);

  // Filter common filler/stop words for search terms
  const STOP_WORDS = new Set([
    "a", "an", "the", "and", "or", "in", "of", "to", "for", "with", "but", "i", 
    "want", "me", "something", "book", "books", "like", "find", "show", "give", 
    "looking", "please", "can", "you", "tell", "read", "about", "is", "there"
  ]);

  const searchTerms = tokens.filter(t => !STOP_WORDS.has(t) && t.length >= 2);

  // Exact phrases check (e.g. "one piece", "stephen king", "harry potter")
  const keyPhrases = Object.keys(COMP_TITLES).filter(phrase => rawLower.includes(phrase));

  function scoreItem(book: Book | ExternalBook | WorldBook): { score: number; matchedTags: string[]; reason: string } {
    let score = 0;
    const matched: string[] = [];
    const bookTitleLower = book.title.toLowerCase();
    const bookAuthorLower = book.author.toLowerCase();
    const bookDescLower = book.description.toLowerCase();

    // 0. Exact phrase / title matches (Huge Boost +80 pts)
    for (const phrase of keyPhrases) {
      if (bookTitleLower.includes(phrase) || bookAuthorLower.includes(phrase) || book.tags.includes(phrase.replace(/\s+/g, '-'))) {
        score += 80;
        if (!matched.includes(phrase)) matched.push(phrase);
      }
    }

    // Direct match if query equals title or author
    if (rawLower.includes(bookTitleLower) || bookTitleLower.includes(rawLower)) {
      score += 60;
    }
    if (rawLower.includes(bookAuthorLower) || bookAuthorLower.includes(rawLower)) {
      score += 40;
    }

    // Tag overlap scoring (12 pts per matched tag)
    for (const tag of book.tags) {
      const tagLower = tag.toLowerCase();
      if (queryTags.includes(tagLower)) {
        score += 12;
        if (!matched.includes(tag)) matched.push(tag);
      }
    }

    // Genre match bonus (8 pts)
    const genreLower = book.genre.toLowerCase();
    if (tokens.some(tok => !STOP_WORDS.has(tok) && genreLower.includes(tok))) {
      score += 8;
      if (!matched.includes(book.genre)) matched.push(book.genre.toLowerCase());
    }

    // Search terms in title/author/description bonus
    for (const term of searchTerms) {
      if (bookTitleLower.includes(term)) {
        score += 15;
      }
      if (bookAuthorLower.includes(term)) {
        score += 12;
      }
      if (bookDescLower.includes(term)) {
        score += 4;
      }
    }

    // Construct human-readable reason
    let reason = "";
    if (keyPhrases.length > 0 && (bookTitleLower.includes(keyPhrases[0]) || bookAuthorLower.includes(keyPhrases[0]))) {
      reason = `Direct match for "${keyPhrases[0]}"`;
    } else if (matched.length > 0) {
      const displayTags = matched.slice(0, 3).map(t => t.replace('-', ' '));
      reason = `Matches: ${displayTags.join(', ')}`;
    } else if (searchTerms.length > 0) {
      reason = `Relevant to "${searchTerms.slice(0, 2).join(' ')}"`;
    } else {
      reason = "Curated literary recommendation";
    }

    return { score, matchedTags: matched, reason };
  }

  // Score in-library books
  const libraryBooks = getBooks();
  const scoredInLibrary: RecommendationResult[] = libraryBooks
    .map(book => {
      const { score, matchedTags, reason } = scoreItem(book);
      return {
        book,
        inLibrary: true,
        matchedTags,
        reason,
        score
      };
    })
    .filter(r => r.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 6);

  // Combine external books + curated world books (deduplicated against in-library titles)
  const libraryTitles = new Set(libraryBooks.map(b => b.title.toLowerCase()));
  const allWorldBooksPool: (ExternalBook | WorldBook)[] = [
    ...EXTERNAL_BOOKS,
    ...CURATED_WORLD_BOOKS
  ].filter(b => !libraryTitles.has(b.title.toLowerCase()));

  // Deduplicate by title
  const seenTitles = new Set<string>();
  const deduplicatedWorldPool: (ExternalBook | WorldBook)[] = [];
  for (const b of allWorldBooksPool) {
    const norm = b.title.toLowerCase();
    if (!seenTitles.has(norm)) {
      seenTitles.add(norm);
      deduplicatedWorldPool.push(b);
    }
  }

  // Score world & external books (Not in library)
  const scoredNotInLibrary: RecommendationResult[] = deduplicatedWorldPool
    .map(book => {
      const { score, matchedTags, reason } = scoreItem(book);
      return {
        book,
        inLibrary: false,
        matchedTags,
        reason,
        score
      };
    })
    .filter(r => r.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 8);

  return {
    inLibrary: scoredInLibrary,
    notInLibrary: scoredNotInLibrary
  };
}

