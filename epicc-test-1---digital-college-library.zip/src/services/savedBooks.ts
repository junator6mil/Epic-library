// Saved for Later Service (Local Storage Persistence)
import { Book, WorldBook } from '../types';

export interface SavedBookItem {
  bookId: string;
  title: string;
  author: string;
  genre: string;
  coverUrl: string;
  shelf?: string;
  availableCopies?: number;
  totalCopies?: number;
  inLibrary: boolean;
  savedAt: string;
  notes?: string;
}

const STORAGE_KEY = 'epicc_library_saved_books_v1';

type Listener = (saved: SavedBookItem[]) => void;
const listeners = new Set<Listener>();

function loadSavedFromStorage(): SavedBookItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (err) {
    console.error('Failed to load saved books from localStorage', err);
    return [];
  }
}

function saveToStorage(items: SavedBookItem[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    listeners.forEach(fn => fn(items));
  } catch (err) {
    console.error('Failed to write saved books to localStorage', err);
  }
}

export type SavedBookRecord = SavedBookItem;

export function getSavedBooks(): SavedBookItem[] {
  return loadSavedFromStorage();
}

export function getSavedBooksCount(): number {
  return loadSavedFromStorage().length;
}

export function isBookSaved(bookId: string): boolean {
  const list = loadSavedFromStorage();
  return list.some(item => item.bookId === bookId);
}

export function saveBook(book: Book | WorldBook | { bookId: string; title: string; author: string; genre: string; coverUrl: string; shelf?: string; availableCopies?: number; totalCopies?: number; inLibrary?: boolean }): void {
  const current = loadSavedFromStorage();
  if (current.some(item => item.bookId === book.bookId)) {
    return; // already saved
  }

  const inLibrary = 'availableCopies' in book && typeof (book as Book).availableCopies === 'number'
    ? true 
    : ('inLibrary' in book ? Boolean(book.inLibrary) : false);

  const newItem: SavedBookItem = {
    bookId: book.bookId,
    title: book.title,
    author: book.author,
    genre: book.genre,
    coverUrl: book.coverUrl,
    shelf: 'shelf' in book ? (book as any).shelf : (book as any).libraryBook?.shelf,
    availableCopies: 'availableCopies' in book ? (book as any).availableCopies : (book as any).libraryBook?.availableCopies,
    totalCopies: 'totalCopies' in book ? (book as any).totalCopies : (book as any).libraryBook?.totalCopies,
    inLibrary,
    savedAt: new Date().toISOString()
  };

  saveToStorage([newItem, ...current]);
}

export function removeSavedBook(bookId: string): void {
  const current = loadSavedFromStorage();
  const filtered = current.filter(item => item.bookId !== bookId);
  saveToStorage(filtered);
}

export function clearSavedBooks(): void {
  saveToStorage([]);
}

export function toggleSaveBook(book: Book | WorldBook): boolean {
  if (isBookSaved(book.bookId)) {
    removeSavedBook(book.bookId);
    return false; // now unsaved
  } else {
    saveBook(book);
    return true; // now saved
  }
}

export function subscribeToSavedBooks(callback: Listener): () => void {
  listeners.add(callback);
  callback(loadSavedFromStorage());
  return () => {
    listeners.delete(callback);
  };
}
